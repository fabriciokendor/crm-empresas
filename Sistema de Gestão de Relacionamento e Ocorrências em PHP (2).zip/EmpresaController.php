<?php
/**
 * Controller de Empresas
 * Sistema de Gerenciamento de Relacionamento com Empresas
 */

class EmpresaController
{
    private $empresaModel;
    
    public function __construct()
    {
        $this->empresaModel = new Empresa();
        
        // Verificar autenticação
        if (!Auth::check()) {
            header('Location: /login');
            exit;
        }
    }
    
    /**
     * Lista todas as empresas
     */
    public function index()
    {
        // Verificar permissão
        if (!$this->can('view_empresas')) {
            $this->setErrorMessage('Você não tem permissão para visualizar empresas.');
            $this->redirect('/dashboard');
            return;
        }
        
        $filtros = [
            'razao_social' => $_GET['razao_social'] ?? '',
            'nome_fantasia' => $_GET['nome_fantasia'] ?? '',
            'cnpj' => $_GET['cnpj'] ?? '',
            'cidade' => $_GET['cidade'] ?? '',
            'estado' => $_GET['estado'] ?? '',
            'contato_principal' => $_GET['contato_principal'] ?? '',
            'busca' => $_GET['busca'] ?? '',
            'ativo' => isset($_GET['ativo']) ? (bool)$_GET['ativo'] : null
        ];
        
        // Remover filtros vazios
        $filtros = array_filter($filtros, function($value) {
            return $value !== '' && $value !== null;
        });
        
        $empresas = empty($filtros) ? $this->empresaModel->all() : $this->empresaModel->search($filtros);
        $stats = $this->empresaModel->stats();
        
        $data = [
            'title' => 'Empresas - CRM Empresas',
            'empresas' => $empresas,
            'stats' => $stats,
            'filtros' => $_GET,
            'can_create' => $this->can('create_empresas'),
            'can_edit' => $this->can('edit_empresas'),
            'can_delete' => $this->can('delete_empresas'),
            'success' => $_SESSION['success_message'] ?? null,
            'error' => $_SESSION['error_message'] ?? null
        ];
        
        // Limpar mensagens da sessão
        unset($_SESSION['success_message'], $_SESSION['error_message']);
        
        $this->view('empresas/index', $data);
    }
    
    /**
     * Exibe formulário de criação
     */
    public function create()
    {
        if (!$this->can('create_empresas')) {
            $this->setErrorMessage('Você não tem permissão para criar empresas.');
            $this->redirect('/empresas');
            return;
        }
        
        $data = [
            'title' => 'Nova Empresa - CRM Empresas',
            'empresa' => [],
            'errors' => $_SESSION['validation_errors'] ?? [],
            'old' => $_SESSION['old_input'] ?? []
        ];
        
        // Limpar dados da sessão
        unset($_SESSION['validation_errors'], $_SESSION['old_input']);
        
        $this->view('empresas/create', $data);
    }
    
    /**
     * Armazena nova empresa
     */
    public function store()
    {
        if (!$this->can('create_empresas')) {
            $this->setErrorMessage('Você não tem permissão para criar empresas.');
            $this->redirect('/empresas');
            return;
        }
        
        try {
            $empresa = $this->empresaModel->create($_POST);
            $this->setSuccessMessage("Empresa '{$empresa['razao_social']}' criada com sucesso!");
            $this->redirect('/empresas');
            
        } catch (Exception $e) {
            // Armazenar erros e dados antigos na sessão
            $_SESSION['validation_errors'] = [$e->getMessage()];
            $_SESSION['old_input'] = $_POST;
            
            $this->redirect('/empresas/create');
        }
    }
    
    /**
     * Exibe detalhes de uma empresa
     */
    public function show($id)
    {
        if (!$this->can('view_empresas')) {
            $this->setErrorMessage('Você não tem permissão para visualizar empresas.');
            $this->redirect('/empresas');
            return;
        }
        
        $empresa = $this->empresaModel->find($id);
        
        if (!$empresa) {
            $this->setErrorMessage('Empresa não encontrada.');
            $this->redirect('/empresas');
            return;
        }
        
        // Buscar ocorrências recentes
        $ocorrenciasRecentes = $this->empresaModel->ocorrencias($id, 10);
        
        // Buscar estatísticas
        $stats = $this->empresaModel->estatisticasEmpresa($id);
        
        $data = [
            'title' => "Empresa: {$empresa['razao_social']} - CRM Empresas",
            'empresa' => $empresa,
            'ocorrencias_recentes' => $ocorrenciasRecentes,
            'stats' => $stats,
            'can_edit' => $this->can('edit_empresas'),
            'can_create_ocorrencia' => $this->can('create_ocorrencias')
        ];
        
        $this->view('empresas/show', $data);
    }
    
    /**
     * Exibe formulário de edição
     */
    public function edit($id)
    {
        if (!$this->can('edit_empresas')) {
            $this->setErrorMessage('Você não tem permissão para editar empresas.');
            $this->redirect('/empresas');
            return;
        }
        
        $empresa = $this->empresaModel->find($id);
        
        if (!$empresa) {
            $this->setErrorMessage('Empresa não encontrada.');
            $this->redirect('/empresas');
            return;
        }
        
        $data = [
            'title' => "Editar Empresa: {$empresa['razao_social']} - CRM Empresas",
            'empresa' => $empresa,
            'errors' => $_SESSION['validation_errors'] ?? [],
            'old' => $_SESSION['old_input'] ?? []
        ];
        
        // Limpar dados da sessão
        unset($_SESSION['validation_errors'], $_SESSION['old_input']);
        
        $this->view('empresas/edit', $data);
    }
    
    /**
     * Atualiza uma empresa
     */
    public function update($id)
    {
        if (!$this->can('edit_empresas')) {
            $this->setErrorMessage('Você não tem permissão para editar empresas.');
            $this->redirect('/empresas');
            return;
        }
        
        try {
            $empresa = $this->empresaModel->find($id);
            
            if (!$empresa) {
                throw new Exception('Empresa não encontrada.');
            }
            
            $empresaAtualizada = $this->empresaModel->update($id, $_POST);
            $this->setSuccessMessage("Empresa '{$empresaAtualizada['razao_social']}' atualizada com sucesso!");
            $this->redirect('/empresas');
            
        } catch (Exception $e) {
            // Armazenar erros e dados antigos na sessão
            $_SESSION['validation_errors'] = [$e->getMessage()];
            $_SESSION['old_input'] = $_POST;
            
            $this->redirect("/empresas/{$id}/edit");
        }
    }
    
    /**
     * Exclui uma empresa (soft delete)
     */
    public function destroy($id)
    {
        if (!$this->can('delete_empresas')) {
            $this->setErrorMessage('Você não tem permissão para excluir empresas.');
            $this->redirect('/empresas');
            return;
        }
        
        try {
            $empresa = $this->empresaModel->find($id);
            
            if (!$empresa) {
                throw new Exception('Empresa não encontrada.');
            }
            
            $this->empresaModel->delete($id);
            $this->setSuccessMessage("Empresa '{$empresa['razao_social']}' desativada com sucesso!");
            
        } catch (Exception $e) {
            $this->setErrorMessage($e->getMessage());
        }
        
        $this->redirect('/empresas');
    }
    
    /**
     * Busca empresas (AJAX)
     */
    public function search()
    {
        if (!$this->isAjaxRequest()) {
            http_response_code(400);
            return;
        }
        
        $termo = $_GET['q'] ?? '';
        $limit = min((int)($_GET['limit'] ?? 10), 50);
        
        $empresas = $this->empresaModel->autocomplete($termo, $limit);
        
        // Formatar para select2 ou similar
        $results = array_map(function($empresa) {
            $texto = $empresa['razao_social'];
            if ($empresa['nome_fantasia']) {
                $texto .= ' (' . $empresa['nome_fantasia'] . ')';
            }
            if ($empresa['cnpj']) {
                $texto .= ' - ' . $empresa['cnpj'];
            }
            
            return [
                'id' => $empresa['id'],
                'text' => $texto,
                'razao_social' => $empresa['razao_social'],
                'nome_fantasia' => $empresa['nome_fantasia'],
                'cnpj' => $empresa['cnpj']
            ];
        }, $empresas);
        
        header('Content-Type: application/json');
        echo json_encode(['results' => $results]);
    }
    
    /**
     * Retorna ocorrências de uma empresa (AJAX)
     */
    public function ocorrencias($id)
    {
        if (!$this->can('view_ocorrencias')) {
            http_response_code(403);
            echo json_encode(['error' => 'Sem permissão']);
            return;
        }
        
        $empresa = $this->empresaModel->find($id);
        
        if (!$empresa) {
            http_response_code(404);
            echo json_encode(['error' => 'Empresa não encontrada']);
            return;
        }
        
        $page = (int)($_GET['page'] ?? 1);
        $limit = min((int)($_GET['limit'] ?? 20), 100);
        $offset = ($page - 1) * $limit;
        
        $ocorrencias = $this->empresaModel->ocorrencias($id);
        
        // Paginar resultados
        $total = count($ocorrencias);
        $ocorrenciasPaginadas = array_slice($ocorrencias, $offset, $limit);
        
        // Formatar dados
        foreach ($ocorrenciasPaginadas as &$ocorrencia) {
            $ocorrencia['data_ocorrencia_formatada'] = date('d/m/Y H:i', strtotime($ocorrencia['data_ocorrencia']));
            $ocorrencia['tempo_relativo'] = $this->timeAgo($ocorrencia['data_ocorrencia']);
        }
        
        header('Content-Type: application/json');
        echo json_encode([
            'ocorrencias' => $ocorrenciasPaginadas,
            'pagination' => [
                'current_page' => $page,
                'total_pages' => ceil($total / $limit),
                'total_items' => $total,
                'per_page' => $limit
            ]
        ]);
    }
    
    /**
     * Exporta lista de empresas
     */
    public function export()
    {
        if (!$this->can('export_empresas')) {
            $this->setErrorMessage('Você não tem permissão para exportar empresas.');
            $this->redirect('/empresas');
            return;
        }
        
        $formato = $_GET['formato'] ?? 'csv';
        $empresas = $this->empresaModel->all(true); // Apenas ativas
        
        switch ($formato) {
            case 'csv':
                $this->exportCsv($empresas);
                break;
            case 'excel':
                $this->exportExcel($empresas);
                break;
            default:
                $this->setErrorMessage('Formato de exportação inválido.');
                $this->redirect('/empresas');
        }
    }
    
    /**
     * Exporta para CSV
     */
    private function exportCsv($empresas)
    {
        $filename = 'empresas_' . date('Y-m-d_H-i-s') . '.csv';
        
        header('Content-Type: text/csv; charset=utf-8');
        header('Content-Disposition: attachment; filename=' . $filename);
        
        $output = fopen('php://output', 'w');
        
        // BOM para UTF-8
        fprintf($output, chr(0xEF).chr(0xBB).chr(0xBF));
        
        // Cabeçalho
        fputcsv($output, [
            'ID', 'Razão Social', 'Nome Fantasia', 'CNPJ', 'Inscrição Estadual',
            'Endereço', 'Cidade', 'Estado', 'CEP', 'Telefone', 'Email', 'Site',
            'Contato Principal', 'Cargo do Contato', 'Status', 'Data de Cadastro'
        ], ';');
        
        // Dados
        foreach ($empresas as $empresa) {
            fputcsv($output, [
                $empresa['id'],
                $empresa['razao_social'],
                $empresa['nome_fantasia'],
                $empresa['cnpj'],
                $empresa['inscricao_estadual'],
                $empresa['endereco'],
                $empresa['cidade'],
                $empresa['estado'],
                $empresa['cep'],
                $empresa['telefone'],
                $empresa['email'],
                $empresa['site'],
                $empresa['contato_principal'],
                $empresa['cargo_contato'],
                $empresa['ativo'] ? 'Ativa' : 'Inativa',
                date('d/m/Y H:i', strtotime($empresa['created_at']))
            ], ';');
        }
        
        fclose($output);
    }
    
    /**
     * Consulta CEP via API (AJAX)
     */
    public function consultarCep()
    {
        if (!$this->isAjaxRequest()) {
            http_response_code(400);
            return;
        }
        
        $cep = preg_replace('/[^0-9]/', '', $_GET['cep'] ?? '');
        
        if (strlen($cep) !== 8) {
            http_response_code(400);
            echo json_encode(['error' => 'CEP inválido']);
            return;
        }
        
        // Consultar API do ViaCEP
        $url = "https://viacep.com.br/ws/{$cep}/json/";
        $response = @file_get_contents($url);
        
        if ($response === false) {
            http_response_code(500);
            echo json_encode(['error' => 'Erro ao consultar CEP']);
            return;
        }
        
        $data = json_decode($response, true);
        
        if (isset($data['erro'])) {
            http_response_code(404);
            echo json_encode(['error' => 'CEP não encontrado']);
            return;
        }
        
        header('Content-Type: application/json');
        echo json_encode([
            'endereco' => $data['logradouro'],
            'bairro' => $data['bairro'],
            'cidade' => $data['localidade'],
            'estado' => $data['uf'],
            'cep' => $data['cep']
        ]);
    }
    
    /**
     * Verifica permissões do usuário
     */
    private function can($action)
    {
        if (!Auth::check()) {
            return false;
        }
        
        $userRole = Auth::user()['nivel_acesso'];
        
        $permissions = [
            'admin' => ['*'],
            'operador' => [
                'view_empresas', 'create_empresas', 'edit_empresas', 'delete_empresas',
                'export_empresas', 'view_ocorrencias', 'create_ocorrencias'
            ],
            'visualizador' => ['view_empresas', 'view_ocorrencias']
        ];
        
        $userPermissions = $permissions[$userRole] ?? [];
        
        return in_array('*', $userPermissions) || in_array($action, $userPermissions);
    }
    
    /**
     * Calcula tempo relativo
     */
    private function timeAgo($datetime)
    {
        $time = time() - strtotime($datetime);
        
        if ($time < 60) return 'agora mesmo';
        if ($time < 3600) return floor($time/60) . ' min atrás';
        if ($time < 86400) return floor($time/3600) . ' h atrás';
        if ($time < 2592000) return floor($time/86400) . ' dias atrás';
        if ($time < 31536000) return floor($time/2592000) . ' meses atrás';
        
        return floor($time/31536000) . ' anos atrás';
    }
    
    /**
     * Verifica se é requisição AJAX
     */
    private function isAjaxRequest()
    {
        return isset($_SERVER['HTTP_X_REQUESTED_WITH']) && 
               strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) === 'xmlhttprequest';
    }
    
    /**
     * Renderiza uma view
     */
    private function view($view, $data = [])
    {
        // Extrair variáveis para o escopo da view
        extract($data);
        
        // Incluir header
        include APP_ROOT . '/app/views/layouts/header.php';
        
        // Incluir view específica
        $viewFile = APP_ROOT . '/app/views/' . $view . '.php';
        if (file_exists($viewFile)) {
            include $viewFile;
        } else {
            throw new Exception("View não encontrada: {$view}");
        }
        
        // Incluir footer
        include APP_ROOT . '/app/views/layouts/footer.php';
    }
    
    /**
     * Redireciona para uma URL
     */
    private function redirect($url)
    {
        header("Location: {$url}");
        exit;
    }
    
    /**
     * Define mensagem de sucesso
     */
    private function setSuccessMessage($message)
    {
        $_SESSION['success_message'] = $message;
    }
    
    /**
     * Define mensagem de erro
     */
    private function setErrorMessage($message)
    {
        $_SESSION['error_message'] = $message;
    }
}

