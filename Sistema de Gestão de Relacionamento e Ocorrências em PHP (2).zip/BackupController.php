<?php
/**
 * Controller de Backup
 * Sistema de Gerenciamento de Relacionamento com Empresas
 */

class BackupController
{
    private $backupModel;
    
    public function __construct()
    {
        $this->backupModel = new Backup();
        
        // Verificar autenticação e permissão de administrador
        if (!Auth::check() || !Auth::isAdmin()) {
            $this->setErrorMessage('Acesso negado. Apenas administradores podem gerenciar backups.');
            $this->redirect('/dashboard');
            exit;
        }
    }
    
    /**
     * Lista todos os backups
     */
    public function index()
    {
        $backups = $this->backupModel->all();
        $stats = $this->backupModel->stats();
        
        // Verificar integridade dos backups recentes
        foreach ($backups as &$backup) {
            if ($backup['status'] === 'concluido') {
                $backup['integridade'] = $this->backupModel->verifyIntegrity($backup['id']);
            }
        }
        
        $data = [
            'title' => 'Backup e Restauração - CRM Empresas',
            'backups' => $backups,
            'stats' => $stats,
            'success' => $_SESSION['success_message'] ?? null,
            'error' => $_SESSION['error_message'] ?? null
        ];
        
        // Limpar mensagens da sessão
        unset($_SESSION['success_message'], $_SESSION['error_message']);
        
        $this->view('backup/index', $data);
    }
    
    /**
     * Cria um novo backup
     */
    public function create()
    {
        try {
            $descricao = $_POST['descricao'] ?? 'Backup manual criado em ' . date('d/m/Y H:i');
            
            $backup = $this->backupModel->create('manual', $descricao);
            
            $this->setSuccessMessage("Backup criado com sucesso! Arquivo: {$backup['filename']}");
            
        } catch (Exception $e) {
            $this->setErrorMessage('Erro ao criar backup: ' . $e->getMessage());
        }
        
        // Responder com JSON se for requisição AJAX
        if ($this->isAjaxRequest()) {
            header('Content-Type: application/json');
            echo json_encode([
                'success' => !isset($e),
                'message' => isset($e) ? $e->getMessage() : 'Backup criado com sucesso',
                'backup' => $backup ?? null
            ]);
            return;
        }
        
        $this->redirect('/backup');
    }
    
    /**
     * Restaura um backup
     */
    public function restore($id)
    {
        try {
            // Verificar confirmação
            if (!isset($_POST['confirmar']) || $_POST['confirmar'] !== 'sim') {
                throw new Exception('Confirmação necessária para restaurar backup.');
            }
            
            $this->backupModel->restore($id);
            
            $this->setSuccessMessage('Backup restaurado com sucesso! O sistema foi restaurado para o estado anterior.');
            
        } catch (Exception $e) {
            $this->setErrorMessage('Erro ao restaurar backup: ' . $e->getMessage());
        }
        
        $this->redirect('/backup');
    }
    
    /**
     * Exclui um backup
     */
    public function destroy($id)
    {
        try {
            $backup = $this->backupModel->find($id);
            
            if (!$backup) {
                throw new Exception('Backup não encontrado.');
            }
            
            $this->backupModel->delete($id);
            $this->setSuccessMessage("Backup '{$backup['filename']}' excluído com sucesso!");
            
        } catch (Exception $e) {
            $this->setErrorMessage($e->getMessage());
        }
        
        $this->redirect('/backup');
    }
    
    /**
     * Download de um backup
     */
    public function download($id)
    {
        try {
            $this->backupModel->download($id);
            
        } catch (Exception $e) {
            $this->setErrorMessage('Erro ao baixar backup: ' . $e->getMessage());
            $this->redirect('/backup');
        }
    }
    
    /**
     * Upload de backup para restauração
     */
    public function upload()
    {
        try {
            if (!isset($_FILES['backup_file'])) {
                throw new Exception('Nenhum arquivo foi enviado.');
            }
            
            $backup = $this->backupModel->upload($_FILES['backup_file']);
            
            $this->setSuccessMessage("Backup '{$backup['filename']}' enviado com sucesso!");
            
        } catch (Exception $e) {
            $this->setErrorMessage('Erro no upload: ' . $e->getMessage());
        }
        
        $this->redirect('/backup');
    }
    
    /**
     * Verifica integridade de um backup
     */
    public function verify($id)
    {
        try {
            $result = $this->backupModel->verifyIntegrity($id);
            
            if ($result['valido']) {
                $this->setSuccessMessage('Backup verificado com sucesso! Arquivo íntegro.');
            } else {
                $this->setErrorMessage('Backup corrompido: ' . $result['erro']);
            }
            
        } catch (Exception $e) {
            $this->setErrorMessage('Erro na verificação: ' . $e->getMessage());
        }
        
        // Responder com JSON se for requisição AJAX
        if ($this->isAjaxRequest()) {
            header('Content-Type: application/json');
            echo json_encode([
                'success' => isset($result) && $result['valido'],
                'result' => $result ?? null,
                'message' => isset($e) ? $e->getMessage() : ($result['valido'] ? 'Backup íntegro' : $result['erro'])
            ]);
            return;
        }
        
        $this->redirect('/backup');
    }
    
    /**
     * Configurações de backup automático
     */
    public function settings()
    {
        $configFile = APP_ROOT . '/storage/backup_config.json';
        $config = [];
        
        if (file_exists($configFile)) {
            $config = json_decode(file_get_contents($configFile), true) ?? [];
        }
        
        $data = [
            'title' => 'Configurações de Backup - CRM Empresas',
            'config' => $config,
            'success' => $_SESSION['success_message'] ?? null,
            'error' => $_SESSION['error_message'] ?? null
        ];
        
        // Limpar mensagens da sessão
        unset($_SESSION['success_message'], $_SESSION['error_message']);
        
        $this->view('backup/settings', $data);
    }
    
    /**
     * Salva configurações de backup automático
     */
    public function saveSettings()
    {
        try {
            $frequencia = $_POST['frequencia'] ?? 'diario';
            $hora = $_POST['hora'] ?? '02:00';
            $ativo = isset($_POST['ativo']);
            
            // Validar dados
            if (!in_array($frequencia, ['diario', 'semanal', 'mensal'])) {
                throw new Exception('Frequência inválida.');
            }
            
            if (!preg_match('/^([01]?[0-9]|2[0-3]):[0-5][0-9]$/', $hora)) {
                throw new Exception('Hora inválida.');
            }
            
            $config = $this->backupModel->scheduleAutoBackup($frequencia, $hora);
            $config['ativo'] = $ativo;
            
            // Salvar configuração
            file_put_contents(
                APP_ROOT . '/storage/backup_config.json',
                json_encode($config, JSON_PRETTY_PRINT)
            );
            
            $this->setSuccessMessage('Configurações de backup automático salvas com sucesso!');
            
        } catch (Exception $e) {
            $this->setErrorMessage('Erro ao salvar configurações: ' . $e->getMessage());
        }
        
        $this->redirect('/backup/settings');
    }
    
    /**
     * Executa backup automático (chamado via cron)
     */
    public function auto()
    {
        try {
            // Verificar se é chamada via CLI ou cron
            if (php_sapi_name() !== 'cli' && !$this->isLocalRequest()) {
                http_response_code(403);
                echo json_encode(['error' => 'Acesso negado']);
                return;
            }
            
            $backup = $this->backupModel->create('automatico', 'Backup automático agendado');
            
            echo "Backup automático criado: {$backup['filename']}\n";
            
        } catch (Exception $e) {
            echo "Erro no backup automático: " . $e->getMessage() . "\n";
            exit(1);
        }
    }
    
    /**
     * API para estatísticas de backup (AJAX)
     */
    public function stats()
    {
        if (!$this->isAjaxRequest()) {
            http_response_code(400);
            return;
        }
        
        $stats = $this->backupModel->stats();
        
        // Formatar dados
        $stats['tamanho_total_formatado'] = Backup::formatFileSize($stats['tamanho_total']);
        $stats['espaco_usado_formatado'] = Backup::formatFileSize($stats['espaco_usado']);
        
        if ($stats['ultimo_backup']) {
            $stats['ultimo_backup_formatado'] = date('d/m/Y H:i', strtotime($stats['ultimo_backup']));
            $stats['tempo_ultimo_backup'] = $this->timeAgo($stats['ultimo_backup']);
        }
        
        header('Content-Type: application/json');
        echo json_encode($stats);
    }
    
    /**
     * Limpa backups antigos
     */
    public function cleanup()
    {
        try {
            $diasParaManter = (int)($_POST['dias'] ?? 30);
            
            if ($diasParaManter < 7) {
                throw new Exception('Deve manter pelo menos 7 dias de backup.');
            }
            
            $dataLimite = date('Y-m-d H:i:s', strtotime("-{$diasParaManter} days"));
            
            $backupsAntigos = $this->backupModel->db->select(
                "SELECT id, filename FROM backups 
                 WHERE created_at < ? AND tipo != 'manual'",
                [$dataLimite]
            );
            
            $removidos = 0;
            foreach ($backupsAntigos as $backup) {
                $this->backupModel->delete($backup['id']);
                $removidos++;
            }
            
            $this->setSuccessMessage("Limpeza concluída! {$removidos} backup(s) antigo(s) removido(s).");
            
        } catch (Exception $e) {
            $this->setErrorMessage('Erro na limpeza: ' . $e->getMessage());
        }
        
        $this->redirect('/backup');
    }
    
    /**
     * Gera script de cron para backup automático
     */
    public function cronScript()
    {
        $configFile = APP_ROOT . '/storage/backup_config.json';
        $config = [];
        
        if (file_exists($configFile)) {
            $config = json_decode(file_get_contents($configFile), true) ?? [];
        }
        
        if (empty($config) || !$config['ativo']) {
            $this->setErrorMessage('Backup automático não está configurado ou ativo.');
            $this->redirect('/backup/settings');
            return;
        }
        
        $phpPath = '/usr/bin/php'; // Ajustar conforme necessário
        $scriptPath = APP_ROOT . '/public/index.php';
        
        list($hora, $minuto) = explode(':', $config['hora']);
        
        switch ($config['frequencia']) {
            case 'diario':
                $cronExpression = "{$minuto} {$hora} * * *";
                break;
            case 'semanal':
                $cronExpression = "{$minuto} {$hora} * * 0"; // Domingo
                break;
            case 'mensal':
                $cronExpression = "{$minuto} {$hora} 1 * *"; // Dia 1 do mês
                break;
            default:
                $cronExpression = "{$minuto} {$hora} * * *";
        }
        
        $cronCommand = "{$cronExpression} {$phpPath} {$scriptPath} backup/auto >> /var/log/crm-backup.log 2>&1";
        
        $data = [
            'title' => 'Script Cron - Backup Automático',
            'cron_command' => $cronCommand,
            'config' => $config
        ];
        
        $this->view('backup/cron', $data);
    }
    
    /**
     * Métodos auxiliares
     */
    private function isAjaxRequest()
    {
        return isset($_SERVER['HTTP_X_REQUESTED_WITH']) && 
               strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) === 'xmlhttprequest';
    }
    
    private function isLocalRequest()
    {
        $remoteAddr = $_SERVER['REMOTE_ADDR'] ?? '';
        return in_array($remoteAddr, ['127.0.0.1', '::1', 'localhost']);
    }
    
    private function timeAgo($datetime)
    {
        $time = time() - strtotime($datetime);
        
        if ($time < 60) return 'agora mesmo';
        if ($time < 3600) return floor($time/60) . ' min atrás';
        if ($time < 86400) return floor($time/3600) . ' h atrás';
        if ($time < 2592000) return floor($time/86400) . ' dias atrás';
        if ($time < 31536000) return floor($time/2592000) . ' meses atrás';
        
        return floor($time/31536000) . ' anos atrás';
    }
    
    private function view($view, $data = [])
    {
        extract($data);
        include APP_ROOT . '/app/views/layouts/header.php';
        $viewFile = APP_ROOT . '/app/views/' . $view . '.php';
        if (file_exists($viewFile)) {
            include $viewFile;
        } else {
            throw new Exception("View não encontrada: {$view}");
        }
        include APP_ROOT . '/app/views/layouts/footer.php';
    }
    
    private function redirect($url)
    {
        header("Location: {$url}");
        exit;
    }
    
    private function setSuccessMessage($message)
    {
        $_SESSION['success_message'] = $message;
    }
    
    private function setErrorMessage($message)
    {
        $_SESSION['error_message'] = $message;
    }
}

