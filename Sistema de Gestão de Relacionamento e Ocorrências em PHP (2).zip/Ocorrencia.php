<?php
/**
 * Modelo Ocorrencia
 * Sistema de Gerenciamento de Relacionamento com Empresas
 */

class Ocorrencia
{
    private $db;
    
    public function __construct()
    {
        $this->db = Database::getInstance();
    }
    
    /**
     * Busca todas as ocorrências
     */
    public function all($limit = null)
    {
        $sql = "
            SELECT o.*, 
                   e.razao_social as empresa_nome,
                   e.nome_fantasia as empresa_fantasia,
                   u.nome as usuario_nome,
                   t.nome as tipo_nome,
                   t.cor as tipo_cor,
                   t.icone as tipo_icone
            FROM ocorrencias o
            INNER JOIN empresas e ON o.empresa_id = e.id
            INNER JOIN usuarios u ON o.usuario_id = u.id
            INNER JOIN tipos_ocorrencia t ON o.tipo_ocorrencia_id = t.id
            ORDER BY o.data_ocorrencia DESC
        ";
        
        if ($limit) {
            $sql .= " LIMIT ?";
            return $this->db->select($sql, [$limit]);
        }
        
        return $this->db->select($sql);
    }
    
    /**
     * Busca ocorrência por ID
     */
    public function find($id)
    {
        return $this->db->selectOne(
            "SELECT o.*, 
                    e.razao_social as empresa_nome,
                    e.nome_fantasia as empresa_fantasia,
                    e.contato_principal as empresa_contato,
                    u.nome as usuario_nome,
                    t.nome as tipo_nome,
                    t.cor as tipo_cor,
                    t.icone as tipo_icone
             FROM ocorrencias o
             INNER JOIN empresas e ON o.empresa_id = e.id
             INNER JOIN usuarios u ON o.usuario_id = u.id
             INNER JOIN tipos_ocorrencia t ON o.tipo_ocorrencia_id = t.id
             WHERE o.id = ?",
            [$id]
        );
    }
    
    /**
     * Cria uma nova ocorrência
     */
    public function create($data)
    {
        // Validar dados
        $validator = Validator::make($data, [
            'empresa_id' => 'required|exists:empresas,id',
            'tipo_ocorrencia_id' => 'required|exists:tipos_ocorrencia,id',
            'titulo' => 'required|min:5|max:200',
            'descricao' => 'required|min:10',
            'data_ocorrencia' => 'required|date',
            'prioridade' => 'in:baixa,media,alta,critica',
            'status' => 'in:aberta,em_andamento,resolvida,fechada'
        ]);
        
        if (!$validator->validate()) {
            throw new Exception('Dados inválidos: ' . implode(', ', array_map(function($errors) {
                return implode(', ', $errors);
            }, $validator->errors())));
        }
        
        // Processar anexos se houver
        $anexos = $this->processarAnexos($_FILES['anexos'] ?? []);
        
        // Inserir no banco
        $id = $this->db->insert(
            "INSERT INTO ocorrencias (
                empresa_id, usuario_id, tipo_ocorrencia_id, titulo, descricao,
                data_ocorrencia, prioridade, status, anexos, tags
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
            [
                $data['empresa_id'],
                Auth::id(),
                $data['tipo_ocorrencia_id'],
                $data['titulo'],
                $data['descricao'],
                $data['data_ocorrencia'],
                $data['prioridade'] ?? 'media',
                $data['status'] ?? 'aberta',
                $anexos ? json_encode($anexos) : null,
                $data['tags'] ?? null
            ]
        );
        
        // Registrar no histórico
        $this->registrarHistorico($id, 'criacao', null, $data);
        
        return $this->find($id);
    }
    
    /**
     * Atualiza uma ocorrência
     */
    public function update($id, $data)
    {
        // Buscar dados atuais para histórico
        $ocorrenciaAtual = $this->db->selectOne("SELECT * FROM ocorrencias WHERE id = ?", [$id]);
        
        if (!$ocorrenciaAtual) {
            throw new Exception('Ocorrência não encontrada.');
        }
        
        // Validar dados
        $validator = Validator::make($data, [
            'empresa_id' => 'required|exists:empresas,id',
            'tipo_ocorrencia_id' => 'required|exists:tipos_ocorrencia,id',
            'titulo' => 'required|min:5|max:200',
            'descricao' => 'required|min:10',
            'data_ocorrencia' => 'required|date',
            'prioridade' => 'in:baixa,media,alta,critica',
            'status' => 'in:aberta,em_andamento,resolvida,fechada'
        ]);
        
        if (!$validator->validate()) {
            throw new Exception('Dados inválidos: ' . implode(', ', array_map(function($errors) {
                return implode(', ', $errors);
            }, $validator->errors())));
        }
        
        // Processar novos anexos
        $anexosAtuais = json_decode($ocorrenciaAtual['anexos'], true) ?? [];
        $novosAnexos = $this->processarAnexos($_FILES['anexos'] ?? []);
        $anexos = array_merge($anexosAtuais, $novosAnexos);
        
        // Atualizar no banco
        $this->db->update(
            "UPDATE ocorrencias SET 
                empresa_id = ?, tipo_ocorrencia_id = ?, titulo = ?, descricao = ?,
                data_ocorrencia = ?, prioridade = ?, status = ?, anexos = ?, tags = ?
             WHERE id = ?",
            [
                $data['empresa_id'],
                $data['tipo_ocorrencia_id'],
                $data['titulo'],
                $data['descricao'],
                $data['data_ocorrencia'],
                $data['prioridade'] ?? 'media',
                $data['status'] ?? 'aberta',
                $anexos ? json_encode($anexos) : null,
                $data['tags'] ?? null,
                $id
            ]
        );
        
        // Registrar no histórico
        $this->registrarHistorico($id, 'atualizacao', $ocorrenciaAtual, $data);
        
        return $this->find($id);
    }
    
    /**
     * Resolve uma ocorrência
     */
    public function resolver($id, $resolucao)
    {
        $ocorrencia = $this->db->selectOne("SELECT * FROM ocorrencias WHERE id = ?", [$id]);
        
        if (!$ocorrencia) {
            throw new Exception('Ocorrência não encontrada.');
        }
        
        if (empty($resolucao)) {
            throw new Exception('Descrição da resolução é obrigatória.');
        }
        
        $this->db->update(
            "UPDATE ocorrencias SET status = 'resolvida', resolucao = ?, data_resolucao = NOW() WHERE id = ?",
            [$resolucao, $id]
        );
        
        // Registrar no histórico
        $this->registrarHistorico($id, 'resolucao', $ocorrencia, ['resolucao' => $resolucao]);
        
        return $this->find($id);
    }
    
    /**
     * Fecha uma ocorrência
     */
    public function fechar($id, $observacoes = null)
    {
        $ocorrencia = $this->db->selectOne("SELECT * FROM ocorrencias WHERE id = ?", [$id]);
        
        if (!$ocorrencia) {
            throw new Exception('Ocorrência não encontrada.');
        }
        
        $this->db->update(
            "UPDATE ocorrencias SET status = 'fechada' WHERE id = ?",
            [$id]
        );
        
        // Registrar no histórico
        $this->registrarHistorico($id, 'fechamento', $ocorrencia, ['observacoes' => $observacoes]);
        
        return $this->find($id);
    }
    
    /**
     * Reabre uma ocorrência
     */
    public function reabrir($id, $motivo)
    {
        $ocorrencia = $this->db->selectOne("SELECT * FROM ocorrencias WHERE id = ?", [$id]);
        
        if (!$ocorrencia) {
            throw new Exception('Ocorrência não encontrada.');
        }
        
        if (empty($motivo)) {
            throw new Exception('Motivo da reabertura é obrigatório.');
        }
        
        $this->db->update(
            "UPDATE ocorrencias SET status = 'aberta', data_resolucao = NULL WHERE id = ?",
            [$id]
        );
        
        // Registrar no histórico
        $this->registrarHistorico($id, 'reabertura', $ocorrencia, ['motivo' => $motivo]);
        
        return $this->find($id);
    }
    
    /**
     * Busca ocorrências com filtros
     */
    public function search($filtros = [])
    {
        $sql = "
            SELECT o.*, 
                   e.razao_social as empresa_nome,
                   e.nome_fantasia as empresa_fantasia,
                   u.nome as usuario_nome,
                   t.nome as tipo_nome,
                   t.cor as tipo_cor,
                   t.icone as tipo_icone
            FROM ocorrencias o
            INNER JOIN empresas e ON o.empresa_id = e.id
            INNER JOIN usuarios u ON o.usuario_id = u.id
            INNER JOIN tipos_ocorrencia t ON o.tipo_ocorrencia_id = t.id
            WHERE 1=1
        ";
        $params = [];
        
        if (!empty($filtros['empresa_id'])) {
            $sql .= " AND o.empresa_id = ?";
            $params[] = $filtros['empresa_id'];
        }
        
        if (!empty($filtros['usuario_id'])) {
            $sql .= " AND o.usuario_id = ?";
            $params[] = $filtros['usuario_id'];
        }
        
        if (!empty($filtros['tipo_ocorrencia_id'])) {
            $sql .= " AND o.tipo_ocorrencia_id = ?";
            $params[] = $filtros['tipo_ocorrencia_id'];
        }
        
        if (!empty($filtros['status'])) {
            $sql .= " AND o.status = ?";
            $params[] = $filtros['status'];
        }
        
        if (!empty($filtros['prioridade'])) {
            $sql .= " AND o.prioridade = ?";
            $params[] = $filtros['prioridade'];
        }
        
        if (!empty($filtros['data_inicio'])) {
            $sql .= " AND o.data_ocorrencia >= ?";
            $params[] = $filtros['data_inicio'];
        }
        
        if (!empty($filtros['data_fim'])) {
            $sql .= " AND o.data_ocorrencia <= ?";
            $params[] = $filtros['data_fim'] . ' 23:59:59';
        }
        
        if (!empty($filtros['busca'])) {
            $sql .= " AND (o.titulo LIKE ? OR o.descricao LIKE ? OR o.tags LIKE ?)";
            $termo = '%' . $filtros['busca'] . '%';
            $params = array_merge($params, [$termo, $termo, $termo]);
        }
        
        $sql .= " ORDER BY o.data_ocorrencia DESC";
        
        return $this->db->select($sql, $params);
    }
    
    /**
     * Busca histórico de uma ocorrência
     */
    public function historico($ocorrenciaId)
    {
        return $this->db->select(
            "SELECT h.*, u.nome as usuario_nome
             FROM historico_ocorrencias h
             LEFT JOIN usuarios u ON h.usuario_id = u.id
             WHERE h.ocorrencia_id = ?
             ORDER BY h.created_at DESC",
            [$ocorrenciaId]
        );
    }
    
    /**
     * Estatísticas gerais
     */
    public function stats()
    {
        $total = $this->db->selectOne("SELECT COUNT(*) as total FROM ocorrencias");
        
        $porStatus = $this->db->select(
            "SELECT status, COUNT(*) as total FROM ocorrencias GROUP BY status"
        );
        
        $porPrioridade = $this->db->select(
            "SELECT prioridade, COUNT(*) as total FROM ocorrencias GROUP BY prioridade"
        );
        
        $porTipo = $this->db->select(
            "SELECT t.nome, t.cor, COUNT(o.id) as total
             FROM tipos_ocorrencia t
             LEFT JOIN ocorrencias o ON t.id = o.tipo_ocorrencia_id
             GROUP BY t.id, t.nome, t.cor
             ORDER BY total DESC"
        );
        
        return [
            'total' => $total['total'],
            'por_status' => $porStatus,
            'por_prioridade' => $porPrioridade,
            'por_tipo' => $porTipo
        ];
    }
    
    /**
     * Ocorrências por período
     */
    public function porPeriodo($periodo = '12 months')
    {
        return $this->db->select(
            "SELECT 
                DATE_FORMAT(data_ocorrencia, '%Y-%m') as mes,
                COUNT(*) as total
             FROM ocorrencias
             WHERE data_ocorrencia >= DATE_SUB(NOW(), INTERVAL {$periodo})
             GROUP BY DATE_FORMAT(data_ocorrencia, '%Y-%m')
             ORDER BY mes"
        );
    }
    
    /**
     * Processa upload de anexos
     */
    private function processarAnexos($files)
    {
        if (empty($files['name'][0])) {
            return [];
        }
        
        $anexos = [];
        $uploadDir = APP_ROOT . '/public/uploads/ocorrencias/';
        
        // Criar diretório se não existir
        if (!is_dir($uploadDir)) {
            mkdir($uploadDir, 0755, true);
        }
        
        for ($i = 0; $i < count($files['name']); $i++) {
            if ($files['error'][$i] === UPLOAD_ERR_OK) {
                $filename = $this->generateUniqueFilename($files['name'][$i]);
                $filepath = $uploadDir . $filename;
                
                if (move_uploaded_file($files['tmp_name'][$i], $filepath)) {
                    $anexos[] = [
                        'nome_original' => $files['name'][$i],
                        'nome_arquivo' => $filename,
                        'tamanho' => $files['size'][$i],
                        'tipo' => $files['type'][$i],
                        'data_upload' => date('Y-m-d H:i:s')
                    ];
                }
            }
        }
        
        return $anexos;
    }
    
    /**
     * Gera nome único para arquivo
     */
    private function generateUniqueFilename($originalName)
    {
        $extension = pathinfo($originalName, PATHINFO_EXTENSION);
        return uniqid() . '_' . time() . '.' . $extension;
    }
    
    /**
     * Registra ação no histórico
     */
    private function registrarHistorico($ocorrenciaId, $acao, $dadosAnteriores = null, $dadosNovos = null)
    {
        $this->db->insert(
            "INSERT INTO historico_ocorrencias (ocorrencia_id, usuario_id, acao, dados_anteriores, dados_novos) 
             VALUES (?, ?, ?, ?, ?)",
            [
                $ocorrenciaId,
                Auth::id(),
                $acao,
                $dadosAnteriores ? json_encode($dadosAnteriores) : null,
                $dadosNovos ? json_encode($dadosNovos) : null
            ]
        );
    }
    
    /**
     * Remove anexo de uma ocorrência
     */
    public function removerAnexo($ocorrenciaId, $nomeArquivo)
    {
        $ocorrencia = $this->db->selectOne("SELECT anexos FROM ocorrencias WHERE id = ?", [$ocorrenciaId]);
        
        if (!$ocorrencia) {
            throw new Exception('Ocorrência não encontrada.');
        }
        
        $anexos = json_decode($ocorrencia['anexos'], true) ?? [];
        
        // Remover anexo da lista
        $anexos = array_filter($anexos, function($anexo) use ($nomeArquivo) {
            return $anexo['nome_arquivo'] !== $nomeArquivo;
        });
        
        // Remover arquivo físico
        $filepath = APP_ROOT . '/public/uploads/ocorrencias/' . $nomeArquivo;
        if (file_exists($filepath)) {
            unlink($filepath);
        }
        
        // Atualizar banco
        $this->db->update(
            "UPDATE ocorrencias SET anexos = ? WHERE id = ?",
            [json_encode(array_values($anexos)), $ocorrenciaId]
        );
        
        return true;
    }
    
    /**
     * Conta ocorrências por status
     */
    public function countByStatus($status)
    {
        $result = $this->db->selectOne(
            "SELECT COUNT(*) as total FROM ocorrencias WHERE status = ?",
            [$status]
        );
        return $result['total'];
    }
    
    /**
     * Ocorrências em atraso (abertas há mais de X dias)
     */
    public function emAtraso($dias = 7)
    {
        return $this->db->select(
            "SELECT o.*, 
                    e.razao_social as empresa_nome,
                    u.nome as usuario_nome,
                    t.nome as tipo_nome,
                    DATEDIFF(NOW(), o.data_ocorrencia) as dias_atraso
             FROM ocorrencias o
             INNER JOIN empresas e ON o.empresa_id = e.id
             INNER JOIN usuarios u ON o.usuario_id = u.id
             INNER JOIN tipos_ocorrencia t ON o.tipo_ocorrencia_id = t.id
             WHERE o.status IN ('aberta', 'em_andamento') 
             AND DATEDIFF(NOW(), o.data_ocorrencia) > ?
             ORDER BY dias_atraso DESC",
            [$dias]
        );
    }
}

