# 🔧 Solução para Erro do Apache

**Resolvendo o erro "Job for apache2.service failed"**

---

## 🚨 Diagnóstico do Problema

O erro que você está vendo indica que o Apache não conseguiu iniciar. Vamos diagnosticar e resolver:

### 1. Verificar o que está ocupando a porta 80

```bash
# Verificar se algo está usando a porta 80
sudo netstat -tlnp | grep :80

# Ou usar ss (mais moderno)
sudo ss -tlnp | grep :80

# Verificar processos do Apache
ps aux | grep apache
```

### 2. Verificar logs detalhados do erro

```bash
# Ver logs do systemd
sudo journalctl -u apache2.service -l --no-pager

# Ver logs do Apache
sudo tail -f /var/log/apache2/error.log
```

### 3. Verificar configuração do Apache

```bash
# Testar configuração
sudo apache2ctl configtest
```

---

## 🛠️ Soluções Passo a Passo

### Solução 1: Limpar e Reinstalar Apache

```bash
# Parar qualquer processo Apache
sudo pkill apache2

# Remover Apache completamente
sudo apt remove --purge apache2 apache2-utils apache2-bin
sudo apt autoremove

# Limpar configurações
sudo rm -rf /etc/apache2
sudo rm -rf /var/www/html

# Reinstalar Apache
sudo apt update
sudo apt install -y apache2

# Verificar se instalou corretamente
sudo systemctl status apache2
```

### Solução 2: Se há conflito de porta

```bash
# Verificar se nginx ou outro servidor está rodando
sudo systemctl status nginx
sudo systemctl stop nginx
sudo systemctl disable nginx

# Ou se for outro serviço na porta 80
sudo fuser -k 80/tcp
```

### Solução 3: Corrigir permissões e configurações

```bash
# Recriar diretórios necessários
sudo mkdir -p /var/www/html
sudo chown -R www-data:www-data /var/www/html

# Verificar se usuário www-data existe
id www-data

# Se não existir, criar
sudo adduser --system --group --no-create-home --disabled-login www-data
```

### Solução 4: Configuração manual do Apache

```bash
# Verificar se módulos básicos estão habilitados
sudo a2enmod rewrite
sudo a2enmod headers

# Verificar sites disponíveis
sudo a2ensite 000-default

# Recarregar configuração
sudo systemctl daemon-reload
sudo systemctl restart apache2
```

---

## 🚀 Instalação Alternativa (Passo a Passo)

Se ainda der problema, vamos instalar um por vez:

### 1. Instalar apenas Apache primeiro

```bash
# Atualizar sistema
sudo apt update

# Instalar apenas Apache
sudo apt install -y apache2

# Verificar se funcionou
sudo systemctl status apache2
curl -I http://localhost
```

### 2. Instalar MySQL

```bash
# Instalar MySQL
sudo apt install -y mysql-server

# Verificar se funcionou
sudo systemctl status mysql
```

### 3. Instalar PHP

```bash
# Instalar PHP e extensões
sudo apt install -y php libapache2-mod-php php-mysql php-mbstring php-xml php-curl php-zip php-gd

# Reiniciar Apache
sudo systemctl restart apache2

# Testar PHP
echo "<?php phpinfo(); ?>" | sudo tee /var/www/html/info.php
curl http://localhost/info.php
```

---

## 🔍 Diagnóstico Avançado

Se ainda não funcionar, execute estes comandos para diagnóstico:

```bash
# Verificar versão do Ubuntu
lsb_release -a

# Verificar espaço em disco
df -h

# Verificar memória
free -h

# Verificar se há outros serviços web
sudo netstat -tlnp | grep -E ':(80|443|8080)'

# Verificar logs do sistema
sudo dmesg | tail -20

# Verificar status de todos os serviços web
sudo systemctl list-units --type=service | grep -E '(apache|nginx|httpd)'
```

---

## 🎯 Instalação Limpa Garantida

Se nada funcionar, vamos fazer uma instalação completamente limpa:

```bash
# 1. Limpar tudo relacionado a servidores web
sudo apt remove --purge apache2* nginx* mysql* php*
sudo apt autoremove
sudo apt autoclean

# 2. Limpar configurações residuais
sudo rm -rf /etc/apache2
sudo rm -rf /etc/nginx
sudo rm -rf /etc/mysql
sudo rm -rf /var/www
sudo rm -rf /var/lib/mysql

# 3. Atualizar sistema
sudo apt update && sudo apt upgrade -y

# 4. Instalar um por vez com verificação
echo "Instalando Apache..."
sudo apt install -y apache2
sudo systemctl enable apache2
sudo systemctl start apache2
echo "Apache status:"
sudo systemctl status apache2

echo "Instalando MySQL..."
sudo apt install -y mysql-server
sudo systemctl enable mysql
sudo systemctl start mysql
echo "MySQL status:"
sudo systemctl status mysql

echo "Instalando PHP..."
sudo apt install -y php libapache2-mod-php php-mysql php-mbstring php-xml php-curl php-zip php-gd
sudo systemctl restart apache2
echo "PHP instalado, Apache reiniciado"

# 5. Testar tudo
curl -I http://localhost
```

---

## 🐛 Problemas Específicos e Soluções

### Erro: "Address already in use"
```bash
# Encontrar processo usando porta 80
sudo lsof -i :80

# Matar processo específico (substitua PID)
sudo kill -9 PID_DO_PROCESSO

# Ou matar tudo na porta 80
sudo fuser -k 80/tcp
```

### Erro: "Could not reliably determine server's fully qualified domain name"
```bash
# Adicionar ServerName ao Apache
echo "ServerName localhost" | sudo tee -a /etc/apache2/apache2.conf
sudo systemctl restart apache2
```

### Erro: "Permission denied"
```bash
# Corrigir permissões
sudo chown -R www-data:www-data /var/www
sudo chmod -R 755 /var/www
```

### Erro: "Module not found"
```bash
# Habilitar módulos necessários
sudo a2enmod rewrite headers
sudo systemctl restart apache2
```

---

## ✅ Verificação Final

Após resolver, execute estes testes:

```bash
# 1. Verificar se Apache está rodando
sudo systemctl status apache2

# 2. Testar acesso HTTP
curl -I http://localhost

# 3. Verificar se PHP funciona
echo "<?php echo 'PHP funcionando!'; ?>" | sudo tee /var/www/html/test.php
curl http://localhost/test.php

# 4. Testar MySQL
sudo mysql -e "SELECT 'MySQL funcionando!' as status;"

# 5. Ver portas abertas
sudo netstat -tlnp | grep -E ':(80|443|3306)'
```

---

## 📞 Se Ainda Não Funcionar

Me envie a saída destes comandos:

```bash
# Informações do sistema
lsb_release -a
uname -a

# Status dos serviços
sudo systemctl status apache2
sudo systemctl status mysql

# Logs de erro
sudo journalctl -u apache2.service -l --no-pager | tail -20
sudo tail -20 /var/log/apache2/error.log

# Configuração de rede
sudo netstat -tlnp | grep -E ':(80|443)'
```

Com essas informações posso te ajudar de forma mais específica!

---

## 🚀 Alternativa: Usar Docker

Se continuar com problemas, posso criar uma versão em Docker que funciona em qualquer sistema:

```bash
# Instalar Docker
curl -fsSL https://get.docker.com -o get-docker.sh
sudo sh get-docker.sh

# Executar CRM em container
# (posso criar o Dockerfile se quiser)
```

**Qual solução você quer tentar primeiro?**

