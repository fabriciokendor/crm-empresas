# 🚀 CRM Empresas - Instalação SIMPLES e RÁPIDA

**Guia para instalação básica sem configurações avançadas de segurança**

---

## ⚡ Instalação Express (30 minutos)

### 1. Preparar o Servidor Ubuntu

```bash
# Atualizar sistema
sudo apt update && sudo apt upgrade -y

# Instalar tudo de uma vez
sudo apt install -y apache2 mysql-server php php-mysql php-mbstring php-xml php-curl php-zip php-gd git curl wget vim
```

### 2. Configurar Apache

```bash
# Habilitar módulos básicos
sudo a2enmod rewrite headers

# Reiniciar Apache
sudo systemctl restart apache2
sudo systemctl enable apache2
```

### 3. Configurar MySQL (Básico)

```bash
# Configurar MySQL (aceitar padrões, definir senha root)
sudo mysql_secure_installation

# Acessar MySQL
sudo mysql -u root -p
```

```sql
-- Criar banco e usuário
CREATE DATABASE crm_empresas;
CREATE USER 'crm_user'@'localhost' IDENTIFIED BY '123456';
GRANT ALL PRIVILEGES ON crm_empresas.* TO 'crm_user'@'localhost';
FLUSH PRIVILEGES;
EXIT;
```

### 4. Instalar CRM Empresas

```bash
# Ir para diretório web
cd /var/www/html

# Baixar projeto (substitua pela URL real ou use arquivo ZIP)
sudo git clone https://github.com/seu-usuario/crm-empresas.git

# Ou se tiver ZIP local:
# sudo unzip crm-empresas.zip

# Configurar permissões básicas
sudo chown -R www-data:www-data crm-empresas
sudo chmod -R 755 crm-empresas
sudo chmod -R 777 crm-empresas/storage
sudo chmod -R 777 crm-empresas/uploads

# Criar diretórios necessários
sudo mkdir -p crm-empresas/storage/{backups,sessions,tmp,logs}
sudo chmod -R 777 crm-empresas/storage
```

### 5. Configurar Banco de Dados

```bash
# Editar configuração do banco
sudo nano crm-empresas/config/database.php
```

```php
<?php
return [
    'host' => 'localhost',
    'database' => 'crm_empresas',
    'username' => 'crm_user',
    'password' => '123456',
    'charset' => 'utf8mb4',
    'options' => [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES => false,
    ]
];
```

### 6. Importar Banco de Dados

```bash
# Navegar para o projeto
cd /var/www/html/crm-empresas

# Importar estrutura
mysql -u crm_user -p123456 crm_empresas < database/migrations/create_tables.sql
mysql -u crm_user -p123456 crm_empresas < database/migrations/optimize_indexes.sql
mysql -u crm_user -p123456 crm_empresas < database/seeds/initial_data.sql
```

### 7. Configurar Apache Virtual Host (Simples)

```bash
# Criar configuração simples
sudo nano /etc/apache2/sites-available/crm.conf
```

```apache
<VirtualHost *:80>
    DocumentRoot /var/www/html/crm-empresas/public
    
    <Directory /var/www/html/crm-empresas/public>
        AllowOverride All
        Require all granted
    </Directory>
    
    ErrorLog ${APACHE_LOG_DIR}/crm-error.log
    CustomLog ${APACHE_LOG_DIR}/crm-access.log combined
</VirtualHost>
```

```bash
# Habilitar site e desabilitar padrão
sudo a2ensite crm
sudo a2dissite 000-default

# Reiniciar Apache
sudo systemctl restart apache2
```

### 8. Ajustar PHP (Básico)

```bash
# Editar configuração PHP
sudo nano /etc/php/8.1/apache2/php.ini

# Encontrar e alterar estas linhas:
# upload_max_filesize = 10M
# post_max_size = 10M
# memory_limit = 256M

# Reiniciar Apache
sudo systemctl restart apache2
```

### 9. Testar Instalação

```bash
# Verificar se está funcionando
curl -I http://localhost

# Ver logs se houver erro
sudo tail -f /var/log/apache2/crm-error.log
```

---

## 🎯 Acesso Rápido

**URL:** http://SEU_IP_SERVIDOR  
**Login:** admin@admin.com  
**Senha:** admin123

---

## 🛠️ Instalação com Script Automático

Se preferir, use o script de instalação que já vem com o projeto:

```bash
# Navegar para o projeto
cd /var/www/html/crm-empresas

# Executar instalação automática
sudo ./install.sh

# Seguir as instruções na tela
```

---

## ⚠️ Configurações Mínimas de Segurança (Opcional)

Se quiser um pouco mais de segurança sem complicar:

### Firewall Básico
```bash
# Permitir apenas HTTP, HTTPS e SSH
sudo ufw allow 22
sudo ufw allow 80
sudo ufw allow 443
sudo ufw enable
```

### Senha MySQL Mais Segura
```bash
# Alterar senha do usuário do banco
mysql -u root -p
```
```sql
ALTER USER 'crm_user'@'localhost' IDENTIFIED BY 'MinhaSenh@Segur@123';
FLUSH PRIVILEGES;
```

Depois altere a senha no arquivo `config/database.php`.

---

## 🔧 Comandos Úteis

### Verificar Status
```bash
# Ver se serviços estão rodando
sudo systemctl status apache2
sudo systemctl status mysql

# Ver logs
sudo tail -f /var/log/apache2/crm-error.log
```

### Reiniciar Serviços
```bash
sudo systemctl restart apache2
sudo systemctl restart mysql
```

### Backup Simples
```bash
# Backup do banco
mysqldump -u crm_user -p123456 crm_empresas > backup.sql

# Backup dos arquivos
tar -czf backup-arquivos.tar.gz /var/www/html/crm-empresas
```

---

## 🚨 Problemas Comuns

### Erro 500
```bash
# Verificar permissões
sudo chown -R www-data:www-data /var/www/html/crm-empresas
sudo chmod -R 755 /var/www/html/crm-empresas
sudo chmod -R 777 /var/www/html/crm-empresas/storage
```

### Erro de Conexão com Banco
```bash
# Testar conexão
mysql -u crm_user -p123456 crm_empresas

# Se não conectar, verificar usuário e senha
```

### Site não Carrega
```bash
# Verificar se Apache está rodando
sudo systemctl status apache2

# Verificar configuração
sudo apache2ctl configtest
```

---

## 📱 Instalação Local (Desenvolvimento)

Para testar no seu computador local:

### Windows (XAMPP)
1. Baixe XAMPP
2. Instale Apache, MySQL, PHP
3. Coloque projeto em `C:\xampp\htdocs\crm-empresas`
4. Acesse `http://localhost/crm-empresas/public`

### Linux (LAMP)
```bash
sudo apt install apache2 mysql-server php php-mysql
# Seguir passos acima
```

### macOS (MAMP)
1. Baixe MAMP
2. Configure Apache e MySQL
3. Coloque projeto na pasta htdocs

---

## ✅ Checklist Rápido

- [ ] Ubuntu atualizado
- [ ] Apache, MySQL, PHP instalados
- [ ] Projeto baixado em `/var/www/html/crm-empresas`
- [ ] Permissões configuradas (777 em storage)
- [ ] Banco criado e importado
- [ ] Virtual host configurado
- [ ] Site acessível via navegador
- [ ] Login funcionando

---

## 🎉 Pronto!

Com estes passos simples, você terá o CRM Empresas funcionando rapidamente para testes e desenvolvimento. 

**Para produção, recomendo usar o guia completo com todas as configurações de segurança.**

**Tempo de instalação:** 15-30 minutos  
**Dificuldade:** Básica  
**Ideal para:** Desenvolvimento, testes, demonstrações

