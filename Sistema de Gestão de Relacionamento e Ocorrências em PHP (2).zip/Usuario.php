<?php
/**
 * Modelo Usuario
 * Sistema de Gerenciamento de Relacionamento com Empresas
 */

class Usuario
{
    private $db;
    
    public function __construct()
    {
        $this->db = Database::getInstance();
    }
    
    /**
     * Busca todos os usuários
     */
    public function all($ativo = null)
    {
        $sql = "SELECT id, nome, email, nivel_acesso, ativo, ultimo_login, created_at FROM usuarios";
        $params = [];
        
        if ($ativo !== null) {
            $sql .= " WHERE ativo = ?";
            $params[] = $ativo;
        }
        
        $sql .= " ORDER BY nome";
        
        return $this->db->select($sql, $params);
    }
    
    /**
     * Busca usuário por ID
     */
    public function find($id)
    {
        return $this->db->selectOne(
            "SELECT id, nome, email, nivel_acesso, ativo, ultimo_login, created_at FROM usuarios WHERE id = ?",
            [$id]
        );
    }
    
    /**
     * Busca usuário por email
     */
    public function findByEmail($email)
    {
        return $this->db->selectOne(
            "SELECT * FROM usuarios WHERE email = ?",
            [$email]
        );
    }
    
    /**
     * Cria um novo usuário
     */
    public function create($data)
    {
        // Validar dados
        $validator = Validator::make($data, [
            'nome' => 'required|min:2|max:100',
            'email' => 'required|email|unique:usuarios,email',
            'senha' => 'required|min:8',
            'nivel_acesso' => 'required|in:admin,operador,visualizador'
        ]);
        
        if (!$validator->validate()) {
            throw new Exception('Dados inválidos: ' . implode(', ', array_map(function($errors) {
                return implode(', ', $errors);
            }, $validator->errors())));
        }
        
        // Hash da senha
        $senhaHash = password_hash($data['senha'], PASSWORD_DEFAULT);
        
        // Inserir no banco
        $id = $this->db->insert(
            "INSERT INTO usuarios (nome, email, senha, nivel_acesso, ativo) VALUES (?, ?, ?, ?, ?)",
            [
                $data['nome'],
                $data['email'],
                $senhaHash,
                $data['nivel_acesso'],
                $data['ativo'] ?? true
            ]
        );
        
        return $this->find($id);
    }
    
    /**
     * Atualiza um usuário
     */
    public function update($id, $data)
    {
        // Validar dados
        $validator = Validator::make($data, [
            'nome' => 'required|min:2|max:100',
            'email' => 'required|email|unique:usuarios,email,' . $id,
            'nivel_acesso' => 'required|in:admin,operador,visualizador'
        ]);
        
        // Validar senha se fornecida
        if (!empty($data['senha'])) {
            $validator->rules(array_merge($validator->rules, [
                'senha' => 'required|min:8'
            ]));
        }
        
        if (!$validator->validate()) {
            throw new Exception('Dados inválidos: ' . implode(', ', array_map(function($errors) {
                return implode(', ', $errors);
            }, $validator->errors())));
        }
        
        // Preparar dados para atualização
        $updateData = [
            $data['nome'],
            $data['email'],
            $data['nivel_acesso'],
            $data['ativo'] ?? true,
            $id
        ];
        
        $sql = "UPDATE usuarios SET nome = ?, email = ?, nivel_acesso = ?, ativo = ? WHERE id = ?";
        
        // Atualizar senha se fornecida
        if (!empty($data['senha'])) {
            $senhaHash = password_hash($data['senha'], PASSWORD_DEFAULT);
            $sql = "UPDATE usuarios SET nome = ?, email = ?, senha = ?, nivel_acesso = ?, ativo = ? WHERE id = ?";
            array_splice($updateData, 2, 0, [$senhaHash]);
        }
        
        $this->db->update($sql, $updateData);
        
        return $this->find($id);
    }
    
    /**
     * Exclui um usuário (soft delete)
     */
    public function delete($id)
    {
        // Verificar se não é o último admin
        if ($this->isLastAdmin($id)) {
            throw new Exception('Não é possível excluir o último administrador do sistema');
        }
        
        return $this->db->update(
            "UPDATE usuarios SET ativo = 0 WHERE id = ?",
            [$id]
        );
    }
    
    /**
     * Exclui permanentemente um usuário
     */
    public function forceDelete($id)
    {
        // Verificar se não é o último admin
        if ($this->isLastAdmin($id)) {
            throw new Exception('Não é possível excluir o último administrador do sistema');
        }
        
        return $this->db->delete(
            "DELETE FROM usuarios WHERE id = ?",
            [$id]
        );
    }
    
    /**
     * Alterna o status ativo/inativo
     */
    public function toggleStatus($id)
    {
        $usuario = $this->find($id);
        
        if (!$usuario) {
            throw new Exception('Usuário não encontrado');
        }
        
        // Verificar se não é o último admin sendo desativado
        if ($usuario['ativo'] && $this->isLastAdmin($id)) {
            throw new Exception('Não é possível desativar o último administrador do sistema');
        }
        
        $novoStatus = !$usuario['ativo'];
        
        $this->db->update(
            "UPDATE usuarios SET ativo = ? WHERE id = ?",
            [$novoStatus, $id]
        );
        
        return $novoStatus;
    }
    
    /**
     * Verifica se é o último administrador
     */
    private function isLastAdmin($id)
    {
        $usuario = $this->find($id);
        
        if (!$usuario || $usuario['nivel_acesso'] !== 'admin') {
            return false;
        }
        
        $adminCount = $this->db->selectOne(
            "SELECT COUNT(*) as count FROM usuarios WHERE nivel_acesso = 'admin' AND ativo = 1 AND id != ?",
            [$id]
        );
        
        return $adminCount['count'] == 0;
    }
    
    /**
     * Atualiza a senha do usuário
     */
    public function updatePassword($id, $senhaAtual, $novaSenha)
    {
        $usuario = $this->db->selectOne(
            "SELECT senha FROM usuarios WHERE id = ?",
            [$id]
        );
        
        if (!$usuario) {
            throw new Exception('Usuário não encontrado');
        }
        
        // Verificar senha atual
        if (!password_verify($senhaAtual, $usuario['senha'])) {
            throw new Exception('Senha atual incorreta');
        }
        
        // Validar nova senha
        $validator = Validator::make(['senha' => $novaSenha], [
            'senha' => 'required|min:8'
        ]);
        
        if (!$validator->validate()) {
            throw new Exception('Nova senha inválida: deve ter pelo menos 8 caracteres');
        }
        
        // Atualizar senha
        $senhaHash = password_hash($novaSenha, PASSWORD_DEFAULT);
        
        return $this->db->update(
            "UPDATE usuarios SET senha = ? WHERE id = ?",
            [$senhaHash, $id]
        );
    }
    
    /**
     * Busca usuários com filtros
     */
    public function search($filtros = [])
    {
        $sql = "SELECT id, nome, email, nivel_acesso, ativo, ultimo_login, created_at FROM usuarios WHERE 1=1";
        $params = [];
        
        if (!empty($filtros['nome'])) {
            $sql .= " AND nome LIKE ?";
            $params[] = '%' . $filtros['nome'] . '%';
        }
        
        if (!empty($filtros['email'])) {
            $sql .= " AND email LIKE ?";
            $params[] = '%' . $filtros['email'] . '%';
        }
        
        if (!empty($filtros['nivel_acesso'])) {
            $sql .= " AND nivel_acesso = ?";
            $params[] = $filtros['nivel_acesso'];
        }
        
        if (isset($filtros['ativo'])) {
            $sql .= " AND ativo = ?";
            $params[] = $filtros['ativo'];
        }
        
        $sql .= " ORDER BY nome";
        
        return $this->db->select($sql, $params);
    }
    
    /**
     * Conta total de usuários
     */
    public function count($ativo = null)
    {
        $sql = "SELECT COUNT(*) as total FROM usuarios";
        $params = [];
        
        if ($ativo !== null) {
            $sql .= " WHERE ativo = ?";
            $params[] = $ativo;
        }
        
        $result = $this->db->selectOne($sql, $params);
        return $result['total'];
    }
    
    /**
     * Estatísticas de usuários
     */
    public function stats()
    {
        return [
            'total' => $this->count(),
            'ativos' => $this->count(true),
            'inativos' => $this->count(false),
            'admins' => $this->countByRole('admin'),
            'operadores' => $this->countByRole('operador'),
            'visualizadores' => $this->countByRole('visualizador')
        ];
    }
    
    /**
     * Conta usuários por nível de acesso
     */
    private function countByRole($role)
    {
        $result = $this->db->selectOne(
            "SELECT COUNT(*) as total FROM usuarios WHERE nivel_acesso = ? AND ativo = 1",
            [$role]
        );
        
        return $result['total'];
    }
    
    /**
     * Usuários mais ativos (por número de ocorrências)
     */
    public function maisAtivos($limit = 10)
    {
        return $this->db->select(
            "SELECT u.id, u.nome, u.email, COUNT(o.id) as total_ocorrencias
             FROM usuarios u
             LEFT JOIN ocorrencias o ON u.id = o.usuario_id
             WHERE u.ativo = 1
             GROUP BY u.id, u.nome, u.email
             ORDER BY total_ocorrencias DESC
             LIMIT ?",
            [$limit]
        );
    }
    
    /**
     * Últimos logins
     */
    public function ultimosLogins($limit = 10)
    {
        return $this->db->select(
            "SELECT id, nome, email, ultimo_login
             FROM usuarios
             WHERE ultimo_login IS NOT NULL AND ativo = 1
             ORDER BY ultimo_login DESC
             LIMIT ?",
            [$limit]
        );
    }
}

