# 🚀 Como Publicar o CRM Empresas no GitHub

**Guia completo para publicar seu projeto no GitHub**

---

## 📋 Pré-requisitos

- Conta no GitHub (gratuita)
- Git instalado no seu computador
- Projeto CRM Empresas pronto

---

## 🎯 Método 1: Via Interface Web (Mais Fácil)

### 1. Criar Conta no GitHub

1. Acesse [github.com](https://github.com)
2. Clique em **"Sign up"**
3. Preencha: username, email, senha
4. Verifique seu email

### 2. Criar Novo Repositório

1. Faça login no GitHub
2. Clique no **"+"** no canto superior direito
3. Selecione **"New repository"**
4. Preencha:
   - **Repository name:** `crm-empresas`
   - **Description:** `Sistema de Gerenciamento de Relacionamento com Empresas - PHP/MySQL`
   - **Public** (para ser visível) ou **Private**
   - ✅ **Add a README file**
   - ✅ **Add .gitignore** → escolha **PHP**
   - ✅ **Choose a license** → MIT License (recomendado)
5. Clique **"Create repository"**

### 3. Upload dos Arquivos

**Opção A: Arrastar e Soltar**
1. No repositório criado, clique **"uploading an existing file"**
2. Arraste todos os arquivos do projeto para a área
3. Escreva uma mensagem: `"Initial commit - CRM Empresas v1.0"`
4. Clique **"Commit changes"**

**Opção B: Upload por Pasta**
1. Comprima o projeto em ZIP
2. No GitHub, clique **"Add file"** → **"Upload files"**
3. Arraste o ZIP ou selecione arquivos
4. Commit com mensagem descritiva

---

## 🛠️ Método 2: Via Git (Linha de Comando)

### 1. Instalar Git

**Ubuntu/Debian:**
```bash
sudo apt update
sudo apt install git
```

**Windows:**
- Baixe de [git-scm.com](https://git-scm.com)

**macOS:**
```bash
brew install git
```

### 2. Configurar Git (Primeira vez)

```bash
# Configurar nome e email
git config --global user.name "Seu Nome"
git config --global user.email "seu-email@exemplo.com"

# Verificar configuração
git config --list
```

### 3. Preparar o Projeto

```bash
# Navegar para o diretório do projeto
cd /caminho/para/crm-empresas

# Inicializar repositório Git
git init

# Criar .gitignore
nano .gitignore
```

**Conteúdo do .gitignore:**
```
# Arquivos de configuração sensíveis
config/database.php
.env

# Diretórios de dados
storage/logs/*
storage/sessions/*
storage/tmp/*
uploads/*
!uploads/.gitkeep
!storage/logs/.gitkeep
!storage/sessions/.gitkeep
!storage/tmp/.gitkeep

# Backups
storage/backups/*
*.sql
*.tar.gz

# Arquivos do sistema
.DS_Store
Thumbs.db
*.log

# Dependências (se usar Composer)
vendor/
composer.lock

# IDEs
.vscode/
.idea/
*.swp
*.swo

# Arquivos temporários
*.tmp
*.temp
```

### 4. Criar Arquivos de Exemplo

```bash
# Criar arquivo de configuração de exemplo
cp config/database.php config/database.example.php

# Editar o exemplo removendo dados sensíveis
nano config/database.example.php
```

**database.example.php:**
```php
<?php
return [
    'host' => 'localhost',
    'database' => 'crm_empresas',
    'username' => 'seu_usuario',
    'password' => 'sua_senha',
    'charset' => 'utf8mb4',
    'options' => [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES => false,
    ]
];
```

### 5. Adicionar Arquivos ao Git

```bash
# Adicionar todos os arquivos
git add .

# Verificar o que será commitado
git status

# Fazer primeiro commit
git commit -m "Initial commit - CRM Empresas v1.0

- Sistema completo de CRM para empresas
- Interface responsiva com Bootstrap
- Sistema de backup automático
- Relatórios e dashboard
- Autenticação com 3 níveis de acesso"
```

### 6. Conectar com GitHub

```bash
# Adicionar repositório remoto (substitua SEU_USUARIO)
git remote add origin https://github.com/SEU_USUARIO/crm-empresas.git

# Verificar conexão
git remote -v

# Enviar código para GitHub
git push -u origin main
```

Se der erro de autenticação, use token:
```bash
# GitHub não aceita mais senha, use token pessoal
# Vá em GitHub → Settings → Developer settings → Personal access tokens
# Gere um token e use no lugar da senha
```

---

## 🔐 Configurar Token de Acesso

### 1. Criar Token Pessoal

1. GitHub → **Settings** (seu perfil)
2. **Developer settings** (menu esquerdo)
3. **Personal access tokens** → **Tokens (classic)**
4. **Generate new token**
5. Selecione permissões:
   - ✅ **repo** (acesso completo a repositórios)
   - ✅ **workflow** (se usar GitHub Actions)
6. **Generate token**
7. **COPIE O TOKEN** (só aparece uma vez!)

### 2. Usar Token

```bash
# Quando pedir senha, use o token
git push -u origin main
# Username: seu_usuario_github
# Password: cole_o_token_aqui
```

**Ou configurar credenciais:**
```bash
# Salvar credenciais (Linux/Mac)
git config --global credential.helper store

# Windows
git config --global credential.helper manager
```

---

## 📝 Melhorar o Repositório

### 1. README.md Atrativo

Edite o README.md no GitHub ou localmente:

```markdown
# 🏢 CRM Empresas

Sistema completo de gerenciamento de relacionamento com empresas clientes.

![PHP](https://img.shields.io/badge/PHP-8.1+-777BB4?style=flat&logo=php&logoColor=white)
![MySQL](https://img.shields.io/badge/MySQL-8.0+-4479A1?style=flat&logo=mysql&logoColor=white)
![Bootstrap](https://img.shields.io/badge/Bootstrap-5.3-7952B3?style=flat&logo=bootstrap&logoColor=white)
![License](https://img.shields.io/badge/License-MIT-green.svg)

## ✨ Funcionalidades

- 🏢 **Gestão de Empresas** - Cadastro completo com validação CNPJ
- 📝 **Sistema de Ocorrências** - Controle total do relacionamento
- 👥 **Gestão de Usuários** - 3 níveis de acesso
- 📊 **Relatórios Avançados** - Dashboard com gráficos interativos
- 💾 **Backup Automático** - Proteção completa dos dados
- 📱 **Interface Responsiva** - Funciona em qualquer dispositivo

## 🚀 Instalação Rápida

```bash
git clone https://github.com/SEU_USUARIO/crm-empresas.git
cd crm-empresas
./install.sh
```

## 📖 Documentação

- [Guia de Instalação](INSTALACAO_SIMPLES.md)
- [Documentação Técnica](DOCUMENTACAO_TECNICA.md)
- [Configuração do Servidor](GUIA_INSTALACAO_SERVIDOR_LINUX.md)

## 🎯 Demo

**URL:** https://demo.crm-empresas.com  
**Login:** admin@admin.com  
**Senha:** admin123

## 📄 Licença

Este projeto está sob a licença MIT. Veja [LICENSE](LICENSE) para mais detalhes.

## 🤝 Contribuição

Contribuições são bem-vindas! Veja como contribuir:

1. Fork o projeto
2. Crie uma branch (`git checkout -b feature/nova-funcionalidade`)
3. Commit suas mudanças (`git commit -m 'Adiciona nova funcionalidade'`)
4. Push para a branch (`git push origin feature/nova-funcionalidade`)
5. Abra um Pull Request

## 📞 Suporte

- 📧 Email: suporte@crm-empresas.com
- 🐛 Issues: [GitHub Issues](https://github.com/SEU_USUARIO/crm-empresas/issues)
- 📖 Wiki: [GitHub Wiki](https://github.com/SEU_USUARIO/crm-empresas/wiki)

---

**Desenvolvido com ❤️ para gestão eficiente de relacionamento empresarial**
```

### 2. Adicionar Screenshots

1. Crie pasta `screenshots/` no projeto
2. Adicione imagens do sistema:
   - `dashboard.png`
   - `empresas.png`
   - `ocorrencias.png`
   - `relatorios.png`
3. Referencie no README:

```markdown
## 📸 Screenshots

### Dashboard Principal
![Dashboard](screenshots/dashboard.png)

### Gestão de Empresas
![Empresas](screenshots/empresas.png)
```

### 3. Releases e Tags

```bash
# Criar tag de versão
git tag -a v1.0.0 -m "Versão 1.0.0 - Lançamento inicial"

# Enviar tag para GitHub
git push origin v1.0.0
```

No GitHub:
1. Vá em **Releases**
2. **Create a new release**
3. Selecione a tag `v1.0.0`
4. Título: `CRM Empresas v1.0.0`
5. Descreva as funcionalidades
6. Anexe arquivos ZIP se necessário

---

## 🌟 Dicas para Repositório Popular

### 1. Badges Atrativas

Adicione no README.md:
```markdown
![GitHub stars](https://img.shields.io/github/stars/SEU_USUARIO/crm-empresas)
![GitHub forks](https://img.shields.io/github/forks/SEU_USUARIO/crm-empresas)
![GitHub issues](https://img.shields.io/github/issues/SEU_USUARIO/crm-empresas)
![GitHub license](https://img.shields.io/github/license/SEU_USUARIO/crm-empresas)
```

### 2. Topics/Tags

No GitHub, adicione topics:
- `php`
- `mysql`
- `crm`
- `bootstrap`
- `apache`
- `business`
- `management`

### 3. GitHub Pages (Demo)

1. Crie branch `gh-pages`
2. Coloque versão demo estática
3. Ative GitHub Pages nas configurações

---

## 🔄 Atualizações Futuras

### Workflow para Updates

```bash
# Fazer mudanças no código
git add .
git commit -m "Adiciona nova funcionalidade X"
git push origin main

# Para versões importantes
git tag -a v1.1.0 -m "Versão 1.1.0 - Nova funcionalidade X"
git push origin v1.1.0
```

### Branches Organizadas

```bash
# Branch para desenvolvimento
git checkout -b develop

# Branch para funcionalidades
git checkout -b feature/nova-funcionalidade

# Branch para correções
git checkout -b hotfix/correcao-urgente
```

---

## ✅ Checklist de Publicação

- [ ] Repositório criado no GitHub
- [ ] Código enviado com sucesso
- [ ] README.md atrativo criado
- [ ] .gitignore configurado
- [ ] Arquivos sensíveis removidos
- [ ] Screenshots adicionadas
- [ ] Licença MIT incluída
- [ ] Tags/topics configuradas
- [ ] Release v1.0.0 criada
- [ ] Documentação completa
- [ ] Links funcionando

---

## 🎉 Pronto!

Seu projeto CRM Empresas agora está no GitHub e pode ser:

- **Clonado** por outros desenvolvedores
- **Usado** como base para outros projetos
- **Contribuído** pela comunidade
- **Mostrado** no seu portfólio
- **Instalado** facilmente com `git clone`

**URL do seu repositório:** `https://github.com/SEU_USUARIO/crm-empresas`

**Quer que eu ajude com alguma parte específica?**

