<?php
/**
 * Classe de Validação
 * Sistema de Gerenciamento de Relacionamento com Empresas
 */

class Validator
{
    private $data = [];
    private $rules = [];
    private $errors = [];
    private $customMessages = [];
    
    public function __construct($data = [])
    {
        $this->data = $data;
    }
    
    /**
     * Define as regras de validação
     */
    public function rules($rules)
    {
        $this->rules = $rules;
        return $this;
    }
    
    /**
     * Define mensagens customizadas
     */
    public function messages($messages)
    {
        $this->customMessages = $messages;
        return $this;
    }
    
    /**
     * Executa a validação
     */
    public function validate()
    {
        $this->errors = [];
        
        foreach ($this->rules as $field => $fieldRules) {
            $value = $this->data[$field] ?? null;
            $rules = is_string($fieldRules) ? explode('|', $fieldRules) : $fieldRules;
            
            foreach ($rules as $rule) {
                $this->validateField($field, $value, $rule);
            }
        }
        
        return empty($this->errors);
    }
    
    /**
     * Valida um campo específico
     */
    private function validateField($field, $value, $rule)
    {
        // Separar regra e parâmetros
        $parts = explode(':', $rule, 2);
        $ruleName = $parts[0];
        $parameters = isset($parts[1]) ? explode(',', $parts[1]) : [];
        
        // Executar validação
        $method = 'validate' . ucfirst($ruleName);
        
        if (method_exists($this, $method)) {
            $result = $this->$method($field, $value, $parameters);
            
            if (!$result) {
                $this->addError($field, $ruleName, $parameters);
            }
        }
    }
    
    /**
     * Adiciona um erro
     */
    private function addError($field, $rule, $parameters = [])
    {
        $message = $this->getErrorMessage($field, $rule, $parameters);
        
        if (!isset($this->errors[$field])) {
            $this->errors[$field] = [];
        }
        
        $this->errors[$field][] = $message;
    }
    
    /**
     * Retorna a mensagem de erro
     */
    private function getErrorMessage($field, $rule, $parameters = [])
    {
        $key = "{$field}.{$rule}";
        
        if (isset($this->customMessages[$key])) {
            return $this->customMessages[$key];
        }
        
        $messages = [
            'required' => 'O campo :field é obrigatório.',
            'email' => 'O campo :field deve ser um email válido.',
            'min' => 'O campo :field deve ter pelo menos :min caracteres.',
            'max' => 'O campo :field deve ter no máximo :max caracteres.',
            'numeric' => 'O campo :field deve ser um número.',
            'integer' => 'O campo :field deve ser um número inteiro.',
            'alpha' => 'O campo :field deve conter apenas letras.',
            'alphanumeric' => 'O campo :field deve conter apenas letras e números.',
            'unique' => 'O valor do campo :field já está em uso.',
            'exists' => 'O valor selecionado para :field é inválido.',
            'confirmed' => 'A confirmação do campo :field não confere.',
            'date' => 'O campo :field deve ser uma data válida.',
            'url' => 'O campo :field deve ser uma URL válida.',
            'cnpj' => 'O campo :field deve ser um CNPJ válido.',
            'cpf' => 'O campo :field deve ser um CPF válido.',
            'phone' => 'O campo :field deve ser um telefone válido.',
            'cep' => 'O campo :field deve ser um CEP válido.',
            'in' => 'O valor selecionado para :field é inválido.',
            'regex' => 'O formato do campo :field é inválido.',
            'file' => 'O campo :field deve ser um arquivo.',
            'image' => 'O campo :field deve ser uma imagem.',
            'mimes' => 'O campo :field deve ser um arquivo do tipo: :mimes.',
            'size' => 'O campo :field deve ter :size KB.',
            'between' => 'O campo :field deve estar entre :min e :max.',
        ];
        
        $message = $messages[$rule] ?? "O campo :field é inválido.";
        
        // Substituir placeholders
        $message = str_replace(':field', $this->getFieldName($field), $message);
        
        foreach ($parameters as $index => $param) {
            $placeholder = ':' . ($index === 0 ? $rule : $index);
            $message = str_replace($placeholder, $param, $message);
        }
        
        return $message;
    }
    
    /**
     * Retorna o nome amigável do campo
     */
    private function getFieldName($field)
    {
        $names = [
            'nome' => 'Nome',
            'email' => 'E-mail',
            'senha' => 'Senha',
            'senha_confirmation' => 'Confirmação da Senha',
            'razao_social' => 'Razão Social',
            'nome_fantasia' => 'Nome Fantasia',
            'cnpj' => 'CNPJ',
            'telefone' => 'Telefone',
            'endereco' => 'Endereço',
            'cidade' => 'Cidade',
            'estado' => 'Estado',
            'cep' => 'CEP',
            'titulo' => 'Título',
            'descricao' => 'Descrição',
            'data_ocorrencia' => 'Data da Ocorrência',
            'tipo_ocorrencia_id' => 'Tipo de Ocorrência',
            'empresa_id' => 'Empresa',
            'prioridade' => 'Prioridade',
            'status' => 'Status'
        ];
        
        return $names[$field] ?? ucfirst(str_replace('_', ' ', $field));
    }
    
    /**
     * Retorna todos os erros
     */
    public function errors()
    {
        return $this->errors;
    }
    
    /**
     * Retorna erros de um campo específico
     */
    public function error($field)
    {
        return $this->errors[$field] ?? [];
    }
    
    /**
     * Verifica se há erros
     */
    public function hasErrors()
    {
        return !empty($this->errors);
    }
    
    /**
     * Retorna o primeiro erro de um campo
     */
    public function first($field)
    {
        $errors = $this->error($field);
        return $errors[0] ?? null;
    }
    
    // ========== REGRAS DE VALIDAÇÃO ==========
    
    protected function validateRequired($field, $value, $parameters)
    {
        return !empty($value) || $value === '0' || $value === 0;
    }
    
    protected function validateEmail($field, $value, $parameters)
    {
        return empty($value) || filter_var($value, FILTER_VALIDATE_EMAIL) !== false;
    }
    
    protected function validateMin($field, $value, $parameters)
    {
        $min = (int) $parameters[0];
        return empty($value) || strlen($value) >= $min;
    }
    
    protected function validateMax($field, $value, $parameters)
    {
        $max = (int) $parameters[0];
        return empty($value) || strlen($value) <= $max;
    }
    
    protected function validateNumeric($field, $value, $parameters)
    {
        return empty($value) || is_numeric($value);
    }
    
    protected function validateInteger($field, $value, $parameters)
    {
        return empty($value) || filter_var($value, FILTER_VALIDATE_INT) !== false;
    }
    
    protected function validateAlpha($field, $value, $parameters)
    {
        return empty($value) || preg_match('/^[a-zA-ZÀ-ÿ\s]+$/', $value);
    }
    
    protected function validateAlphanumeric($field, $value, $parameters)
    {
        return empty($value) || preg_match('/^[a-zA-Z0-9À-ÿ\s]+$/', $value);
    }
    
    protected function validateUnique($field, $value, $parameters)
    {
        if (empty($value)) return true;
        
        $table = $parameters[0];
        $column = $parameters[1] ?? $field;
        $except = $parameters[2] ?? null;
        
        $db = Database::getInstance();
        $sql = "SELECT COUNT(*) as count FROM {$table} WHERE {$column} = ?";
        $params = [$value];
        
        if ($except) {
            $sql .= " AND id != ?";
            $params[] = $except;
        }
        
        $result = $db->selectOne($sql, $params);
        return $result['count'] == 0;
    }
    
    protected function validateExists($field, $value, $parameters)
    {
        if (empty($value)) return true;
        
        $table = $parameters[0];
        $column = $parameters[1] ?? 'id';
        
        $db = Database::getInstance();
        $result = $db->selectOne(
            "SELECT COUNT(*) as count FROM {$table} WHERE {$column} = ?",
            [$value]
        );
        
        return $result['count'] > 0;
    }
    
    protected function validateConfirmed($field, $value, $parameters)
    {
        $confirmField = $field . '_confirmation';
        $confirmValue = $this->data[$confirmField] ?? null;
        
        return $value === $confirmValue;
    }
    
    protected function validateDate($field, $value, $parameters)
    {
        if (empty($value)) return true;
        
        $date = DateTime::createFromFormat('Y-m-d', $value);
        return $date && $date->format('Y-m-d') === $value;
    }
    
    protected function validateUrl($field, $value, $parameters)
    {
        return empty($value) || filter_var($value, FILTER_VALIDATE_URL) !== false;
    }
    
    protected function validateCnpj($field, $value, $parameters)
    {
        if (empty($value)) return true;
        
        // Remove caracteres não numéricos
        $cnpj = preg_replace('/[^0-9]/', '', $value);
        
        // Verifica se tem 14 dígitos
        if (strlen($cnpj) != 14) return false;
        
        // Verifica se todos os dígitos são iguais
        if (preg_match('/(\d)\1{13}/', $cnpj)) return false;
        
        // Validação dos dígitos verificadores
        for ($i = 0, $j = 5, $soma = 0; $i < 12; $i++) {
            $soma += $cnpj[$i] * $j;
            $j = ($j == 2) ? 9 : $j - 1;
        }
        
        $resto = $soma % 11;
        if ($cnpj[12] != ($resto < 2 ? 0 : 11 - $resto)) return false;
        
        for ($i = 0, $j = 6, $soma = 0; $i < 13; $i++) {
            $soma += $cnpj[$i] * $j;
            $j = ($j == 2) ? 9 : $j - 1;
        }
        
        $resto = $soma % 11;
        return $cnpj[13] == ($resto < 2 ? 0 : 11 - $resto);
    }
    
    protected function validatePhone($field, $value, $parameters)
    {
        if (empty($value)) return true;
        
        // Remove caracteres não numéricos
        $phone = preg_replace('/[^0-9]/', '', $value);
        
        // Verifica se tem 10 ou 11 dígitos (com DDD)
        return strlen($phone) >= 10 && strlen($phone) <= 11;
    }
    
    protected function validateCep($field, $value, $parameters)
    {
        if (empty($value)) return true;
        
        return preg_match('/^\d{5}-?\d{3}$/', $value);
    }
    
    protected function validateIn($field, $value, $parameters)
    {
        return empty($value) || in_array($value, $parameters);
    }
    
    protected function validateRegex($field, $value, $parameters)
    {
        if (empty($value)) return true;
        
        $pattern = $parameters[0];
        return preg_match($pattern, $value);
    }
    
    protected function validateBetween($field, $value, $parameters)
    {
        if (empty($value)) return true;
        
        $min = (int) $parameters[0];
        $max = (int) $parameters[1];
        $length = strlen($value);
        
        return $length >= $min && $length <= $max;
    }
    
    /**
     * Método estático para validação rápida
     */
    public static function make($data, $rules, $messages = [])
    {
        $validator = new self($data);
        return $validator->rules($rules)->messages($messages);
    }
}

