<?php
/**
 * Modelo TipoOcorrencia
 * Sistema de Gerenciamento de Relacionamento com Empresas
 */

class TipoOcorrencia
{
    private $db;
    
    public function __construct()
    {
        $this->db = Database::getInstance();
    }
    
    /**
     * Busca todos os tipos de ocorrência
     */
    public function all($ativo = null)
    {
        $sql = "SELECT * FROM tipos_ocorrencia";
        $params = [];
        
        if ($ativo !== null) {
            $sql .= " WHERE ativo = ?";
            $params[] = $ativo;
        }
        
        $sql .= " ORDER BY nome";
        
        return $this->db->select($sql, $params);
    }
    
    /**
     * Busca tipo de ocorrência por ID
     */
    public function find($id)
    {
        return $this->db->selectOne(
            "SELECT * FROM tipos_ocorrencia WHERE id = ?",
            [$id]
        );
    }
    
    /**
     * Busca tipo de ocorrência por nome
     */
    public function findByNome($nome)
    {
        return $this->db->selectOne(
            "SELECT * FROM tipos_ocorrencia WHERE nome = ?",
            [$nome]
        );
    }
    
    /**
     * Cria um novo tipo de ocorrência
     */
    public function create($data)
    {
        // Validar dados
        $validator = Validator::make($data, [
            'nome' => 'required|min:2|max:50|unique:tipos_ocorrencia,nome',
            'cor' => 'regex:/^#[0-9A-Fa-f]{6}$/',
            'icone' => 'max:50'
        ]);
        
        if (!$validator->validate()) {
            throw new Exception('Dados inválidos: ' . implode(', ', array_map(function($errors) {
                return implode(', ', $errors);
            }, $validator->errors())));
        }
        
        // Inserir no banco
        $id = $this->db->insert(
            "INSERT INTO tipos_ocorrencia (nome, descricao, cor, icone, ativo) VALUES (?, ?, ?, ?, ?)",
            [
                $data['nome'],
                $data['descricao'] ?? null,
                $data['cor'] ?? '#007bff',
                $data['icone'] ?? 'fas fa-info-circle',
                $data['ativo'] ?? true
            ]
        );
        
        return $this->find($id);
    }
    
    /**
     * Atualiza um tipo de ocorrência
     */
    public function update($id, $data)
    {
        // Validar dados
        $validator = Validator::make($data, [
            'nome' => 'required|min:2|max:50|unique:tipos_ocorrencia,nome,' . $id,
            'cor' => 'regex:/^#[0-9A-Fa-f]{6}$/',
            'icone' => 'max:50'
        ]);
        
        if (!$validator->validate()) {
            throw new Exception('Dados inválidos: ' . implode(', ', array_map(function($errors) {
                return implode(', ', $errors);
            }, $validator->errors())));
        }
        
        // Atualizar no banco
        $this->db->update(
            "UPDATE tipos_ocorrencia SET nome = ?, descricao = ?, cor = ?, icone = ?, ativo = ? WHERE id = ?",
            [
                $data['nome'],
                $data['descricao'] ?? null,
                $data['cor'] ?? '#007bff',
                $data['icone'] ?? 'fas fa-info-circle',
                $data['ativo'] ?? true,
                $id
            ]
        );
        
        return $this->find($id);
    }
    
    /**
     * Exclui um tipo de ocorrência
     */
    public function delete($id)
    {
        // Verificar se há ocorrências vinculadas
        $ocorrencias = $this->db->selectOne(
            "SELECT COUNT(*) as total FROM ocorrencias WHERE tipo_ocorrencia_id = ?",
            [$id]
        );
        
        if ($ocorrencias['total'] > 0) {
            throw new Exception('Não é possível excluir tipo de ocorrência com ocorrências vinculadas. Desative o tipo em vez de excluí-lo.');
        }
        
        return $this->db->delete(
            "DELETE FROM tipos_ocorrencia WHERE id = ?",
            [$id]
        );
    }
    
    /**
     * Alterna o status ativo/inativo
     */
    public function toggleStatus($id)
    {
        $tipo = $this->find($id);
        
        if (!$tipo) {
            throw new Exception('Tipo de ocorrência não encontrado');
        }
        
        $novoStatus = !$tipo['ativo'];
        
        $this->db->update(
            "UPDATE tipos_ocorrencia SET ativo = ? WHERE id = ?",
            [$novoStatus, $id]
        );
        
        return $novoStatus;
    }
    
    /**
     * Busca tipos com filtros
     */
    public function search($filtros = [])
    {
        $sql = "SELECT * FROM tipos_ocorrencia WHERE 1=1";
        $params = [];
        
        if (!empty($filtros['nome'])) {
            $sql .= " AND nome LIKE ?";
            $params[] = '%' . $filtros['nome'] . '%';
        }
        
        if (isset($filtros['ativo'])) {
            $sql .= " AND ativo = ?";
            $params[] = $filtros['ativo'];
        }
        
        $sql .= " ORDER BY nome";
        
        return $this->db->select($sql, $params);
    }
    
    /**
     * Conta total de tipos
     */
    public function count($ativo = null)
    {
        $sql = "SELECT COUNT(*) as total FROM tipos_ocorrencia";
        $params = [];
        
        if ($ativo !== null) {
            $sql .= " WHERE ativo = ?";
            $params[] = $ativo;
        }
        
        $result = $this->db->selectOne($sql, $params);
        return $result['total'];
    }
    
    /**
     * Estatísticas de tipos de ocorrência
     */
    public function stats()
    {
        return [
            'total' => $this->count(),
            'ativos' => $this->count(true),
            'inativos' => $this->count(false)
        ];
    }
    
    /**
     * Tipos mais utilizados
     */
    public function maisUtilizados($limit = 10)
    {
        return $this->db->select(
            "SELECT 
                t.id, t.nome, t.cor, t.icone,
                COUNT(o.id) as total_ocorrencias
             FROM tipos_ocorrencia t
             LEFT JOIN ocorrencias o ON t.id = o.tipo_ocorrencia_id
             WHERE t.ativo = 1
             GROUP BY t.id, t.nome, t.cor, t.icone
             ORDER BY total_ocorrencias DESC
             LIMIT ?",
            [$limit]
        );
    }
    
    /**
     * Cores padrão para tipos
     */
    public static function getCoresPadrao()
    {
        return [
            '#007bff', // Azul
            '#28a745', // Verde
            '#dc3545', // Vermelho
            '#ffc107', // Amarelo
            '#fd7e14', // Laranja
            '#6f42c1', // Roxo
            '#20c997', // Verde água
            '#17a2b8', // Azul claro
            '#6c757d', // Cinza
            '#e83e8c', // Rosa
            '#343a40', // Preto
            '#495057'  // Cinza escuro
        ];
    }
    
    /**
     * Ícones padrão para tipos
     */
    public static function getIconesPadrao()
    {
        return [
            'fas fa-info-circle',      // Informação
            'fas fa-headset',          // Atendimento
            'fas fa-users',            // Reunião
            'fas fa-exclamation-triangle', // Problema
            'fas fa-tools',            // Suporte técnico
            'fas fa-file-contract',    // Proposta
            'fas fa-phone',            // Follow-up
            'fas fa-graduation-cap',   // Treinamento
            'fas fa-wrench',           // Manutenção
            'fas fa-cogs',             // Instalação
            'fas fa-frown',            // Reclamação
            'fas fa-smile',            // Elogio
            'fas fa-times-circle',     // Cancelamento
            'fas fa-redo',             // Renovação
            'fas fa-calculator',       // Orçamento
            'fas fa-map-marker-alt',   // Visita técnica
            'fas fa-envelope',         // Email
            'fas fa-calendar',         // Agendamento
            'fas fa-chart-line',       // Análise
            'fas fa-handshake'         // Negociação
        ];
    }
}

