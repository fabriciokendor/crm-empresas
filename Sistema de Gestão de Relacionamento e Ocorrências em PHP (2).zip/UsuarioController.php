<?php
/**
 * Controller de Usuários
 * Sistema de Gerenciamento de Relacionamento com Empresas
 */

class UsuarioController
{
    private $usuarioModel;
    
    public function __construct()
    {
        $this->usuarioModel = new Usuario();
        
        // Verificar se é administrador
        if (!Auth::isAdmin()) {
            $this->setErrorMessage('Acesso negado. Apenas administradores podem gerenciar usuários.');
            $this->redirect('/dashboard');
            exit;
        }
    }
    
    /**
     * Lista todos os usuários
     */
    public function index()
    {
        $filtros = [
            'nome' => $_GET['nome'] ?? '',
            'email' => $_GET['email'] ?? '',
            'nivel_acesso' => $_GET['nivel_acesso'] ?? '',
            'ativo' => isset($_GET['ativo']) ? (bool)$_GET['ativo'] : null
        ];
        
        // Remover filtros vazios
        $filtros = array_filter($filtros, function($value) {
            return $value !== '' && $value !== null;
        });
        
        $usuarios = empty($filtros) ? $this->usuarioModel->all() : $this->usuarioModel->search($filtros);
        $stats = $this->usuarioModel->stats();
        
        $data = [
            'title' => 'Usuários - CRM Empresas',
            'usuarios' => $usuarios,
            'stats' => $stats,
            'filtros' => $_GET,
            'success' => $_SESSION['success_message'] ?? null,
            'error' => $_SESSION['error_message'] ?? null
        ];
        
        // Limpar mensagens da sessão
        unset($_SESSION['success_message'], $_SESSION['error_message']);
        
        $this->view('usuarios/index', $data);
    }
    
    /**
     * Exibe formulário de criação
     */
    public function create()
    {
        $data = [
            'title' => 'Novo Usuário - CRM Empresas',
            'usuario' => [],
            'errors' => $_SESSION['validation_errors'] ?? [],
            'old' => $_SESSION['old_input'] ?? []
        ];
        
        // Limpar dados da sessão
        unset($_SESSION['validation_errors'], $_SESSION['old_input']);
        
        $this->view('usuarios/create', $data);
    }
    
    /**
     * Armazena novo usuário
     */
    public function store()
    {
        try {
            $usuario = $this->usuarioModel->create($_POST);
            $this->setSuccessMessage("Usuário '{$usuario['nome']}' criado com sucesso!");
            $this->redirect('/usuarios');
            
        } catch (Exception $e) {
            // Armazenar erros e dados antigos na sessão
            $_SESSION['validation_errors'] = [$e->getMessage()];
            $_SESSION['old_input'] = $_POST;
            
            $this->redirect('/usuarios/create');
        }
    }
    
    /**
     * Exibe detalhes de um usuário
     */
    public function show($id)
    {
        $usuario = $this->usuarioModel->find($id);
        
        if (!$usuario) {
            $this->setErrorMessage('Usuário não encontrado.');
            $this->redirect('/usuarios');
            return;
        }
        
        // Buscar estatísticas do usuário
        $stats = $this->getUserStats($id);
        
        $data = [
            'title' => "Usuário: {$usuario['nome']} - CRM Empresas",
            'usuario' => $usuario,
            'stats' => $stats
        ];
        
        $this->view('usuarios/show', $data);
    }
    
    /**
     * Exibe formulário de edição
     */
    public function edit($id)
    {
        $usuario = $this->usuarioModel->find($id);
        
        if (!$usuario) {
            $this->setErrorMessage('Usuário não encontrado.');
            $this->redirect('/usuarios');
            return;
        }
        
        $data = [
            'title' => "Editar Usuário: {$usuario['nome']} - CRM Empresas",
            'usuario' => $usuario,
            'errors' => $_SESSION['validation_errors'] ?? [],
            'old' => $_SESSION['old_input'] ?? []
        ];
        
        // Limpar dados da sessão
        unset($_SESSION['validation_errors'], $_SESSION['old_input']);
        
        $this->view('usuarios/edit', $data);
    }
    
    /**
     * Atualiza um usuário
     */
    public function update($id)
    {
        try {
            $usuario = $this->usuarioModel->find($id);
            
            if (!$usuario) {
                throw new Exception('Usuário não encontrado.');
            }
            
            $usuarioAtualizado = $this->usuarioModel->update($id, $_POST);
            $this->setSuccessMessage("Usuário '{$usuarioAtualizado['nome']}' atualizado com sucesso!");
            $this->redirect('/usuarios');
            
        } catch (Exception $e) {
            // Armazenar erros e dados antigos na sessão
            $_SESSION['validation_errors'] = [$e->getMessage()];
            $_SESSION['old_input'] = $_POST;
            
            $this->redirect("/usuarios/{$id}/edit");
        }
    }
    
    /**
     * Exclui um usuário (soft delete)
     */
    public function destroy($id)
    {
        try {
            $usuario = $this->usuarioModel->find($id);
            
            if (!$usuario) {
                throw new Exception('Usuário não encontrado.');
            }
            
            // Verificar se não está tentando excluir a si mesmo
            if ($id == Auth::id()) {
                throw new Exception('Você não pode excluir sua própria conta.');
            }
            
            $this->usuarioModel->delete($id);
            $this->setSuccessMessage("Usuário '{$usuario['nome']}' desativado com sucesso!");
            
        } catch (Exception $e) {
            $this->setErrorMessage($e->getMessage());
        }
        
        $this->redirect('/usuarios');
    }
    
    /**
     * Alterna status ativo/inativo
     */
    public function toggleStatus($id)
    {
        try {
            $usuario = $this->usuarioModel->find($id);
            
            if (!$usuario) {
                throw new Exception('Usuário não encontrado.');
            }
            
            // Verificar se não está tentando desativar a si mesmo
            if ($id == Auth::id()) {
                throw new Exception('Você não pode alterar o status da sua própria conta.');
            }
            
            $novoStatus = $this->usuarioModel->toggleStatus($id);
            $statusTexto = $novoStatus ? 'ativado' : 'desativado';
            
            $this->setSuccessMessage("Usuário '{$usuario['nome']}' {$statusTexto} com sucesso!");
            
        } catch (Exception $e) {
            $this->setErrorMessage($e->getMessage());
        }
        
        // Responder com JSON se for requisição AJAX
        if ($this->isAjaxRequest()) {
            header('Content-Type: application/json');
            echo json_encode([
                'success' => !isset($e),
                'message' => isset($e) ? $e->getMessage() : "Status alterado com sucesso",
                'new_status' => $novoStatus ?? null
            ]);
            return;
        }
        
        $this->redirect('/usuarios');
    }
    
    /**
     * Busca usuários (AJAX)
     */
    public function search()
    {
        if (!$this->isAjaxRequest()) {
            http_response_code(400);
            return;
        }
        
        $termo = $_GET['q'] ?? '';
        $limit = min((int)($_GET['limit'] ?? 10), 50);
        
        $usuarios = $this->usuarioModel->search(['nome' => $termo]);
        
        // Limitar resultados
        $usuarios = array_slice($usuarios, 0, $limit);
        
        // Formatar para select2 ou similar
        $results = array_map(function($usuario) {
            return [
                'id' => $usuario['id'],
                'text' => $usuario['nome'] . ' (' . $usuario['email'] . ')',
                'email' => $usuario['email'],
                'nivel_acesso' => $usuario['nivel_acesso']
            ];
        }, $usuarios);
        
        header('Content-Type: application/json');
        echo json_encode(['results' => $results]);
    }
    
    /**
     * Exporta lista de usuários
     */
    public function export()
    {
        $formato = $_GET['formato'] ?? 'csv';
        $usuarios = $this->usuarioModel->all();
        
        switch ($formato) {
            case 'csv':
                $this->exportCsv($usuarios);
                break;
            case 'excel':
                $this->exportExcel($usuarios);
                break;
            default:
                $this->setErrorMessage('Formato de exportação inválido.');
                $this->redirect('/usuarios');
        }
    }
    
    /**
     * Exporta para CSV
     */
    private function exportCsv($usuarios)
    {
        $filename = 'usuarios_' . date('Y-m-d_H-i-s') . '.csv';
        
        header('Content-Type: text/csv; charset=utf-8');
        header('Content-Disposition: attachment; filename=' . $filename);
        
        $output = fopen('php://output', 'w');
        
        // BOM para UTF-8
        fprintf($output, chr(0xEF).chr(0xBB).chr(0xBF));
        
        // Cabeçalho
        fputcsv($output, [
            'ID', 'Nome', 'Email', 'Nível de Acesso', 'Status', 'Último Login', 'Data de Cadastro'
        ], ';');
        
        // Dados
        foreach ($usuarios as $usuario) {
            fputcsv($output, [
                $usuario['id'],
                $usuario['nome'],
                $usuario['email'],
                $usuario['nivel_acesso'],
                $usuario['ativo'] ? 'Ativo' : 'Inativo',
                $usuario['ultimo_login'] ? date('d/m/Y H:i', strtotime($usuario['ultimo_login'])) : 'Nunca',
                date('d/m/Y H:i', strtotime($usuario['created_at']))
            ], ';');
        }
        
        fclose($output);
    }
    
    /**
     * Retorna estatísticas de um usuário
     */
    private function getUserStats($userId)
    {
        $db = Database::getInstance();
        
        // Total de ocorrências criadas
        $ocorrencias = $db->selectOne(
            "SELECT COUNT(*) as total FROM ocorrencias WHERE usuario_id = ?",
            [$userId]
        );
        
        // Ocorrências por status
        $ocorrenciasPorStatus = $db->select(
            "SELECT status, COUNT(*) as total FROM ocorrencias WHERE usuario_id = ? GROUP BY status",
            [$userId]
        );
        
        // Empresas cadastradas
        $empresas = $db->selectOne(
            "SELECT COUNT(*) as total FROM empresas WHERE usuario_cadastro = ?",
            [$userId]
        );
        
        // Última atividade
        $ultimaAtividade = $db->selectOne(
            "SELECT MAX(created_at) as ultima FROM logs_sistema WHERE usuario_id = ?",
            [$userId]
        );
        
        return [
            'total_ocorrencias' => $ocorrencias['total'],
            'ocorrencias_por_status' => $ocorrenciasPorStatus,
            'total_empresas' => $empresas['total'],
            'ultima_atividade' => $ultimaAtividade['ultima']
        ];
    }
    
    /**
     * Verifica se é requisição AJAX
     */
    private function isAjaxRequest()
    {
        return isset($_SERVER['HTTP_X_REQUESTED_WITH']) && 
               strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) === 'xmlhttprequest';
    }
    
    /**
     * Renderiza uma view
     */
    private function view($view, $data = [])
    {
        // Extrair variáveis para o escopo da view
        extract($data);
        
        // Incluir header
        include APP_ROOT . '/app/views/layouts/header.php';
        
        // Incluir view específica
        $viewFile = APP_ROOT . '/app/views/' . $view . '.php';
        if (file_exists($viewFile)) {
            include $viewFile;
        } else {
            throw new Exception("View não encontrada: {$view}");
        }
        
        // Incluir footer
        include APP_ROOT . '/app/views/layouts/footer.php';
    }
    
    /**
     * Redireciona para uma URL
     */
    private function redirect($url)
    {
        header("Location: {$url}");
        exit;
    }
    
    /**
     * Define mensagem de sucesso
     */
    private function setSuccessMessage($message)
    {
        $_SESSION['success_message'] = $message;
    }
    
    /**
     * Define mensagem de erro
     */
    private function setErrorMessage($message)
    {
        $_SESSION['error_message'] = $message;
    }
}

