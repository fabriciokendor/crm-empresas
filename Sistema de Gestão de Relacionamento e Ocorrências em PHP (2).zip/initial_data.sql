-- ============================================================================
-- Sistema de Gerenciamento de Relacionamento com Empresas
-- Script de Dados Iniciais (Seeds)
-- ============================================================================

USE crm_empresas;

-- ============================================================================
-- DADOS INICIAIS: tipos_ocorrencia
-- ============================================================================
INSERT INTO tipos_ocorrencia (nome, descricao, cor, icone) VALUES
('Atendimento', 'Atendimento geral ao cliente', '#28a745', 'fas fa-headset'),
('Reunião', 'Reuniões presenciais ou virtuais', '#007bff', 'fas fa-users'),
('Problema', 'Problemas reportados pelo cliente', '#dc3545', 'fas fa-exclamation-triangle'),
('Suporte Técnico', 'Suporte técnico especializado', '#fd7e14', 'fas fa-tools'),
('Proposta Comercial', 'Apresentação de propostas', '#6f42c1', 'fas fa-file-contract'),
('Follow-up', 'Acompanhamento de negociações', '#20c997', 'fas fa-phone'),
('Treinamento', 'Treinamentos e capacitações', '#17a2b8', 'fas fa-graduation-cap'),
('Manutenção', 'Serviços de manutenção', '#6c757d', 'fas fa-wrench'),
('Instalação', 'Instalação de produtos/serviços', '#ffc107', 'fas fa-cogs'),
('Reclamação', 'Reclamações e insatisfações', '#e83e8c', 'fas fa-frown'),
('Elogio', 'Elogios e feedback positivo', '#28a745', 'fas fa-smile'),
('Cancelamento', 'Solicitações de cancelamento', '#dc3545', 'fas fa-times-circle'),
('Renovação', 'Renovação de contratos', '#007bff', 'fas fa-redo'),
('Orçamento', 'Solicitações de orçamento', '#6f42c1', 'fas fa-calculator'),
('Visita Técnica', 'Visitas técnicas programadas', '#fd7e14', 'fas fa-map-marker-alt');

-- ============================================================================
-- DADOS INICIAIS: usuarios
-- ============================================================================
-- Usuário administrador padrão
-- Senha: admin123 (deve ser alterada no primeiro acesso)
INSERT INTO usuarios (nome, email, senha, nivel_acesso) VALUES
('Administrador', 'admin@empresa.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'admin');

-- Usuários de exemplo para demonstração
INSERT INTO usuarios (nome, email, senha, nivel_acesso) VALUES
('João Silva', 'joao.silva@empresa.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'operador'),
('Maria Santos', 'maria.santos@empresa.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'operador'),
('Pedro Oliveira', 'pedro.oliveira@empresa.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'visualizador');

-- ============================================================================
-- DADOS INICIAIS: empresas (exemplos para demonstração)
-- ============================================================================
INSERT INTO empresas (razao_social, nome_fantasia, cnpj, endereco, cidade, estado, cep, telefone, email, contato_principal, cargo_contato, usuario_cadastro) VALUES
('TECH SOLUTIONS LTDA', 'TechSol', '12.345.678/0001-90', 'Rua das Tecnologias, 123', 'São Paulo', 'SP', '01234-567', '(11) 1234-5678', 'contato@techsol.com.br', 'Carlos Mendes', 'Gerente de TI', 1),
('COMERCIAL BRASIL S/A', 'ComBrasil', '98.765.432/0001-10', 'Av. Comercial, 456', 'Rio de Janeiro', 'RJ', '20123-456', '(21) 9876-5432', 'vendas@combrasil.com.br', 'Ana Costa', 'Diretora Comercial', 1),
('INDUSTRIA MODERNA LTDA', 'IndModerna', '11.222.333/0001-44', 'Rua Industrial, 789', 'Belo Horizonte', 'MG', '30123-789', '(31) 1111-2222', 'contato@indmoderna.com.br', 'Roberto Lima', 'Supervisor de Produção', 1);

-- ============================================================================
-- DADOS INICIAIS: ocorrencias (exemplos para demonstração)
-- ============================================================================
INSERT INTO ocorrencias (empresa_id, usuario_id, tipo_ocorrencia_id, titulo, descricao, data_ocorrencia, prioridade, status) VALUES
(1, 2, 1, 'Primeiro contato com cliente', 'Apresentação inicial dos serviços da empresa. Cliente demonstrou interesse em soluções de TI.', '2024-01-15 09:30:00', 'media', 'fechada'),
(1, 2, 2, 'Reunião de levantamento de requisitos', 'Reunião para entender as necessidades específicas do cliente em infraestrutura de TI.', '2024-01-20 14:00:00', 'alta', 'fechada'),
(1, 3, 5, 'Apresentação de proposta comercial', 'Apresentação da proposta técnica e comercial para modernização da infraestrutura.', '2024-01-25 10:00:00', 'alta', 'em_andamento'),
(2, 2, 1, 'Atendimento telefônico', 'Cliente solicitou informações sobre novos produtos da linha comercial.', '2024-01-18 11:15:00', 'baixa', 'fechada'),
(2, 3, 3, 'Problema com entrega', 'Cliente reportou atraso na entrega de mercadorias. Verificar com logística.', '2024-01-22 16:30:00', 'alta', 'aberta'),
(3, 2, 7, 'Treinamento de operadores', 'Treinamento realizado para operadores de máquinas industriais.', '2024-01-19 08:00:00', 'media', 'fechada'),
(3, 3, 8, 'Manutenção preventiva', 'Agendamento de manutenção preventiva nos equipamentos instalados.', '2024-02-01 13:00:00', 'media', 'aberta');

-- ============================================================================
-- CONFIGURAÇÕES ADICIONAIS
-- ============================================================================

-- Atualizar estatísticas das tabelas para otimização
ANALYZE TABLE usuarios, empresas, tipos_ocorrencia, ocorrencias, historico_ocorrencias, backups, sessoes, logs_sistema;

-- ============================================================================
-- INFORMAÇÕES IMPORTANTES
-- ============================================================================
-- 
-- CREDENCIAIS PADRÃO:
-- Email: admin@empresa.com
-- Senha: admin123
-- 
-- IMPORTANTE: Altere a senha do administrador no primeiro acesso!
-- 
-- TIPOS DE OCORRÊNCIA CRIADOS:
-- - Atendimento, Reunião, Problema, Suporte Técnico
-- - Proposta Comercial, Follow-up, Treinamento, Manutenção
-- - Instalação, Reclamação, Elogio, Cancelamento
-- - Renovação, Orçamento, Visita Técnica
-- 
-- EMPRESAS DE EXEMPLO:
-- - TechSol (Tecnologia)
-- - ComBrasil (Comercial)  
-- - IndModerna (Industrial)
-- 
-- ============================================================================

