<?php
/**
 * Configurações do Banco de Dados
 * Sistema de Gerenciamento de Relacionamento com Empresas
 */

return [
    'default' => 'mysql',
    
    'connections' => [
        'mysql' => [
            'driver' => 'mysql',
            'host' => $_ENV['DB_HOST'] ?? 'localhost',
            'port' => $_ENV['DB_PORT'] ?? '3306',
            'database' => $_ENV['DB_DATABASE'] ?? 'crm_empresas',
            'username' => $_ENV['DB_USERNAME'] ?? 'root',
            'password' => $_ENV['DB_PASSWORD'] ?? '',
            'charset' => 'utf8mb4',
            'collation' => 'utf8mb4_unicode_ci',
            'options' => [
                PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                PDO::ATTR_EMULATE_PREPARES => false,
                PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES utf8mb4 COLLATE utf8mb4_unicode_ci"
            ]
        ]
    ],
    
    // Configurações de cache de consultas
    'query_cache' => [
        'enabled' => true,
        'ttl' => 3600, // 1 hora
        'prefix' => 'crm_query_'
    ],
    
    // Configurações de log de consultas
    'query_log' => [
        'enabled' => $_ENV['APP_DEBUG'] ?? false,
        'slow_query_time' => 2.0, // segundos
        'log_file' => __DIR__ . '/../logs/queries.log'
    ]
];

