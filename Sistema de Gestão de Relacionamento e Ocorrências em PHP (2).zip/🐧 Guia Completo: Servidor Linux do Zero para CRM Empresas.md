# 🐧 Guia Completo: Servidor Linux do Zero para CRM Empresas

**Preparação completa de servidor Linux Ubuntu para o Sistema CRM Empresas**

---

## 📋 Índice

1. [Preparação Inicial do Servidor](#1-preparação-inicial-do-servidor)
2. [Instalação do Sistema Operacional](#2-instalação-do-sistema-operacional)
3. [Configuração Inicial de Segurança](#3-configuração-inicial-de-segurança)
4. [Instalação das Dependências](#4-instalação-das-dependências)
5. [Configuração do MySQL](#5-configuração-do-mysql)
6. [Configuração do Apache](#6-configuração-do-apache)
7. [Configuração do PHP](#7-configuração-do-php)
8. [Instalação do CRM Empresas](#8-instalação-do-crm-empresas)
9. [Configuração de SSL/HTTPS](#9-configuração-de-sslhttps)
10. [Configuração de Backup Automático](#10-configuração-de-backup-automático)
11. [Monitoramento e Manutenção](#11-monitoramento-e-manutenção)
12. [Testes Finais](#12-testes-finais)

---

## 1. Preparação Inicial do Servidor

### 1.1 Requisitos Mínimos de Hardware

**Para Ambiente de Produção:**
- **CPU:** 2 cores (4 cores recomendado)
- **RAM:** 4GB (8GB recomendado)
- **Armazenamento:** 50GB SSD (100GB recomendado)
- **Rede:** Conexão estável com IP fixo

**Para Ambiente de Teste:**
- **CPU:** 1 core
- **RAM:** 2GB
- **Armazenamento:** 20GB
- **Rede:** Conexão básica

### 1.2 Escolha do Provedor

**Provedores Recomendados:**
- **DigitalOcean:** Droplets a partir de $5/mês
- **Vultr:** VPS a partir de $2.50/mês
- **Linode:** Instâncias a partir de $5/mês
- **AWS EC2:** t3.micro (free tier disponível)
- **Google Cloud:** e2-micro (free tier disponível)

### 1.3 Informações Necessárias

Antes de começar, tenha em mãos:
- **Domínio:** exemplo.com (opcional, pode usar IP)
- **Email:** para certificados SSL
- **Senhas:** Defina senhas seguras para root, MySQL, etc.

---

## 2. Instalação do Sistema Operacional

### 2.1 Ubuntu Server 22.04 LTS (Recomendado)

**Opção A: Provedor Cloud (Mais Fácil)**

1. **Criar Instância:**
   ```bash
   # No painel do provedor, selecione:
   # - Ubuntu 22.04 LTS
   # - Tamanho adequado (mínimo 2GB RAM)
   # - Região próxima aos usuários
   # - Chave SSH (recomendado)
   ```

2. **Primeiro Acesso:**
   ```bash
   # Via SSH (substitua pelo IP do seu servidor)
   ssh root@SEU_IP_SERVIDOR
   
   # Ou se configurou usuário específico:
   ssh ubuntu@SEU_IP_SERVIDOR
   ```

**Opção B: Instalação Manual (VPS/Dedicado)**

1. **Download da ISO:**
   ```bash
   # Baixe Ubuntu Server 22.04 LTS
   wget https://releases.ubuntu.com/22.04/ubuntu-22.04.3-live-server-amd64.iso
   ```

2. **Instalação via Console:**
   - Boot pela ISO
   - Selecione idioma (English recomendado para servidores)
   - Configure rede (IP estático recomendado)
   - Particione o disco (usar disco inteiro é adequado)
   - Crie usuário administrativo
   - Instale OpenSSH Server
   - Não instale snaps adicionais por enquanto

### 2.2 Verificação Pós-Instalação

```bash
# Verificar versão do sistema
lsb_release -a

# Verificar recursos disponíveis
free -h
df -h
nproc

# Verificar conectividade
ping -c 4 google.com
```

---

## 3. Configuração Inicial de Segurança

### 3.1 Atualização do Sistema

```bash
# Atualizar lista de pacotes
sudo apt update

# Atualizar sistema completo
sudo apt upgrade -y

# Instalar pacotes essenciais
sudo apt install -y curl wget vim htop unzip git ufw fail2ban
```

### 3.2 Configuração de Usuário

```bash
# Se logado como root, criar usuário administrativo
adduser crm-admin

# Adicionar ao grupo sudo
usermod -aG sudo crm-admin

# Trocar para o novo usuário
su - crm-admin
```

### 3.3 Configuração SSH Segura

```bash
# Editar configuração SSH
sudo vim /etc/ssh/sshd_config

# Configurações recomendadas:
# Port 2222                    # Mudar porta padrão
# PermitRootLogin no          # Desabilitar login root
# PasswordAuthentication no   # Usar apenas chaves SSH
# MaxAuthTries 3              # Limitar tentativas
```

**Configurar Chave SSH (se ainda não fez):**

```bash
# No seu computador local, gerar chave SSH
ssh-keygen -t rsa -b 4096 -C "seu-email@exemplo.com"

# Copiar chave pública para o servidor
ssh-copy-id -p 2222 crm-admin@SEU_IP_SERVIDOR

# Reiniciar SSH no servidor
sudo systemctl restart sshd
```

### 3.4 Configuração do Firewall

```bash
# Configurar UFW (Uncomplicated Firewall)
sudo ufw default deny incoming
sudo ufw default allow outgoing

# Permitir SSH na nova porta
sudo ufw allow 2222/tcp

# Permitir HTTP e HTTPS
sudo ufw allow 80/tcp
sudo ufw allow 443/tcp

# Ativar firewall
sudo ufw enable

# Verificar status
sudo ufw status verbose
```

### 3.5 Configuração do Fail2Ban

```bash
# Criar configuração personalizada
sudo cp /etc/fail2ban/jail.conf /etc/fail2ban/jail.local

# Editar configuração
sudo vim /etc/fail2ban/jail.local

# Configurações importantes:
# [DEFAULT]
# bantime = 3600        # 1 hora de ban
# findtime = 600        # Janela de 10 minutos
# maxretry = 3          # Máximo 3 tentativas
# 
# [sshd]
# enabled = true
# port = 2222           # Sua porta SSH customizada

# Reiniciar fail2ban
sudo systemctl restart fail2ban
sudo systemctl enable fail2ban
```

---

## 4. Instalação das Dependências

### 4.1 Apache Web Server

```bash
# Instalar Apache
sudo apt install -y apache2

# Habilitar módulos necessários
sudo a2enmod rewrite
sudo a2enmod headers
sudo a2enmod deflate
sudo a2enmod expires
sudo a2enmod ssl

# Iniciar e habilitar Apache
sudo systemctl start apache2
sudo systemctl enable apache2

# Verificar status
sudo systemctl status apache2
```

### 4.2 MySQL Server

```bash
# Instalar MySQL
sudo apt install -y mysql-server

# Executar script de segurança
sudo mysql_secure_installation

# Responder as perguntas:
# - Validate Password Plugin: Y (recomendado)
# - Password Strength: 2 (Strong)
# - Remove anonymous users: Y
# - Disallow root login remotely: Y
# - Remove test database: Y
# - Reload privilege tables: Y
```

### 4.3 PHP e Extensões

```bash
# Instalar PHP e extensões necessárias
sudo apt install -y php8.1 php8.1-mysql php8.1-mbstring php8.1-xml php8.1-curl php8.1-zip php8.1-gd php8.1-json php8.1-common php8.1-cli libapache2-mod-php8.1

# Verificar instalação
php -v
php -m | grep -E "(mysql|mbstring|xml|curl|zip|gd)"
```

---

## 5. Configuração do MySQL

### 5.1 Configuração Básica

```bash
# Acessar MySQL como root
sudo mysql -u root -p

# Dentro do MySQL, executar:
```

```sql
-- Criar banco de dados
CREATE DATABASE crm_empresas CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

-- Criar usuário específico
CREATE USER 'crm_user'@'localhost' IDENTIFIED BY 'SuaSenhaSegura123!';

-- Conceder permissões
GRANT ALL PRIVILEGES ON crm_empresas.* TO 'crm_user'@'localhost';

-- Aplicar mudanças
FLUSH PRIVILEGES;

-- Sair
EXIT;
```

### 5.2 Otimização do MySQL

```bash
# Editar configuração do MySQL
sudo vim /etc/mysql/mysql.conf.d/mysqld.cnf

# Adicionar otimizações:
```

```ini
[mysqld]
# Configurações de performance
innodb_buffer_pool_size = 1G
innodb_log_file_size = 256M
innodb_flush_log_at_trx_commit = 2
innodb_flush_method = O_DIRECT

# Configurações de segurança
bind-address = 127.0.0.1
skip-networking = false
local-infile = 0

# Configurações de charset
character-set-server = utf8mb4
collation-server = utf8mb4_unicode_ci

# Logs
general_log = 0
slow_query_log = 1
slow_query_log_file = /var/log/mysql/slow.log
long_query_time = 2
```

```bash
# Reiniciar MySQL
sudo systemctl restart mysql

# Verificar status
sudo systemctl status mysql
```

### 5.3 Backup Inicial

```bash
# Criar diretório para backups
sudo mkdir -p /backup/mysql
sudo chown mysql:mysql /backup/mysql

# Criar script de backup
sudo vim /usr/local/bin/mysql-backup.sh
```

```bash
#!/bin/bash
# Script de backup MySQL

DATE=$(date +%Y%m%d_%H%M%S)
BACKUP_DIR="/backup/mysql"
DB_NAME="crm_empresas"
DB_USER="crm_user"
DB_PASS="SuaSenhaSegura123!"

# Criar backup
mysqldump -u $DB_USER -p$DB_PASS $DB_NAME > $BACKUP_DIR/backup_$DATE.sql

# Manter apenas últimos 7 backups
find $BACKUP_DIR -name "backup_*.sql" -mtime +7 -delete

echo "Backup concluído: backup_$DATE.sql"
```

```bash
# Tornar executável
sudo chmod +x /usr/local/bin/mysql-backup.sh

# Testar backup
sudo /usr/local/bin/mysql-backup.sh
```

---

## 6. Configuração do Apache

### 6.1 Configuração Básica de Segurança

```bash
# Editar configuração principal
sudo vim /etc/apache2/conf-available/security.conf
```

```apache
# Ocultar informações do servidor
ServerTokens Prod
ServerSignature Off

# Headers de segurança
Header always set X-Content-Type-Options nosniff
Header always set X-Frame-Options DENY
Header always set X-XSS-Protection "1; mode=block"
Header always set Referrer-Policy "strict-origin-when-cross-origin"
```

```bash
# Habilitar configuração
sudo a2enconf security

# Desabilitar site padrão
sudo a2dissite 000-default

# Reiniciar Apache
sudo systemctl restart apache2
```

### 6.2 Configuração de Virtual Host

```bash
# Criar diretório para o site
sudo mkdir -p /var/www/crm-empresas

# Definir permissões
sudo chown -R www-data:www-data /var/www/crm-empresas
sudo chmod -R 755 /var/www/crm-empresas

# Criar virtual host
sudo vim /etc/apache2/sites-available/crm-empresas.conf
```

```apache
<VirtualHost *:80>
    ServerName seu-dominio.com
    ServerAlias www.seu-dominio.com
    DocumentRoot /var/www/crm-empresas/public
    
    <Directory /var/www/crm-empresas/public>
        Options -Indexes +FollowSymLinks
        AllowOverride All
        Require all granted
        
        # Proteção de arquivos sensíveis
        <FilesMatch "\.(htaccess|htpasswd|ini|log|sh|inc|bak|sql)$">
            Require all denied
        </FilesMatch>
    </Directory>
    
    # Logs específicos
    ErrorLog ${APACHE_LOG_DIR}/crm-empresas-error.log
    CustomLog ${APACHE_LOG_DIR}/crm-empresas-access.log combined
    LogLevel warn
    
    # Headers de segurança
    Header always set X-Content-Type-Options nosniff
    Header always set X-Frame-Options DENY
    Header always set X-XSS-Protection "1; mode=block"
</VirtualHost>
```

```bash
# Habilitar site
sudo a2ensite crm-empresas

# Testar configuração
sudo apache2ctl configtest

# Reiniciar Apache
sudo systemctl restart apache2
```

---

## 7. Configuração do PHP

### 7.1 Otimização do PHP

```bash
# Editar configuração do PHP
sudo vim /etc/php/8.1/apache2/php.ini

# Configurações importantes:
```

```ini
; Configurações básicas
memory_limit = 256M
max_execution_time = 300
max_input_time = 300
post_max_size = 10M
upload_max_filesize = 10M

; Configurações de sessão
session.cookie_httponly = 1
session.cookie_secure = 0
session.use_only_cookies = 1
session.cookie_samesite = "Strict"

; Configurações de segurança
expose_php = Off
display_errors = Off
log_errors = On
error_log = /var/log/php_errors.log

; Timezone
date.timezone = America/Sao_Paulo

; OPcache (performance)
opcache.enable = 1
opcache.memory_consumption = 128
opcache.interned_strings_buffer = 8
opcache.max_accelerated_files = 4000
opcache.revalidate_freq = 2
opcache.fast_shutdown = 1
```

### 7.2 Configuração de Logs

```bash
# Criar arquivo de log do PHP
sudo touch /var/log/php_errors.log
sudo chown www-data:www-data /var/log/php_errors.log

# Configurar rotação de logs
sudo vim /etc/logrotate.d/php
```

```
/var/log/php_errors.log {
    weekly
    missingok
    rotate 12
    compress
    delaycompress
    notifempty
    create 644 www-data www-data
}
```

```bash
# Reiniciar Apache para aplicar mudanças
sudo systemctl restart apache2

# Verificar configuração PHP
php -i | grep -E "(memory_limit|upload_max_filesize|post_max_size)"
```

---

## 8. Instalação do CRM Empresas

### 8.1 Download e Preparação

```bash
# Navegar para diretório web
cd /var/www

# Clonar ou baixar o projeto (substitua pela URL real)
sudo git clone https://github.com/seu-usuario/crm-empresas.git

# Ou se tiver o arquivo ZIP:
# sudo wget https://github.com/seu-usuario/crm-empresas/archive/main.zip
# sudo unzip main.zip
# sudo mv crm-empresas-main crm-empresas

# Definir permissões corretas
sudo chown -R www-data:www-data /var/www/crm-empresas
sudo chmod -R 755 /var/www/crm-empresas

# Criar diretórios necessários com permissões especiais
sudo mkdir -p /var/www/crm-empresas/storage/{backups,sessions,tmp,logs}
sudo mkdir -p /var/www/crm-empresas/uploads
sudo chmod -R 777 /var/www/crm-empresas/storage
sudo chmod -R 777 /var/www/crm-empresas/uploads
```

### 8.2 Configuração do Banco de Dados

```bash
# Editar configuração do banco
sudo vim /var/www/crm-empresas/config/database.php
```

```php
<?php
return [
    'host' => 'localhost',
    'database' => 'crm_empresas',
    'username' => 'crm_user',
    'password' => 'SuaSenhaSegura123!',
    'charset' => 'utf8mb4',
    'options' => [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES => false,
    ]
];
```

### 8.3 Importação do Banco de Dados

```bash
# Navegar para o diretório do projeto
cd /var/www/crm-empresas

# Importar estrutura do banco
mysql -u crm_user -p crm_empresas < database/migrations/create_tables.sql

# Importar otimizações
mysql -u crm_user -p crm_empresas < database/migrations/optimize_indexes.sql

# Importar dados iniciais
mysql -u crm_user -p crm_empresas < database/seeds/initial_data.sql

# Verificar importação
mysql -u crm_user -p crm_empresas -e "SHOW TABLES;"
```

### 8.4 Configuração da Aplicação

```bash
# Editar configurações gerais
sudo vim /var/www/crm-empresas/config/config.php
```

```php
<?php
// Configurações gerais da aplicação
define('APP_NAME', 'CRM Empresas');
define('APP_URL', 'http://seu-dominio.com'); // Ajustar para seu domínio
define('APP_ROOT', '/var/www/crm-empresas');

// Configurações de sessão
define('SESSION_LIFETIME', 7200); // 2 horas
define('SESSION_NAME', 'CRM_SESSION');

// Configurações de upload
define('MAX_UPLOAD_SIZE', 10 * 1024 * 1024); // 10MB
define('ALLOWED_EXTENSIONS', ['jpg', 'jpeg', 'png', 'gif', 'pdf', 'doc', 'docx', 'xls', 'xlsx']);

// Configurações de segurança
define('CSRF_TOKEN_NAME', 'csrf_token');
define('PASSWORD_MIN_LENGTH', 6);

// Timezone
date_default_timezone_set('America/Sao_Paulo');
```

### 8.5 Teste da Instalação

```bash
# Verificar se o site está acessível
curl -I http://localhost

# Ou se configurou domínio:
curl -I http://seu-dominio.com

# Verificar logs em caso de erro
sudo tail -f /var/log/apache2/crm-empresas-error.log
```

---

## 9. Configuração de SSL/HTTPS

### 9.1 Instalação do Certbot (Let's Encrypt)

```bash
# Instalar Certbot
sudo apt install -y certbot python3-certbot-apache

# Obter certificado SSL (substitua pelo seu domínio)
sudo certbot --apache -d seu-dominio.com -d www.seu-dominio.com

# Seguir as instruções:
# - Fornecer email válido
# - Aceitar termos de uso
# - Escolher redirecionamento automático para HTTPS
```

### 9.2 Configuração Manual de SSL (Alternativa)

Se não usar Let's Encrypt, configure SSL manualmente:

```bash
# Gerar certificado auto-assinado (apenas para teste)
sudo openssl req -x509 -nodes -days 365 -newkey rsa:2048 \
    -keyout /etc/ssl/private/crm-empresas.key \
    -out /etc/ssl/certs/crm-empresas.crt

# Criar virtual host SSL
sudo vim /etc/apache2/sites-available/crm-empresas-ssl.conf
```

```apache
<VirtualHost *:443>
    ServerName seu-dominio.com
    DocumentRoot /var/www/crm-empresas/public
    
    SSLEngine on
    SSLCertificateFile /etc/ssl/certs/crm-empresas.crt
    SSLCertificateKeyFile /etc/ssl/private/crm-empresas.key
    
    # Configurações SSL seguras
    SSLProtocol all -SSLv2 -SSLv3 -TLSv1 -TLSv1.1
    SSLCipherSuite ECDHE-ECDSA-AES128-GCM-SHA256:ECDHE-RSA-AES128-GCM-SHA256
    SSLHonorCipherOrder on
    
    # HSTS
    Header always set Strict-Transport-Security "max-age=63072000; includeSubDomains; preload"
    
    # Resto da configuração igual ao HTTP
    <Directory /var/www/crm-empresas/public>
        Options -Indexes +FollowSymLinks
        AllowOverride All
        Require all granted
    </Directory>
</VirtualHost>
```

```bash
# Habilitar site SSL
sudo a2ensite crm-empresas-ssl
sudo systemctl restart apache2
```

### 9.3 Renovação Automática

```bash
# Testar renovação
sudo certbot renew --dry-run

# Configurar renovação automática via cron
sudo crontab -e

# Adicionar linha:
0 12 * * * /usr/bin/certbot renew --quiet
```

---

## 10. Configuração de Backup Automático

### 10.1 Script de Backup Completo

```bash
# Criar script de backup completo
sudo vim /usr/local/bin/crm-backup-completo.sh
```

```bash
#!/bin/bash
# Backup completo do CRM Empresas

# Configurações
DATE=$(date +%Y%m%d_%H%M%S)
BACKUP_DIR="/backup/crm"
DB_NAME="crm_empresas"
DB_USER="crm_user"
DB_PASS="SuaSenhaSegura123!"
APP_DIR="/var/www/crm-empresas"

# Criar diretório de backup
mkdir -p $BACKUP_DIR

# Backup do banco de dados
echo "Iniciando backup do banco de dados..."
mysqldump -u $DB_USER -p$DB_PASS $DB_NAME > $BACKUP_DIR/db_backup_$DATE.sql

# Backup dos arquivos da aplicação
echo "Iniciando backup dos arquivos..."
tar -czf $BACKUP_DIR/files_backup_$DATE.tar.gz -C /var/www crm-empresas

# Backup apenas dos uploads (mais frequente)
tar -czf $BACKUP_DIR/uploads_backup_$DATE.tar.gz -C $APP_DIR uploads

# Limpeza de backups antigos (manter 30 dias)
find $BACKUP_DIR -name "*backup_*.sql" -mtime +30 -delete
find $BACKUP_DIR -name "*backup_*.tar.gz" -mtime +30 -delete

# Log do backup
echo "$(date): Backup concluído - db_backup_$DATE.sql, files_backup_$DATE.tar.gz" >> $BACKUP_DIR/backup.log

echo "Backup concluído com sucesso!"
```

```bash
# Tornar executável
sudo chmod +x /usr/local/bin/crm-backup-completo.sh

# Criar diretório de backup
sudo mkdir -p /backup/crm
sudo chown www-data:www-data /backup/crm
```

### 10.2 Agendamento via Cron

```bash
# Editar crontab do usuário www-data
sudo crontab -u www-data -e

# Adicionar agendamentos:
# Backup completo diário às 2:00
0 2 * * * /usr/local/bin/crm-backup-completo.sh

# Backup apenas do banco a cada 6 horas
0 */6 * * * /usr/local/bin/mysql-backup.sh

# Backup dos uploads a cada hora (durante horário comercial)
0 8-18 * * 1-5 tar -czf /backup/crm/uploads_$(date +\%H\%M).tar.gz -C /var/www/crm-empresas uploads
```

### 10.3 Backup Remoto (Opcional)

```bash
# Instalar rclone para backup em nuvem
curl https://rclone.org/install.sh | sudo bash

# Configurar rclone (seguir instruções interativas)
rclone config

# Criar script de sincronização
sudo vim /usr/local/bin/sync-backup-cloud.sh
```

```bash
#!/bin/bash
# Sincronizar backups com nuvem

BACKUP_DIR="/backup/crm"
REMOTE_NAME="google-drive" # Nome configurado no rclone

# Sincronizar com nuvem
rclone sync $BACKUP_DIR $REMOTE_NAME:crm-backups

echo "$(date): Backup sincronizado com nuvem" >> $BACKUP_DIR/sync.log
```

---

## 11. Monitoramento e Manutenção

### 11.1 Configuração de Logs

```bash
# Configurar logrotate para logs da aplicação
sudo vim /etc/logrotate.d/crm-empresas
```

```
/var/www/crm-empresas/storage/logs/*.log {
    daily
    missingok
    rotate 30
    compress
    delaycompress
    notifempty
    create 644 www-data www-data
}

/var/log/apache2/crm-empresas-*.log {
    weekly
    missingok
    rotate 12
    compress
    delaycompress
    notifempty
    create 644 root root
    postrotate
        systemctl reload apache2
    endscript
}
```

### 11.2 Script de Monitoramento

```bash
# Criar script de monitoramento
sudo vim /usr/local/bin/crm-monitor.sh
```

```bash
#!/bin/bash
# Script de monitoramento do CRM Empresas

LOG_FILE="/var/log/crm-monitor.log"

# Função de log
log_message() {
    echo "$(date '+%Y-%m-%d %H:%M:%S') - $1" >> $LOG_FILE
}

# Verificar serviços
check_service() {
    if systemctl is-active --quiet $1; then
        log_message "✓ $1 está rodando"
    else
        log_message "✗ $1 está parado - tentando reiniciar"
        systemctl restart $1
    fi
}

# Verificar Apache
check_service apache2

# Verificar MySQL
check_service mysql

# Verificar espaço em disco
DISK_USAGE=$(df / | awk 'NR==2 {print $5}' | sed 's/%//')
if [ $DISK_USAGE -gt 80 ]; then
    log_message "⚠ Espaço em disco baixo: ${DISK_USAGE}%"
fi

# Verificar conectividade do site
if curl -f -s http://localhost > /dev/null; then
    log_message "✓ Site respondendo"
else
    log_message "✗ Site não está respondendo"
fi

# Verificar conexão com banco
if mysql -u crm_user -p'SuaSenhaSegura123!' -e "SELECT 1" crm_empresas > /dev/null 2>&1; then
    log_message "✓ Banco de dados conectando"
else
    log_message "✗ Problema na conexão com banco"
fi
```

```bash
# Tornar executável
sudo chmod +x /usr/local/bin/crm-monitor.sh

# Agendar monitoramento a cada 5 minutos
sudo crontab -e
# Adicionar:
*/5 * * * * /usr/local/bin/crm-monitor.sh
```

### 11.3 Configuração de Alertas por Email

```bash
# Instalar mailutils
sudo apt install -y mailutils

# Configurar postfix (escolher "Internet Site")
sudo dpkg-reconfigure postfix

# Criar script de alerta
sudo vim /usr/local/bin/crm-alert.sh
```

```bash
#!/bin/bash
# Script de alertas por email

EMAIL="admin@seu-dominio.com"
SUBJECT="Alerta CRM Empresas"

# Verificar se há problemas críticos
if ! systemctl is-active --quiet apache2; then
    echo "Apache está parado no servidor $(hostname)" | mail -s "$SUBJECT - Apache Parado" $EMAIL
fi

if ! systemctl is-active --quiet mysql; then
    echo "MySQL está parado no servidor $(hostname)" | mail -s "$SUBJECT - MySQL Parado" $EMAIL
fi

# Verificar espaço em disco
DISK_USAGE=$(df / | awk 'NR==2 {print $5}' | sed 's/%//')
if [ $DISK_USAGE -gt 90 ]; then
    echo "Espaço em disco crítico: ${DISK_USAGE}% no servidor $(hostname)" | mail -s "$SUBJECT - Disco Cheio" $EMAIL
fi
```

---

## 12. Testes Finais

### 12.1 Teste de Conectividade

```bash
# Testar acesso HTTP
curl -I http://seu-dominio.com

# Testar acesso HTTPS
curl -I https://seu-dominio.com

# Testar redirecionamento
curl -I http://seu-dominio.com | grep Location
```

### 12.2 Teste de Funcionalidades

```bash
# Testar conexão com banco via PHP
php -r "
include '/var/www/crm-empresas/config/database.php';
try {
    \$pdo = new PDO(\"mysql:host={\$config['host']};dbname={\$config['database']}\", \$config['username'], \$config['password']);
    echo 'Conexão com banco: OK\n';
} catch (Exception \$e) {
    echo 'Erro na conexão: ' . \$e->getMessage() . '\n';
}
"

# Testar permissões de escrita
sudo -u www-data touch /var/www/crm-empresas/storage/test.txt
if [ $? -eq 0 ]; then
    echo "Permissões de escrita: OK"
    sudo rm /var/www/crm-empresas/storage/test.txt
else
    echo "Problema com permissões de escrita"
fi
```

### 12.3 Teste de Performance

```bash
# Instalar ferramentas de teste
sudo apt install -y apache2-utils

# Teste de carga básico
ab -n 100 -c 10 http://seu-dominio.com/

# Verificar tempo de resposta
curl -o /dev/null -s -w "Tempo total: %{time_total}s\n" http://seu-dominio.com/
```

### 12.4 Verificação de Segurança

```bash
# Verificar headers de segurança
curl -I https://seu-dominio.com | grep -E "(X-Frame-Options|X-XSS-Protection|X-Content-Type-Options)"

# Verificar SSL
openssl s_client -connect seu-dominio.com:443 -servername seu-dominio.com < /dev/null

# Testar firewall
sudo ufw status verbose
```

---

## 🎯 Checklist Final

### ✅ Sistema Operacional
- [ ] Ubuntu 22.04 LTS instalado
- [ ] Sistema atualizado
- [ ] Usuário administrativo criado
- [ ] SSH configurado com chave

### ✅ Segurança
- [ ] Firewall UFW configurado
- [ ] Fail2Ban instalado e configurado
- [ ] SSH na porta customizada
- [ ] Root login desabilitado

### ✅ Serviços Web
- [ ] Apache instalado e configurado
- [ ] MySQL instalado e seguro
- [ ] PHP 8.1 com extensões
- [ ] Virtual host configurado

### ✅ CRM Empresas
- [ ] Código fonte instalado
- [ ] Banco de dados importado
- [ ] Permissões configuradas
- [ ] Configurações ajustadas

### ✅ SSL/HTTPS
- [ ] Certificado SSL instalado
- [ ] Redirecionamento HTTP→HTTPS
- [ ] Headers de segurança
- [ ] Renovação automática

### ✅ Backup e Monitoramento
- [ ] Scripts de backup criados
- [ ] Cron jobs configurados
- [ ] Monitoramento ativo
- [ ] Alertas por email

### ✅ Testes
- [ ] Site acessível via HTTP/HTTPS
- [ ] Login no sistema funciona
- [ ] Banco de dados conecta
- [ ] Uploads funcionam
- [ ] Backups executam

---

## 🚀 Primeiro Acesso

Após completar todos os passos:

1. **Acesse o sistema:**
   ```
   https://seu-dominio.com
   ```

2. **Faça login com:**
   - **Email:** admin@admin.com
   - **Senha:** admin123

3. **IMPORTANTE:** Altere a senha imediatamente!

4. **Configure:**
   - Dados da empresa
   - Usuários adicionais
   - Tipos de ocorrência
   - Backup automático via interface

---

## 📞 Suporte e Manutenção

### Comandos Úteis de Manutenção

```bash
# Verificar status dos serviços
sudo systemctl status apache2 mysql

# Ver logs em tempo real
sudo tail -f /var/log/apache2/crm-empresas-error.log

# Verificar espaço em disco
df -h

# Verificar uso de memória
free -h

# Verificar processos
htop

# Reiniciar serviços se necessário
sudo systemctl restart apache2
sudo systemctl restart mysql
```

### Backup Manual de Emergência

```bash
# Backup rápido do banco
mysqldump -u crm_user -p crm_empresas > backup_emergencia_$(date +%Y%m%d).sql

# Backup dos arquivos
tar -czf backup_arquivos_$(date +%Y%m%d).tar.gz /var/www/crm-empresas
```

---

**🎉 Parabéns! Seu servidor Linux está pronto para o CRM Empresas!**

Este guia cobriu desde a instalação básica até a configuração avançada de produção. Seu sistema agora está seguro, otimizado e pronto para uso empresarial.

**Desenvolvido por:** Manus AI  
**Versão do Guia:** 1.0.0

