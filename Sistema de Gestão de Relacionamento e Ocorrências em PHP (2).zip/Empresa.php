<?php
/**
 * Modelo Empresa
 * Sistema de Gerenciamento de Relacionamento com Empresas
 */

class Empresa
{
    private $db;
    
    public function __construct()
    {
        $this->db = Database::getInstance();
    }
    
    /**
     * Busca todas as empresas
     */
    public function all($ativo = null)
    {
        $sql = "SELECT * FROM empresas";
        $params = [];
        
        if ($ativo !== null) {
            $sql .= " WHERE ativo = ?";
            $params[] = $ativo;
        }
        
        $sql .= " ORDER BY razao_social";
        
        return $this->db->select($sql, $params);
    }
    
    /**
     * Busca empresa por ID
     */
    public function find($id)
    {
        return $this->db->selectOne(
            "SELECT * FROM empresas WHERE id = ?",
            [$id]
        );
    }
    
    /**
     * Busca empresa por CNPJ
     */
    public function findByCnpj($cnpj)
    {
        // Limpar CNPJ (apenas números)
        $cnpj = preg_replace('/[^0-9]/', '', $cnpj);
        
        return $this->db->selectOne(
            "SELECT * FROM empresas WHERE REPLACE(REPLACE(REPLACE(cnpj, '.', ''), '/', ''), '-', '') = ?",
            [$cnpj]
        );
    }
    
    /**
     * Cria uma nova empresa
     */
    public function create($data)
    {
        // Validar dados
        $validator = Validator::make($data, [
            'razao_social' => 'required|min:2|max:200',
            'cnpj' => 'cnpj|unique:empresas,cnpj',
            'email' => 'email',
            'telefone' => 'phone',
            'cep' => 'cep',
            'estado' => 'max:2',
            'cidade' => 'max:100'
        ]);
        
        if (!$validator->validate()) {
            throw new Exception('Dados inválidos: ' . implode(', ', array_map(function($errors) {
                return implode(', ', $errors);
            }, $validator->errors())));
        }
        
        // Limpar e formatar dados
        $data = $this->sanitizeData($data);
        
        // Inserir no banco
        $id = $this->db->insert(
            "INSERT INTO empresas (
                razao_social, nome_fantasia, cnpj, inscricao_estadual,
                endereco, cidade, estado, cep, telefone, email, site,
                contato_principal, cargo_contato, observacoes, ativo, usuario_cadastro
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
            [
                $data['razao_social'],
                $data['nome_fantasia'] ?? null,
                $data['cnpj'] ?? null,
                $data['inscricao_estadual'] ?? null,
                $data['endereco'] ?? null,
                $data['cidade'] ?? null,
                $data['estado'] ?? null,
                $data['cep'] ?? null,
                $data['telefone'] ?? null,
                $data['email'] ?? null,
                $data['site'] ?? null,
                $data['contato_principal'] ?? null,
                $data['cargo_contato'] ?? null,
                $data['observacoes'] ?? null,
                $data['ativo'] ?? true,
                Auth::id()
            ]
        );
        
        return $this->find($id);
    }
    
    /**
     * Atualiza uma empresa
     */
    public function update($id, $data)
    {
        // Validar dados
        $validator = Validator::make($data, [
            'razao_social' => 'required|min:2|max:200',
            'cnpj' => 'cnpj|unique:empresas,cnpj,' . $id,
            'email' => 'email',
            'telefone' => 'phone',
            'cep' => 'cep',
            'estado' => 'max:2',
            'cidade' => 'max:100'
        ]);
        
        if (!$validator->validate()) {
            throw new Exception('Dados inválidos: ' . implode(', ', array_map(function($errors) {
                return implode(', ', $errors);
            }, $validator->errors())));
        }
        
        // Limpar e formatar dados
        $data = $this->sanitizeData($data);
        
        // Atualizar no banco
        $this->db->update(
            "UPDATE empresas SET 
                razao_social = ?, nome_fantasia = ?, cnpj = ?, inscricao_estadual = ?,
                endereco = ?, cidade = ?, estado = ?, cep = ?, telefone = ?, email = ?, site = ?,
                contato_principal = ?, cargo_contato = ?, observacoes = ?, ativo = ?
             WHERE id = ?",
            [
                $data['razao_social'],
                $data['nome_fantasia'] ?? null,
                $data['cnpj'] ?? null,
                $data['inscricao_estadual'] ?? null,
                $data['endereco'] ?? null,
                $data['cidade'] ?? null,
                $data['estado'] ?? null,
                $data['cep'] ?? null,
                $data['telefone'] ?? null,
                $data['email'] ?? null,
                $data['site'] ?? null,
                $data['contato_principal'] ?? null,
                $data['cargo_contato'] ?? null,
                $data['observacoes'] ?? null,
                $data['ativo'] ?? true,
                $id
            ]
        );
        
        return $this->find($id);
    }
    
    /**
     * Exclui uma empresa (soft delete)
     */
    public function delete($id)
    {
        // Verificar se há ocorrências vinculadas
        $ocorrencias = $this->db->selectOne(
            "SELECT COUNT(*) as total FROM ocorrencias WHERE empresa_id = ?",
            [$id]
        );
        
        if ($ocorrencias['total'] > 0) {
            throw new Exception('Não é possível excluir empresa com ocorrências vinculadas. Desative a empresa em vez de excluí-la.');
        }
        
        return $this->db->update(
            "UPDATE empresas SET ativo = 0 WHERE id = ?",
            [$id]
        );
    }
    
    /**
     * Exclui permanentemente uma empresa
     */
    public function forceDelete($id)
    {
        // Verificar se há ocorrências vinculadas
        $ocorrencias = $this->db->selectOne(
            "SELECT COUNT(*) as total FROM ocorrencias WHERE empresa_id = ?",
            [$id]
        );
        
        if ($ocorrencias['total'] > 0) {
            throw new Exception('Não é possível excluir empresa com ocorrências vinculadas.');
        }
        
        return $this->db->delete(
            "DELETE FROM empresas WHERE id = ?",
            [$id]
        );
    }
    
    /**
     * Alterna o status ativo/inativo
     */
    public function toggleStatus($id)
    {
        $empresa = $this->find($id);
        
        if (!$empresa) {
            throw new Exception('Empresa não encontrada');
        }
        
        $novoStatus = !$empresa['ativo'];
        
        $this->db->update(
            "UPDATE empresas SET ativo = ? WHERE id = ?",
            [$novoStatus, $id]
        );
        
        return $novoStatus;
    }
    
    /**
     * Busca empresas com filtros
     */
    public function search($filtros = [])
    {
        $sql = "SELECT * FROM empresas WHERE 1=1";
        $params = [];
        
        if (!empty($filtros['razao_social'])) {
            $sql .= " AND razao_social LIKE ?";
            $params[] = '%' . $filtros['razao_social'] . '%';
        }
        
        if (!empty($filtros['nome_fantasia'])) {
            $sql .= " AND nome_fantasia LIKE ?";
            $params[] = '%' . $filtros['nome_fantasia'] . '%';
        }
        
        if (!empty($filtros['cnpj'])) {
            $cnpj = preg_replace('/[^0-9]/', '', $filtros['cnpj']);
            $sql .= " AND REPLACE(REPLACE(REPLACE(cnpj, '.', ''), '/', ''), '-', '') LIKE ?";
            $params[] = '%' . $cnpj . '%';
        }
        
        if (!empty($filtros['cidade'])) {
            $sql .= " AND cidade LIKE ?";
            $params[] = '%' . $filtros['cidade'] . '%';
        }
        
        if (!empty($filtros['estado'])) {
            $sql .= " AND estado = ?";
            $params[] = $filtros['estado'];
        }
        
        if (!empty($filtros['contato_principal'])) {
            $sql .= " AND contato_principal LIKE ?";
            $params[] = '%' . $filtros['contato_principal'] . '%';
        }
        
        if (isset($filtros['ativo'])) {
            $sql .= " AND ativo = ?";
            $params[] = $filtros['ativo'];
        }
        
        // Busca textual geral
        if (!empty($filtros['busca'])) {
            $sql .= " AND (
                razao_social LIKE ? OR 
                nome_fantasia LIKE ? OR 
                contato_principal LIKE ? OR
                REPLACE(REPLACE(REPLACE(cnpj, '.', ''), '/', ''), '-', '') LIKE ?
            )";
            $termo = '%' . $filtros['busca'] . '%';
            $cnpjTermo = '%' . preg_replace('/[^0-9]/', '', $filtros['busca']) . '%';
            $params = array_merge($params, [$termo, $termo, $termo, $cnpjTermo]);
        }
        
        $sql .= " ORDER BY razao_social";
        
        return $this->db->select($sql, $params);
    }
    
    /**
     * Busca empresas para autocomplete
     */
    public function autocomplete($termo, $limit = 10)
    {
        $sql = "
            SELECT id, razao_social, nome_fantasia, cnpj
            FROM empresas 
            WHERE ativo = 1 AND (
                razao_social LIKE ? OR 
                nome_fantasia LIKE ? OR
                REPLACE(REPLACE(REPLACE(cnpj, '.', ''), '/', ''), '-', '') LIKE ?
            )
            ORDER BY razao_social
            LIMIT ?
        ";
        
        $termoBusca = '%' . $termo . '%';
        $cnpjBusca = '%' . preg_replace('/[^0-9]/', '', $termo) . '%';
        
        return $this->db->select($sql, [$termoBusca, $termoBusca, $cnpjBusca, $limit]);
    }
    
    /**
     * Conta total de empresas
     */
    public function count($ativo = null)
    {
        $sql = "SELECT COUNT(*) as total FROM empresas";
        $params = [];
        
        if ($ativo !== null) {
            $sql .= " WHERE ativo = ?";
            $params[] = $ativo;
        }
        
        $result = $this->db->selectOne($sql, $params);
        return $result['total'];
    }
    
    /**
     * Estatísticas de empresas
     */
    public function stats()
    {
        return [
            'total' => $this->count(),
            'ativas' => $this->count(true),
            'inativas' => $this->count(false),
            'com_ocorrencias' => $this->countComOcorrencias(),
            'sem_ocorrencias' => $this->countSemOcorrencias()
        ];
    }
    
    /**
     * Empresas com mais ocorrências
     */
    public function ranking($limit = 10)
    {
        return $this->db->select(
            "SELECT 
                e.id, e.razao_social, e.nome_fantasia, e.contato_principal,
                COUNT(o.id) as total_ocorrencias,
                COUNT(CASE WHEN o.status = 'aberta' THEN 1 END) as ocorrencias_abertas,
                COUNT(CASE WHEN o.status = 'fechada' THEN 1 END) as ocorrencias_fechadas,
                MAX(o.data_ocorrencia) as ultima_ocorrencia
             FROM empresas e
             LEFT JOIN ocorrencias o ON e.id = o.empresa_id
             WHERE e.ativo = 1
             GROUP BY e.id, e.razao_social, e.nome_fantasia, e.contato_principal
             ORDER BY total_ocorrencias DESC
             LIMIT ?",
            [$limit]
        );
    }
    
    /**
     * Busca ocorrências de uma empresa
     */
    public function ocorrencias($empresaId, $limit = null)
    {
        $sql = "
            SELECT o.*, t.nome as tipo_nome, t.cor as tipo_cor, u.nome as usuario_nome
            FROM ocorrencias o
            INNER JOIN tipos_ocorrencia t ON o.tipo_ocorrencia_id = t.id
            INNER JOIN usuarios u ON o.usuario_id = u.id
            WHERE o.empresa_id = ?
            ORDER BY o.data_ocorrencia DESC
        ";
        
        $params = [$empresaId];
        
        if ($limit) {
            $sql .= " LIMIT ?";
            $params[] = $limit;
        }
        
        return $this->db->select($sql, $params);
    }
    
    /**
     * Estatísticas de uma empresa específica
     */
    public function estatisticasEmpresa($empresaId)
    {
        $ocorrencias = $this->db->selectOne(
            "SELECT 
                COUNT(*) as total,
                COUNT(CASE WHEN status = 'aberta' THEN 1 END) as abertas,
                COUNT(CASE WHEN status = 'em_andamento' THEN 1 END) as em_andamento,
                COUNT(CASE WHEN status = 'resolvida' THEN 1 END) as resolvidas,
                COUNT(CASE WHEN status = 'fechada' THEN 1 END) as fechadas,
                MIN(data_ocorrencia) as primeira_ocorrencia,
                MAX(data_ocorrencia) as ultima_ocorrencia
             FROM ocorrencias 
             WHERE empresa_id = ?",
            [$empresaId]
        );
        
        $porTipo = $this->db->select(
            "SELECT t.nome, t.cor, COUNT(o.id) as total
             FROM tipos_ocorrencia t
             LEFT JOIN ocorrencias o ON t.id = o.tipo_ocorrencia_id AND o.empresa_id = ?
             GROUP BY t.id, t.nome, t.cor
             HAVING total > 0
             ORDER BY total DESC",
            [$empresaId]
        );
        
        return [
            'ocorrencias' => $ocorrencias,
            'por_tipo' => $porTipo
        ];
    }
    
    /**
     * Métodos auxiliares privados
     */
    private function sanitizeData($data)
    {
        // Limpar CNPJ
        if (!empty($data['cnpj'])) {
            $data['cnpj'] = $this->formatCnpj($data['cnpj']);
        }
        
        // Limpar telefone
        if (!empty($data['telefone'])) {
            $data['telefone'] = $this->formatTelefone($data['telefone']);
        }
        
        // Limpar CEP
        if (!empty($data['cep'])) {
            $data['cep'] = $this->formatCep($data['cep']);
        }
        
        // Limpar URL do site
        if (!empty($data['site'])) {
            $data['site'] = $this->formatUrl($data['site']);
        }
        
        // Converter estado para maiúsculo
        if (!empty($data['estado'])) {
            $data['estado'] = strtoupper($data['estado']);
        }
        
        return $data;
    }
    
    private function formatCnpj($cnpj)
    {
        $cnpj = preg_replace('/[^0-9]/', '', $cnpj);
        if (strlen($cnpj) === 14) {
            return substr($cnpj, 0, 2) . '.' . substr($cnpj, 2, 3) . '.' . 
                   substr($cnpj, 5, 3) . '/' . substr($cnpj, 8, 4) . '-' . substr($cnpj, 12, 2);
        }
        return $cnpj;
    }
    
    private function formatTelefone($telefone)
    {
        $telefone = preg_replace('/[^0-9]/', '', $telefone);
        if (strlen($telefone) === 11) {
            return '(' . substr($telefone, 0, 2) . ') ' . substr($telefone, 2, 5) . '-' . substr($telefone, 7, 4);
        } elseif (strlen($telefone) === 10) {
            return '(' . substr($telefone, 0, 2) . ') ' . substr($telefone, 2, 4) . '-' . substr($telefone, 6, 4);
        }
        return $telefone;
    }
    
    private function formatCep($cep)
    {
        $cep = preg_replace('/[^0-9]/', '', $cep);
        if (strlen($cep) === 8) {
            return substr($cep, 0, 5) . '-' . substr($cep, 5, 3);
        }
        return $cep;
    }
    
    private function formatUrl($url)
    {
        if (!preg_match('/^https?:\/\//', $url)) {
            return 'http://' . $url;
        }
        return $url;
    }
    
    private function countComOcorrencias()
    {
        $result = $this->db->selectOne(
            "SELECT COUNT(DISTINCT empresa_id) as total FROM ocorrencias"
        );
        return $result['total'];
    }
    
    private function countSemOcorrencias()
    {
        $result = $this->db->selectOne(
            "SELECT COUNT(*) as total FROM empresas e 
             WHERE e.ativo = 1 AND NOT EXISTS (
                 SELECT 1 FROM ocorrencias o WHERE o.empresa_id = e.id
             )"
        );
        return $result['total'];
    }
}

