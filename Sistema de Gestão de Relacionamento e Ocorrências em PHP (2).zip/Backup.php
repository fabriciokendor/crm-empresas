<?php
/**
 * Modelo Backup
 * Sistema de Gerenciamento de Relacionamento com Empresas
 */

class Backup
{
    private $db;
    private $backupDir;
    
    public function __construct()
    {
        $this->db = Database::getInstance();
        $this->backupDir = APP_ROOT . '/storage/backups/';
        
        // Criar diretório de backup se não existir
        if (!is_dir($this->backupDir)) {
            mkdir($this->backupDir, 0755, true);
        }
    }
    
    /**
     * Lista todos os backups
     */
    public function all()
    {
        return $this->db->select(
            "SELECT * FROM backups ORDER BY created_at DESC"
        );
    }
    
    /**
     * Busca backup por ID
     */
    public function find($id)
    {
        return $this->db->selectOne(
            "SELECT * FROM backups WHERE id = ?",
            [$id]
        );
    }
    
    /**
     * Cria um novo backup
     */
    public function create($tipo = 'manual', $descricao = null)
    {
        try {
            $filename = $this->generateBackupFilename();
            $filepath = $this->backupDir . $filename;
            
            // Criar backup do banco de dados
            $this->createDatabaseBackup($filepath);
            
            // Verificar se o arquivo foi criado
            if (!file_exists($filepath)) {
                throw new Exception('Falha ao criar arquivo de backup');
            }
            
            $filesize = filesize($filepath);
            
            // Registrar backup no banco
            $id = $this->db->insert(
                "INSERT INTO backups (filename, filepath, filesize, tipo, descricao, usuario_id, status) 
                 VALUES (?, ?, ?, ?, ?, ?, ?)",
                [
                    $filename,
                    $filepath,
                    $filesize,
                    $tipo,
                    $descricao,
                    Auth::id(),
                    'concluido'
                ]
            );
            
            // Limpar backups antigos se necessário
            $this->cleanOldBackups();
            
            return $this->find($id);
            
        } catch (Exception $e) {
            // Registrar falha no banco se possível
            try {
                $this->db->insert(
                    "INSERT INTO backups (filename, tipo, descricao, usuario_id, status, erro) 
                     VALUES (?, ?, ?, ?, ?, ?)",
                    [
                        $filename ?? 'backup_' . date('Y-m-d_H-i-s') . '.sql',
                        $tipo,
                        $descricao,
                        Auth::id(),
                        'falhou',
                        $e->getMessage()
                    ]
                );
            } catch (Exception $dbError) {
                // Ignorar erro de banco se não conseguir registrar
            }
            
            throw $e;
        }
    }
    
    /**
     * Restaura um backup
     */
    public function restore($backupId)
    {
        $backup = $this->find($backupId);
        
        if (!$backup) {
            throw new Exception('Backup não encontrado');
        }
        
        if ($backup['status'] !== 'concluido') {
            throw new Exception('Backup não está disponível para restauração');
        }
        
        if (!file_exists($backup['filepath'])) {
            throw new Exception('Arquivo de backup não encontrado');
        }
        
        try {
            // Criar backup de segurança antes da restauração
            $this->create('pre_restauracao', 'Backup automático antes da restauração');
            
            // Restaurar banco de dados
            $this->restoreDatabase($backup['filepath']);
            
            // Registrar restauração
            $this->db->insert(
                "INSERT INTO logs_sistema (usuario_id, acao, tabela_afetada, registro_id, detalhes) 
                 VALUES (?, ?, ?, ?, ?)",
                [
                    Auth::id(),
                    'RESTORE',
                    'backups',
                    $backupId,
                    json_encode(['backup_filename' => $backup['filename']])
                ]
            );
            
            return true;
            
        } catch (Exception $e) {
            throw new Exception('Falha na restauração: ' . $e->getMessage());
        }
    }
    
    /**
     * Exclui um backup
     */
    public function delete($id)
    {
        $backup = $this->find($id);
        
        if (!$backup) {
            throw new Exception('Backup não encontrado');
        }
        
        // Remover arquivo físico
        if (file_exists($backup['filepath'])) {
            unlink($backup['filepath']);
        }
        
        // Remover registro do banco
        return $this->db->delete(
            "DELETE FROM backups WHERE id = ?",
            [$id]
        );
    }
    
    /**
     * Programa backup automático
     */
    public function scheduleAutoBackup($frequencia = 'diario', $hora = '02:00')
    {
        // Esta função seria integrada com cron jobs do sistema
        // Por enquanto, apenas registra a configuração
        
        $config = [
            'frequencia' => $frequencia,
            'hora' => $hora,
            'ativo' => true,
            'proximo_backup' => $this->calculateNextBackup($frequencia, $hora)
        ];
        
        // Salvar configuração (poderia ser em uma tabela separada)
        file_put_contents(
            APP_ROOT . '/storage/backup_config.json',
            json_encode($config, JSON_PRETTY_PRINT)
        );
        
        return $config;
    }
    
    /**
     * Verifica integridade de um backup
     */
    public function verifyIntegrity($backupId)
    {
        $backup = $this->find($backupId);
        
        if (!$backup) {
            throw new Exception('Backup não encontrado');
        }
        
        if (!file_exists($backup['filepath'])) {
            return [
                'valido' => false,
                'erro' => 'Arquivo não encontrado'
            ];
        }
        
        // Verificar tamanho do arquivo
        $currentSize = filesize($backup['filepath']);
        if ($currentSize !== (int)$backup['filesize']) {
            return [
                'valido' => false,
                'erro' => 'Tamanho do arquivo não confere'
            ];
        }
        
        // Verificar se é um arquivo SQL válido
        $content = file_get_contents($backup['filepath'], false, null, 0, 1000);
        if (strpos($content, '-- MySQL dump') === false && strpos($content, 'CREATE TABLE') === false) {
            return [
                'valido' => false,
                'erro' => 'Arquivo não parece ser um backup válido'
            ];
        }
        
        return [
            'valido' => true,
            'tamanho' => $currentSize,
            'data_verificacao' => date('Y-m-d H:i:s')
        ];
    }
    
    /**
     * Estatísticas de backup
     */
    public function stats()
    {
        $total = $this->db->selectOne("SELECT COUNT(*) as total FROM backups");
        $concluidos = $this->db->selectOne("SELECT COUNT(*) as total FROM backups WHERE status = 'concluido'");
        $falharam = $this->db->selectOne("SELECT COUNT(*) as total FROM backups WHERE status = 'falhou'");
        
        $tamanhoTotal = $this->db->selectOne(
            "SELECT SUM(filesize) as total FROM backups WHERE status = 'concluido'"
        );
        
        $ultimoBackup = $this->db->selectOne(
            "SELECT created_at FROM backups WHERE status = 'concluido' ORDER BY created_at DESC LIMIT 1"
        );
        
        return [
            'total' => $total['total'],
            'concluidos' => $concluidos['total'],
            'falharam' => $falharam['total'],
            'tamanho_total' => $tamanhoTotal['total'] ?? 0,
            'ultimo_backup' => $ultimoBackup['created_at'] ?? null,
            'espaco_usado' => $this->getDirectorySize($this->backupDir)
        ];
    }
    
    /**
     * Métodos privados
     */
    private function generateBackupFilename()
    {
        return 'backup_' . date('Y-m-d_H-i-s') . '_' . uniqid() . '.sql';
    }
    
    private function createDatabaseBackup($filepath)
    {
        $config = include APP_ROOT . '/config/database.php';
        
        $host = $config['host'];
        $database = $config['database'];
        $username = $config['username'];
        $password = $config['password'];
        
        // Comando mysqldump
        $command = sprintf(
            'mysqldump --host=%s --user=%s --password=%s --single-transaction --routines --triggers %s > %s 2>&1',
            escapeshellarg($host),
            escapeshellarg($username),
            escapeshellarg($password),
            escapeshellarg($database),
            escapeshellarg($filepath)
        );
        
        // Executar comando
        $output = [];
        $returnCode = 0;
        exec($command, $output, $returnCode);
        
        if ($returnCode !== 0) {
            throw new Exception('Falha no mysqldump: ' . implode("\n", $output));
        }
        
        // Verificar se o arquivo foi criado e tem conteúdo
        if (!file_exists($filepath) || filesize($filepath) < 100) {
            throw new Exception('Arquivo de backup não foi criado corretamente');
        }
    }
    
    private function restoreDatabase($filepath)
    {
        $config = include APP_ROOT . '/config/database.php';
        
        $host = $config['host'];
        $database = $config['database'];
        $username = $config['username'];
        $password = $config['password'];
        
        // Comando mysql para restauração
        $command = sprintf(
            'mysql --host=%s --user=%s --password=%s %s < %s 2>&1',
            escapeshellarg($host),
            escapeshellarg($username),
            escapeshellarg($password),
            escapeshellarg($database),
            escapeshellarg($filepath)
        );
        
        // Executar comando
        $output = [];
        $returnCode = 0;
        exec($command, $output, $returnCode);
        
        if ($returnCode !== 0) {
            throw new Exception('Falha na restauração: ' . implode("\n", $output));
        }
    }
    
    private function cleanOldBackups($maxBackups = 10)
    {
        // Manter apenas os últimos X backups automáticos
        $oldBackups = $this->db->select(
            "SELECT id, filepath FROM backups 
             WHERE tipo = 'automatico' AND status = 'concluido'
             ORDER BY created_at DESC 
             LIMIT 999 OFFSET ?",
            [$maxBackups]
        );
        
        foreach ($oldBackups as $backup) {
            $this->delete($backup['id']);
        }
    }
    
    private function calculateNextBackup($frequencia, $hora)
    {
        $now = new DateTime();
        $next = clone $now;
        
        switch ($frequencia) {
            case 'diario':
                $next->modify('+1 day');
                break;
            case 'semanal':
                $next->modify('+1 week');
                break;
            case 'mensal':
                $next->modify('+1 month');
                break;
            default:
                $next->modify('+1 day');
        }
        
        // Definir hora
        list($h, $m) = explode(':', $hora);
        $next->setTime((int)$h, (int)$m, 0);
        
        return $next->format('Y-m-d H:i:s');
    }
    
    private function getDirectorySize($dir)
    {
        $size = 0;
        
        if (is_dir($dir)) {
            $files = glob($dir . '/*');
            foreach ($files as $file) {
                if (is_file($file)) {
                    $size += filesize($file);
                }
            }
        }
        
        return $size;
    }
    
    /**
     * Formata tamanho de arquivo
     */
    public static function formatFileSize($bytes)
    {
        $units = ['B', 'KB', 'MB', 'GB', 'TB'];
        
        for ($i = 0; $bytes > 1024 && $i < count($units) - 1; $i++) {
            $bytes /= 1024;
        }
        
        return round($bytes, 2) . ' ' . $units[$i];
    }
    
    /**
     * Exporta backup para download
     */
    public function download($backupId)
    {
        $backup = $this->find($backupId);
        
        if (!$backup) {
            throw new Exception('Backup não encontrado');
        }
        
        if (!file_exists($backup['filepath'])) {
            throw new Exception('Arquivo de backup não encontrado');
        }
        
        // Headers para download
        header('Content-Type: application/octet-stream');
        header('Content-Disposition: attachment; filename="' . $backup['filename'] . '"');
        header('Content-Length: ' . filesize($backup['filepath']));
        header('Cache-Control: no-cache, must-revalidate');
        header('Expires: 0');
        
        // Enviar arquivo
        readfile($backup['filepath']);
        exit;
    }
    
    /**
     * Upload de backup para restauração
     */
    public function upload($file)
    {
        if ($file['error'] !== UPLOAD_ERR_OK) {
            throw new Exception('Erro no upload do arquivo');
        }
        
        // Verificar extensão
        $extension = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
        if ($extension !== 'sql') {
            throw new Exception('Apenas arquivos .sql são permitidos');
        }
        
        // Verificar tamanho (máximo 100MB)
        if ($file['size'] > 100 * 1024 * 1024) {
            throw new Exception('Arquivo muito grande (máximo 100MB)');
        }
        
        // Gerar nome único
        $filename = 'upload_' . date('Y-m-d_H-i-s') . '_' . uniqid() . '.sql';
        $filepath = $this->backupDir . $filename;
        
        // Mover arquivo
        if (!move_uploaded_file($file['tmp_name'], $filepath)) {
            throw new Exception('Falha ao salvar arquivo');
        }
        
        // Registrar no banco
        $id = $this->db->insert(
            "INSERT INTO backups (filename, filepath, filesize, tipo, descricao, usuario_id, status) 
             VALUES (?, ?, ?, ?, ?, ?, ?)",
            [
                $filename,
                $filepath,
                filesize($filepath),
                'upload',
                'Backup enviado via upload',
                Auth::id(),
                'concluido'
            ]
        );
        
        return $this->find($id);
    }
}

