# Sistema de Gerenciamento de Relacionamento com Empresas
## Especificação de Requisitos Funcionais

### 1. VISÃO GERAL DO SISTEMA

O sistema será uma aplicação web desenvolvida em PHP para gerenciar relacionamentos com empresas clientes, permitindo o registro de ocorrências, manutenção de histórico e geração de relatórios analíticos.

### 2. REQUISITOS FUNCIONAIS

#### 2.1 Gestão de Usuários
- **RF001**: O sistema deve permitir cadastro de usuários com diferentes níveis de acesso
- **RF002**: O sistema deve implementar autenticação segura (login/logout)
- **RF003**: O sistema deve registrar qual funcionário realizou cada ação
- **RF004**: O sistema deve permitir edição e exclusão de usuários (apenas administradores)
- **RF005**: O sistema deve manter log de atividades dos usuários

#### 2.2 Gestão de Empresas
- **RF006**: O sistema deve permitir cadastro completo de empresas clientes
- **RF007**: O sistema deve armazenar informações como: razão social, CNPJ, endereço, contatos, etc.
- **RF008**: O sistema deve permitir edição e exclusão de empresas
- **RF009**: O sistema deve implementar busca e filtros para empresas
- **RF010**: O sistema deve manter histórico de alterações nas empresas

#### 2.3 Sistema de Ocorrências
- **RF011**: O sistema deve permitir registro de ocorrências para cada empresa
- **RF012**: Cada ocorrência deve conter: data/hora, tipo, descrição, funcionário responsável
- **RF013**: O sistema deve categorizar ocorrências por tipos (atendimento, problema, reunião, etc.)
- **RF014**: O sistema deve permitir anexar arquivos às ocorrências
- **RF015**: O sistema deve manter histórico cronológico de todas as ocorrências
- **RF016**: O sistema deve permitir edição de ocorrências (com controle de versão)

#### 2.4 Sistema de Relatórios
- **RF017**: O sistema deve gerar relatório de ocorrências por empresa
- **RF018**: O sistema deve gerar ranking de empresas com mais ocorrências
- **RF019**: O sistema deve permitir filtros por período, tipo de ocorrência, funcionário
- **RF020**: O sistema deve exportar relatórios em PDF e Excel
- **RF021**: O sistema deve gerar gráficos e estatísticas visuais
- **RF022**: O sistema deve permitir relatórios personalizados

#### 2.5 Sistema de Backup e Restauração
- **RF023**: O sistema deve realizar backup automático do banco de dados
- **RF024**: O sistema deve permitir backup manual via interface web
- **RF025**: O sistema deve implementar restauração de backups
- **RF026**: O sistema deve validar integridade dos backups
- **RF027**: O sistema deve manter histórico de backups realizados

### 3. REQUISITOS NÃO FUNCIONAIS

#### 3.1 Tecnologia
- **RNF001**: Aplicação desenvolvida em PHP 7.4+
- **RNF002**: Banco de dados MySQL 5.7+
- **RNF003**: Servidor web Apache
- **RNF004**: Sistema operacional Linux
- **RNF005**: Interface responsiva (Bootstrap)

#### 3.2 Segurança
- **RNF006**: Senhas criptografadas
- **RNF007**: Proteção contra SQL Injection
- **RNF008**: Controle de sessões seguro
- **RNF009**: Validação de dados de entrada
- **RNF010**: Log de auditoria

#### 3.3 Performance
- **RNF011**: Tempo de resposta máximo de 3 segundos
- **RNF012**: Suporte a múltiplos usuários simultâneos
- **RNF013**: Otimização de consultas ao banco

### 4. CASOS DE USO PRINCIPAIS

#### 4.1 Registrar Ocorrência
1. Usuário faz login no sistema
2. Seleciona empresa cliente
3. Preenche formulário de ocorrência
4. Sistema registra data/hora e usuário automaticamente
5. Ocorrência é salva no histórico da empresa

#### 4.2 Gerar Relatório de Ranking
1. Usuário acessa módulo de relatórios
2. Seleciona período desejado
3. Sistema calcula ranking por número de ocorrências
4. Exibe resultado com opção de exportação

#### 4.3 Realizar Backup
1. Sistema executa backup automático diário
2. Ou usuário solicita backup manual
3. Sistema compacta dados do banco
4. Armazena arquivo com timestamp
5. Registra operação no log

### 5. ESTRUTURA DE DADOS PRINCIPAL

#### 5.1 Entidades Principais
- **Usuários**: id, nome, email, senha, nivel_acesso, ativo, created_at
- **Empresas**: id, razao_social, cnpj, endereco, telefone, email, contato, ativo, created_at
- **Ocorrências**: id, empresa_id, usuario_id, tipo, titulo, descricao, data_ocorrencia, created_at
- **Tipos_Ocorrencia**: id, nome, descricao, cor
- **Backups**: id, nome_arquivo, tamanho, data_backup, usuario_id

### 6. FLUXO DE NAVEGAÇÃO

```
Login → Dashboard → [Empresas|Ocorrências|Relatórios|Usuários|Backup]
                 ↓
              Empresa → Histórico de Ocorrências → Nova Ocorrência
                     ↓
                  Relatórios → Filtros → Exportação
```

Este documento serve como base para o desenvolvimento do sistema e será refinado durante a implementação.

