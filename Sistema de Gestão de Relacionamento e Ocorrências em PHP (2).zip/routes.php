<?php
/**
 * Definição de Rotas da Aplicação
 * Sistema de Gerenciamento de Relacionamento com Empresas
 */

return [
    // Rotas de autenticação
    'auth' => [
        'GET /login' => 'AuthController@showLogin',
        'POST /login' => 'AuthController@login',
        'GET /logout' => 'AuthController@logout',
        'POST /logout' => 'AuthController@logout'
    ],
    
    // Rotas protegidas (requerem autenticação)
    'protected' => [
        // Dashboard
        'GET /' => 'DashboardController@index',
        'GET /dashboard' => 'DashboardController@index',
        'GET /dashboard/stats' => 'DashboardController@stats',
        
        // Empresas
        'GET /empresas' => 'EmpresaController@index',
        'GET /empresas/create' => 'EmpresaController@create',
        'POST /empresas' => 'EmpresaController@store',
        'GET /empresas/{id}' => 'EmpresaController@show',
        'GET /empresas/{id}/edit' => 'EmpresaController@edit',
        'PUT /empresas/{id}' => 'EmpresaController@update',
        'DELETE /empresas/{id}' => 'EmpresaController@destroy',
        'GET /empresas/{id}/ocorrencias' => 'EmpresaController@ocorrencias',
        'GET /empresas/search' => 'EmpresaController@search',
        
        // Ocorrências
        'GET /ocorrencias' => 'OcorrenciaController@index',
        'GET /ocorrencias/create' => 'OcorrenciaController@create',
        'POST /ocorrencias' => 'OcorrenciaController@store',
        'GET /ocorrencias/{id}' => 'OcorrenciaController@show',
        'GET /ocorrencias/{id}/edit' => 'OcorrenciaController@edit',
        'PUT /ocorrencias/{id}' => 'OcorrenciaController@update',
        'DELETE /ocorrencias/{id}' => 'OcorrenciaController@destroy',
        'POST /ocorrencias/{id}/resolve' => 'OcorrenciaController@resolve',
        'GET /ocorrencias/empresa/{empresa_id}' => 'OcorrenciaController@byEmpresa',
        
        // Tipos de Ocorrência
        'GET /tipos-ocorrencia' => 'TipoOcorrenciaController@index',
        'POST /tipos-ocorrencia' => 'TipoOcorrenciaController@store',
        'PUT /tipos-ocorrencia/{id}' => 'TipoOcorrenciaController@update',
        'DELETE /tipos-ocorrencia/{id}' => 'TipoOcorrenciaController@destroy',
        
        // Relatórios
        'GET /relatorios' => 'RelatorioController@index',
        'GET /relatorios/ranking' => 'RelatorioController@ranking',
        'GET /relatorios/ocorrencias' => 'RelatorioController@ocorrencias',
        'GET /relatorios/usuarios' => 'RelatorioController@usuarios',
        'POST /relatorios/export' => 'RelatorioController@export',
        'GET /relatorios/dashboard-data' => 'RelatorioController@dashboardData',
        
        // Upload de arquivos
        'POST /upload' => 'UploadController@store',
        'DELETE /upload/{id}' => 'UploadController@destroy',
        'GET /uploads/{filename}' => 'UploadController@serve',
    ],
    
    // Rotas administrativas (apenas admin)
    'admin' => [
        // Usuários
        'GET /usuarios' => 'UsuarioController@index',
        'GET /usuarios/create' => 'UsuarioController@create',
        'POST /usuarios' => 'UsuarioController@store',
        'GET /usuarios/{id}' => 'UsuarioController@show',
        'GET /usuarios/{id}/edit' => 'UsuarioController@edit',
        'PUT /usuarios/{id}' => 'UsuarioController@update',
        'DELETE /usuarios/{id}' => 'UsuarioController@destroy',
        'POST /usuarios/{id}/toggle-status' => 'UsuarioController@toggleStatus',
        
        // Backup
        'GET /backup' => 'BackupController@index',
        'POST /backup/create' => 'BackupController@create',
        'POST /backup/restore' => 'BackupController@restore',
        'DELETE /backup/{id}' => 'BackupController@destroy',
        'GET /backup/{id}/download' => 'BackupController@download',
        'GET /backup/status' => 'BackupController@status',
        
        // Logs do sistema
        'GET /logs' => 'LogController@index',
        'GET /logs/system' => 'LogController@system',
        'GET /logs/errors' => 'LogController@errors',
        'POST /logs/clear' => 'LogController@clear',
        
        // Configurações
        'GET /configuracoes' => 'ConfiguracaoController@index',
        'PUT /configuracoes' => 'ConfiguracaoController@update',
        'POST /configuracoes/test-email' => 'ConfiguracaoController@testEmail',
        'POST /configuracoes/clear-cache' => 'ConfiguracaoController@clearCache',
    ],
    
    // Rotas de API (para futuras integrações)
    'api' => [
        'GET /api/empresas' => 'Api\EmpresaController@index',
        'GET /api/empresas/{id}' => 'Api\EmpresaController@show',
        'GET /api/ocorrencias' => 'Api\OcorrenciaController@index',
        'POST /api/ocorrencias' => 'Api\OcorrenciaController@store',
        'GET /api/relatorios/stats' => 'Api\RelatorioController@stats',
    ],
    
    // Rotas de recursos estáticos
    'static' => [
        'GET /assets/{type}/{file}' => 'AssetController@serve',
        'GET /favicon.ico' => 'AssetController@favicon',
    ],
    
    // Configurações de middleware por grupo
    'middleware' => [
        'auth' => [
            'class' => 'AuthMiddleware',
            'except' => ['/login', '/logout', '/assets/*', '/favicon.ico']
        ],
        'admin' => [
            'class' => 'AdminMiddleware',
            'routes' => ['admin']
        ],
        'csrf' => [
            'class' => 'CsrfMiddleware',
            'methods' => ['POST', 'PUT', 'DELETE']
        ],
        'cors' => [
            'class' => 'CorsMiddleware',
            'routes' => ['api']
        ],
        'rate_limit' => [
            'class' => 'RateLimitMiddleware',
            'routes' => ['api'],
            'limit' => 60 // requests per minute
        ]
    ],
    
    // Configurações de cache de rotas
    'cache' => [
        'enabled' => !($_ENV['APP_DEBUG'] ?? false),
        'ttl' => 3600,
        'key' => 'routes_cache'
    ]
];

