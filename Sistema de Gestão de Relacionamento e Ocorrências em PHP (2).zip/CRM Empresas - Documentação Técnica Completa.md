# CRM Empresas - Documentação Técnica Completa

**Sistema de Gerenciamento de Relacionamento com Empresas**

**Versão:** 1.0.0  
**Data:** Janeiro 2024  
**Autor:** Manus AI  
**Tecnologias:** PHP 8.0+, MySQL 8.0+, Apache 2.4+, Bootstrap 5.3

---

## Sumário Executivo

O CRM Empresas é uma aplicação web completa desenvolvida especificamente para gerenciamento de relacionamento com empresas clientes. O sistema oferece funcionalidades abrangentes para cadastro de empresas, controle de ocorrências, gestão de usuários, geração de relatórios analíticos e sistema robusto de backup e restauração.

Desenvolvido seguindo as melhores práticas de segurança, performance e usabilidade, o sistema utiliza arquitetura MVC (Model-View-Controller) com padrão de design responsivo, garantindo compatibilidade com dispositivos móveis e desktop. A aplicação foi projetada para ambiente Linux Apache com MySQL, oferecendo escalabilidade e confiabilidade para uso empresarial.

## Arquitetura do Sistema

### Visão Geral da Arquitetura

O sistema segue o padrão arquitetural MVC (Model-View-Controller) de três camadas, proporcionando separação clara de responsabilidades e facilitando manutenção e evolução do código. A arquitetura foi projetada para ser modular, escalável e segura.

**Camada de Apresentação (View):**
- Interface web responsiva desenvolvida com Bootstrap 5.3
- Templates PHP com separação de layout (header/footer)
- JavaScript para interatividade e validações client-side
- CSS customizado para identidade visual

**Camada de Controle (Controller):**
- Controllers específicos para cada módulo funcional
- Roteamento centralizado com middleware de autenticação
- Validação de dados e controle de fluxo
- Tratamento de erros e exceções

**Camada de Modelo (Model):**
- Classes de modelo para cada entidade do sistema
- Abstração de acesso a dados com PDO
- Validações de negócio e regras de integridade
- Relacionamentos entre entidades

**Camada de Dados:**
- Banco de dados MySQL com estrutura normalizada
- Índices otimizados para performance
- Triggers para auditoria automática
- Views para consultas complexas

### Estrutura de Diretórios

```
crm-empresas/
├── app/
│   ├── controllers/          # Controllers da aplicação
│   ├── models/              # Modelos de dados
│   ├── views/               # Templates e views
│   └── helpers/             # Classes auxiliares
├── config/                  # Arquivos de configuração
├── database/
│   ├── migrations/          # Scripts de criação do banco
│   └── seeds/              # Dados iniciais
├── public/                  # Ponto de entrada público
├── storage/
│   ├── backups/            # Arquivos de backup
│   ├── logs/               # Logs do sistema
│   ├── sessions/           # Sessões PHP
│   └── tmp/                # Arquivos temporários
└── uploads/                # Arquivos enviados pelos usuários
```

## Especificações Técnicas

### Requisitos de Sistema

**Servidor Web:**
- Apache 2.4+ com mod_rewrite, mod_headers, mod_deflate
- Nginx 1.18+ (alternativo, com configuração específica)
- Suporte a .htaccess ou configuração equivalente

**PHP:**
- Versão 7.4+ ou 8.0+ (recomendado)
- Extensões: mysql, mbstring, xml, curl, zip, gd, json
- Configurações: memory_limit 256M+, upload_max_filesize 10M+

**Banco de Dados:**
- MySQL 5.7+ ou 8.0+ (recomendado)
- MariaDB 10.3+ (compatível)
- Charset UTF8MB4 para suporte completo a Unicode

**Sistema Operacional:**
- Ubuntu 18.04+ LTS (recomendado)
- Debian 9+ (testado)
- CentOS 7+ (compatível)
- Outros sistemas Linux com adaptações

### Dependências e Bibliotecas

**Frontend:**
- Bootstrap 5.3.2 (framework CSS responsivo)
- jQuery 3.7.1 (manipulação DOM e AJAX)
- Chart.js (gráficos interativos)
- DataTables 1.13.7 (tabelas avançadas)
- Select2 4.1.0 (seleção avançada)
- SweetAlert2 (alertas modernos)
- Font Awesome 6.4.0 (ícones)

**Backend:**
- PDO (acesso a banco de dados)
- Session handling nativo do PHP
- File upload com validação
- CSRF protection customizado

## Modelo de Dados

### Diagrama de Entidades e Relacionamentos

O banco de dados foi projetado seguindo princípios de normalização, garantindo integridade referencial e otimização de consultas. As principais entidades são:

**Entidades Principais:**
1. **usuarios** - Gestão de usuários do sistema
2. **empresas** - Cadastro de empresas clientes
3. **ocorrencias** - Registro de interações e ocorrências
4. **tipos_ocorrencia** - Categorização de ocorrências
5. **backups** - Controle de backups do sistema

**Entidades de Auditoria:**
6. **historico_alteracoes** - Log de mudanças
7. **logs_sistema** - Auditoria de ações
8. **sessoes_usuario** - Controle de sessões

### Estrutura Detalhada das Tabelas

#### Tabela: usuarios
```sql
CREATE TABLE usuarios (
    id INT PRIMARY KEY AUTO_INCREMENT,
    nome VARCHAR(100) NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    senha VARCHAR(255) NOT NULL,
    nivel ENUM('admin', 'operador', 'visualizador') DEFAULT 'operador',
    ativo BOOLEAN DEFAULT TRUE,
    ultimo_login DATETIME NULL,
    tentativas_login INT DEFAULT 0,
    bloqueado_ate DATETIME NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);
```

#### Tabela: empresas
```sql
CREATE TABLE empresas (
    id INT PRIMARY KEY AUTO_INCREMENT,
    razao_social VARCHAR(200) NOT NULL,
    nome_fantasia VARCHAR(200),
    cnpj VARCHAR(18) UNIQUE NOT NULL,
    email VARCHAR(100),
    telefone VARCHAR(20),
    endereco TEXT,
    cep VARCHAR(10),
    cidade VARCHAR(100),
    estado VARCHAR(2),
    website VARCHAR(200),
    observacoes TEXT,
    ativo BOOLEAN DEFAULT TRUE,
    usuario_cadastro INT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (usuario_cadastro) REFERENCES usuarios(id)
);
```

#### Tabela: ocorrencias
```sql
CREATE TABLE ocorrencias (
    id INT PRIMARY KEY AUTO_INCREMENT,
    empresa_id INT NOT NULL,
    usuario_id INT NOT NULL,
    tipo_ocorrencia_id INT NOT NULL,
    titulo VARCHAR(200) NOT NULL,
    descricao TEXT NOT NULL,
    status ENUM('aberta', 'em_andamento', 'resolvida', 'fechada') DEFAULT 'aberta',
    prioridade ENUM('baixa', 'media', 'alta', 'critica') DEFAULT 'media',
    data_prevista DATE NULL,
    data_resolucao DATETIME NULL,
    resolucao TEXT NULL,
    anexos JSON NULL,
    tags VARCHAR(500),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (empresa_id) REFERENCES empresas(id),
    FOREIGN KEY (usuario_id) REFERENCES usuarios(id),
    FOREIGN KEY (tipo_ocorrencia_id) REFERENCES tipos_ocorrencia(id)
);
```

### Índices e Otimizações

O sistema implementa índices estratégicos para otimização de consultas:

```sql
-- Índices para busca e performance
CREATE INDEX idx_empresas_cnpj ON empresas(cnpj);
CREATE INDEX idx_empresas_ativo ON empresas(ativo);
CREATE INDEX idx_ocorrencias_empresa ON ocorrencias(empresa_id);
CREATE INDEX idx_ocorrencias_status ON ocorrencias(status);
CREATE INDEX idx_ocorrencias_data ON ocorrencias(created_at);
CREATE FULLTEXT INDEX idx_empresas_busca ON empresas(razao_social, nome_fantasia);
CREATE FULLTEXT INDEX idx_ocorrencias_busca ON ocorrencias(titulo, descricao);
```

## Funcionalidades Detalhadas

### Sistema de Autenticação e Autorização

O sistema implementa autenticação robusta com três níveis de acesso:

**Administrador:**
- Acesso completo a todas as funcionalidades
- Gestão de usuários e configurações
- Acesso ao sistema de backup
- Visualização de logs e auditoria

**Operador:**
- Cadastro e edição de empresas
- Criação e gestão de ocorrências
- Acesso a relatórios básicos
- Sem acesso a configurações administrativas

**Visualizador:**
- Apenas visualização de dados
- Acesso limitado a relatórios
- Sem permissões de edição

**Recursos de Segurança:**
- Hash de senhas com password_hash() do PHP
- Proteção contra força bruta com bloqueio temporário
- Regeneração automática de ID de sessão
- Proteção CSRF em formulários
- Validação rigorosa de dados de entrada

### Gestão de Empresas

O módulo de empresas oferece funcionalidades completas para cadastro e gestão:

**Cadastro Completo:**
- Validação automática de CNPJ com dígito verificador
- Consulta automática de CEP via API ViaCEP
- Formatação automática de campos (CNPJ, telefone, CEP)
- Campos obrigatórios e opcionais bem definidos

**Busca Avançada:**
- Busca textual com FULLTEXT em razão social e nome fantasia
- Filtros por status (ativo/inativo)
- Ordenação por múltiplos critérios
- Paginação otimizada para grandes volumes

**Funcionalidades Especiais:**
- Autocomplete para seleção rápida
- Histórico completo de alterações
- Soft delete para preservar relacionamentos
- Estatísticas de ocorrências por empresa

### Sistema de Ocorrências

O coração do sistema CRM, permitindo controle completo do relacionamento:

**Workflow de Status:**
1. **Aberta** - Ocorrência criada, aguardando ação
2. **Em Andamento** - Sendo trabalhada pela equipe
3. **Resolvida** - Solução implementada, aguardando confirmação
4. **Fechada** - Finalizada definitivamente

**Recursos Avançados:**
- Sistema de prioridades (baixa, média, alta, crítica)
- Anexos múltiplos com validação de tipo
- Tags livres para categorização adicional
- Data prevista para resolução
- Histórico completo de alterações

**Controle de SLA:**
- Alertas automáticos para ocorrências em atraso
- Cálculo de tempo médio de resolução
- Relatórios de performance por usuário

### Relatórios e Analytics

Sistema completo de business intelligence:

**Dashboard Principal:**
- Estatísticas em tempo real
- Gráficos interativos com Chart.js
- Ranking de empresas mais ativas
- Timeline de atividades recentes

**Relatórios Específicos:**
- Ranking de empresas por período
- Relatório detalhado de ocorrências
- Estatísticas de usuários (apenas admin)
- Análise de tendências temporais

**Exportação:**
- Formato CSV com codificação UTF-8
- Separador ponto e vírgula (padrão brasileiro)
- Filtros aplicados mantidos na exportação
- Headers em português

### Sistema de Backup e Restauração

Solução completa para proteção de dados:

**Backup Automático:**
- Agendamento via cron (diário, semanal, mensal)
- Backup completo do banco MySQL via mysqldump
- Limpeza automática de backups antigos
- Logs detalhados de execução

**Backup Manual:**
- Interface web para criação imediata
- Descrição personalizada para identificação
- Verificação de integridade automática
- Download direto do arquivo

**Restauração:**
- Backup de segurança antes da restauração
- Confirmação obrigatória para evitar acidentes
- Logs de auditoria completos
- Verificação de integridade antes da restauração

**Funcionalidades Avançadas:**
- Upload de backups externos
- Verificação de integridade com checksums
- Estatísticas de uso de espaço
- API para monitoramento externo

## Segurança

### Medidas de Proteção Implementadas

**Proteção contra Ataques Comuns:**
- XSS (Cross-Site Scripting): Escape de dados e CSP headers
- CSRF (Cross-Site Request Forgery): Tokens únicos por sessão
- SQL Injection: Prepared statements exclusivamente
- Clickjacking: X-Frame-Options DENY
- MIME Sniffing: X-Content-Type-Options nosniff

**Configurações de Segurança:**
```apache
# Headers de segurança no .htaccess
Header always set X-Content-Type-Options nosniff
Header always set X-Frame-Options DENY
Header always set X-XSS-Protection "1; mode=block"
Header always set Referrer-Policy "strict-origin-when-cross-origin"
Header always set Content-Security-Policy "default-src 'self'..."
```

**Validação de Dados:**
- Validação server-side rigorosa
- Sanitização de entrada de dados
- Validação de tipos de arquivo em uploads
- Limitação de tamanho de arquivos

**Controle de Acesso:**
- Middleware de autenticação em todas as rotas protegidas
- Verificação de permissões por nível de usuário
- Logs de auditoria para ações sensíveis
- Timeout automático de sessões

### Configurações de Produção

**Apache Security:**
```apache
# Ocultar informações do servidor
ServerTokens Prod
ServerSignature Off
Header unset Server
Header always unset X-Powered-By

# Proteção de arquivos sensíveis
<FilesMatch "\.(htaccess|htpasswd|ini|log|sh|inc|bak|sql)$">
    Require all denied
</FilesMatch>
```

**PHP Security:**
```ini
; php.ini recomendações
display_errors = Off
log_errors = On
expose_php = Off
session.cookie_httponly = 1
session.cookie_secure = 1
session.use_only_cookies = 1
```

## Performance e Otimização

### Estratégias de Performance

**Cache e Compressão:**
- GZIP compression para todos os assets
- Cache headers otimizados por tipo de arquivo
- ETags desabilitados para melhor controle de cache
- Compressão de CSS e JavaScript

**Otimização de Banco:**
- Índices estratégicos em colunas de busca
- FULLTEXT indexes para busca textual
- Queries otimizadas com EXPLAIN
- Connection pooling quando disponível

**Frontend Optimization:**
- CDN para bibliotecas externas
- Lazy loading de componentes pesados
- Minificação de assets customizados
- Sprites de ícones quando aplicável

### Monitoramento e Logs

**Sistema de Logs:**
```php
// Estrutura de logs implementada
storage/logs/
├── application.log      # Logs gerais da aplicação
├── error.log           # Erros e exceções
├── security.log        # Eventos de segurança
├── performance.log     # Queries lentas e performance
└── audit.log          # Auditoria de ações
```

**Métricas Monitoradas:**
- Tempo de resposta de páginas
- Queries lentas (> 1 segundo)
- Tentativas de login falhadas
- Uploads de arquivos
- Ações administrativas

## Instalação e Configuração

### Processo de Instalação Automatizada

O sistema inclui script de instalação automatizada (`install.sh`) que:

1. **Verifica Dependências:**
   - Sistema operacional compatível
   - Versões de PHP, Apache e MySQL
   - Extensões PHP necessárias
   - Módulos Apache requeridos

2. **Configura Ambiente:**
   - Cria estrutura de diretórios
   - Define permissões adequadas
   - Configura propriedade de arquivos

3. **Configura Banco de Dados:**
   - Cria banco e usuário
   - Executa migrations
   - Insere dados iniciais
   - Configura conexão

4. **Configura Apache:**
   - Cria virtual host
   - Habilita módulos necessários
   - Configura SSL (opcional)
   - Reinicia serviços

5. **Testes de Instalação:**
   - Conectividade com banco
   - Permissões de escrita
   - Resposta do Apache
   - Funcionalidades básicas

### Configuração Manual Detalhada

Para instalações customizadas ou ambientes específicos:

**1. Preparação do Ambiente:**
```bash
# Ubuntu/Debian
sudo apt update
sudo apt install apache2 mysql-server php php-mysql php-mbstring php-xml php-curl php-zip php-gd

# CentOS/RHEL
sudo yum install httpd mariadb-server php php-mysql php-mbstring php-xml php-curl php-zip php-gd
```

**2. Configuração do MySQL:**
```sql
-- Criar banco com charset correto
CREATE DATABASE crm_empresas CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

-- Criar usuário com permissões específicas
CREATE USER 'crm_user'@'localhost' IDENTIFIED BY 'senha_segura';
GRANT SELECT, INSERT, UPDATE, DELETE, CREATE, ALTER, INDEX ON crm_empresas.* TO 'crm_user'@'localhost';
FLUSH PRIVILEGES;
```

**3. Configuração do Apache:**
```apache
# Virtual Host básico
<VirtualHost *:80>
    ServerName crm.empresa.com
    DocumentRoot /var/www/html/crm-empresas/public
    
    <Directory /var/www/html/crm-empresas/public>
        AllowOverride All
        Require all granted
    </Directory>
    
    ErrorLog ${APACHE_LOG_DIR}/crm-error.log
    CustomLog ${APACHE_LOG_DIR}/crm-access.log combined
</VirtualHost>
```

## Manutenção e Suporte

### Rotinas de Manutenção

**Backup Regular:**
```bash
# Script de backup completo
#!/bin/bash
DATE=$(date +%Y%m%d_%H%M%S)
mysqldump -u crm_user -p crm_empresas > backup_db_$DATE.sql
tar -czf backup_files_$DATE.tar.gz /var/www/html/crm-empresas
```

**Limpeza de Logs:**
```bash
# Rotação de logs (adicionar ao cron)
find /var/www/html/crm-empresas/storage/logs/ -name "*.log" -mtime +30 -delete
```

**Monitoramento de Espaço:**
```bash
# Verificar uso de disco
df -h /var/www/html/crm-empresas/
du -sh /var/www/html/crm-empresas/storage/
```

### Solução de Problemas Comuns

**Erro 500 - Internal Server Error:**
1. Verificar logs do Apache: `tail -f /var/log/apache2/error.log`
2. Verificar permissões: `ls -la /var/www/html/crm-empresas/`
3. Verificar configuração PHP: `php -m | grep mysql`

**Problemas de Conexão com Banco:**
1. Testar conexão: `mysql -u crm_user -p -h localhost crm_empresas`
2. Verificar configuração: `cat config/database.php`
3. Verificar status do MySQL: `systemctl status mysql`

**Problemas de Upload:**
1. Verificar permissões: `ls -la uploads/`
2. Verificar configuração PHP: `php -i | grep upload`
3. Verificar espaço em disco: `df -h`

### Atualizações e Versionamento

**Processo de Atualização:**
1. **Backup Completo:** Sempre antes de qualquer atualização
2. **Teste em Ambiente:** Validar em ambiente de desenvolvimento
3. **Migrations:** Executar scripts de atualização do banco
4. **Verificação:** Testar funcionalidades críticas
5. **Rollback:** Plano de reversão em caso de problemas

**Controle de Versão:**
- Versionamento semântico (MAJOR.MINOR.PATCH)
- Changelog detalhado para cada versão
- Tags no Git para releases
- Documentação de breaking changes

## Conclusão

O CRM Empresas representa uma solução completa e robusta para gerenciamento de relacionamento com empresas clientes. Desenvolvido com foco em segurança, performance e usabilidade, o sistema oferece todas as funcionalidades necessárias para um controle eficiente de ocorrências e relacionamentos empresariais.

A arquitetura modular e bem documentada facilita manutenção e evolução futura, enquanto as configurações de segurança e performance garantem operação confiável em ambiente de produção. O sistema de backup automático e as ferramentas de monitoramento proporcionam tranquilidade para operação crítica.

Com interface moderna e responsiva, o sistema atende tanto usuários desktop quanto mobile, garantindo produtividade em qualquer ambiente de trabalho. A documentação completa e o script de instalação automatizada facilitam a implantação e reduzem o tempo de setup.

O projeto está pronto para uso em produção e pode ser facilmente customizado para atender necessidades específicas de diferentes organizações.

---

**Desenvolvido por:** Manus AI  
**Data:** Janeiro 2024  
**Versão da Documentação:** 1.0.0

