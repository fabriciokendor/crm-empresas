<?php
/**
 * Controller de Ocorrências
 * Sistema de Gerenciamento de Relacionamento com Empresas
 */

class OcorrenciaController
{
    private $ocorrenciaModel;
    private $empresaModel;
    private $tipoOcorrenciaModel;
    
    public function __construct()
    {
        $this->ocorrenciaModel = new Ocorrencia();
        $this->empresaModel = new Empresa();
        $this->tipoOcorrenciaModel = new TipoOcorrencia();
        
        // Verificar autenticação
        if (!Auth::check()) {
            header('Location: /login');
            exit;
        }
    }
    
    /**
     * Lista todas as ocorrências
     */
    public function index()
    {
        // Verificar permissão
        if (!$this->can('view_ocorrencias')) {
            $this->setErrorMessage('Você não tem permissão para visualizar ocorrências.');
            $this->redirect('/dashboard');
            return;
        }
        
        $filtros = [
            'empresa_id' => $_GET['empresa_id'] ?? '',
            'usuario_id' => $_GET['usuario_id'] ?? '',
            'tipo_ocorrencia_id' => $_GET['tipo_ocorrencia_id'] ?? '',
            'status' => $_GET['status'] ?? '',
            'prioridade' => $_GET['prioridade'] ?? '',
            'data_inicio' => $_GET['data_inicio'] ?? '',
            'data_fim' => $_GET['data_fim'] ?? '',
            'busca' => $_GET['busca'] ?? ''
        ];
        
        // Remover filtros vazios
        $filtros = array_filter($filtros, function($value) {
            return $value !== '' && $value !== null;
        });
        
        $ocorrencias = empty($filtros) ? $this->ocorrenciaModel->all() : $this->ocorrenciaModel->search($filtros);
        $stats = $this->ocorrenciaModel->stats();
        
        // Buscar dados para filtros
        $empresas = $this->empresaModel->all(true);
        $tiposOcorrencia = $this->tipoOcorrenciaModel->all(true);
        
        $data = [
            'title' => 'Ocorrências - CRM Empresas',
            'ocorrencias' => $ocorrencias,
            'stats' => $stats,
            'empresas' => $empresas,
            'tipos_ocorrencia' => $tiposOcorrencia,
            'filtros' => $_GET,
            'can_create' => $this->can('create_ocorrencias'),
            'can_edit' => $this->can('edit_ocorrencias'),
            'can_resolve' => $this->can('resolve_ocorrencias'),
            'success' => $_SESSION['success_message'] ?? null,
            'error' => $_SESSION['error_message'] ?? null
        ];
        
        // Limpar mensagens da sessão
        unset($_SESSION['success_message'], $_SESSION['error_message']);
        
        $this->view('ocorrencias/index', $data);
    }
    
    /**
     * Exibe formulário de criação
     */
    public function create()
    {
        if (!$this->can('create_ocorrencias')) {
            $this->setErrorMessage('Você não tem permissão para criar ocorrências.');
            $this->redirect('/ocorrencias');
            return;
        }
        
        $empresas = $this->empresaModel->all(true);
        $tiposOcorrencia = $this->tipoOcorrenciaModel->all(true);
        
        $data = [
            'title' => 'Nova Ocorrência - CRM Empresas',
            'ocorrencia' => [],
            'empresas' => $empresas,
            'tipos_ocorrencia' => $tiposOcorrencia,
            'empresa_selecionada' => $_GET['empresa_id'] ?? null,
            'errors' => $_SESSION['validation_errors'] ?? [],
            'old' => $_SESSION['old_input'] ?? []
        ];
        
        // Limpar dados da sessão
        unset($_SESSION['validation_errors'], $_SESSION['old_input']);
        
        $this->view('ocorrencias/create', $data);
    }
    
    /**
     * Armazena nova ocorrência
     */
    public function store()
    {
        if (!$this->can('create_ocorrencias')) {
            $this->setErrorMessage('Você não tem permissão para criar ocorrências.');
            $this->redirect('/ocorrencias');
            return;
        }
        
        try {
            $ocorrencia = $this->ocorrenciaModel->create($_POST);
            $this->setSuccessMessage("Ocorrência '{$ocorrencia['titulo']}' criada com sucesso!");
            $this->redirect('/ocorrencias');
            
        } catch (Exception $e) {
            // Armazenar erros e dados antigos na sessão
            $_SESSION['validation_errors'] = [$e->getMessage()];
            $_SESSION['old_input'] = $_POST;
            
            $this->redirect('/ocorrencias/create');
        }
    }
    
    /**
     * Exibe detalhes de uma ocorrência
     */
    public function show($id)
    {
        if (!$this->can('view_ocorrencias')) {
            $this->setErrorMessage('Você não tem permissão para visualizar ocorrências.');
            $this->redirect('/ocorrencias');
            return;
        }
        
        $ocorrencia = $this->ocorrenciaModel->find($id);
        
        if (!$ocorrencia) {
            $this->setErrorMessage('Ocorrência não encontrada.');
            $this->redirect('/ocorrencias');
            return;
        }
        
        // Buscar histórico
        $historico = $this->ocorrenciaModel->historico($id);
        
        // Processar anexos
        $anexos = json_decode($ocorrencia['anexos'], true) ?? [];
        
        $data = [
            'title' => "Ocorrência: {$ocorrencia['titulo']} - CRM Empresas",
            'ocorrencia' => $ocorrencia,
            'historico' => $historico,
            'anexos' => $anexos,
            'can_edit' => $this->can('edit_ocorrencias'),
            'can_resolve' => $this->can('resolve_ocorrencias'),
            'can_close' => $this->can('close_ocorrencias')
        ];
        
        $this->view('ocorrencias/show', $data);
    }
    
    /**
     * Exibe formulário de edição
     */
    public function edit($id)
    {
        if (!$this->can('edit_ocorrencias')) {
            $this->setErrorMessage('Você não tem permissão para editar ocorrências.');
            $this->redirect('/ocorrencias');
            return;
        }
        
        $ocorrencia = $this->ocorrenciaModel->find($id);
        
        if (!$ocorrencia) {
            $this->setErrorMessage('Ocorrência não encontrada.');
            $this->redirect('/ocorrencias');
            return;
        }
        
        $empresas = $this->empresaModel->all(true);
        $tiposOcorrencia = $this->tipoOcorrenciaModel->all(true);
        
        $data = [
            'title' => "Editar Ocorrência: {$ocorrencia['titulo']} - CRM Empresas",
            'ocorrencia' => $ocorrencia,
            'empresas' => $empresas,
            'tipos_ocorrencia' => $tiposOcorrencia,
            'errors' => $_SESSION['validation_errors'] ?? [],
            'old' => $_SESSION['old_input'] ?? []
        ];
        
        // Limpar dados da sessão
        unset($_SESSION['validation_errors'], $_SESSION['old_input']);
        
        $this->view('ocorrencias/edit', $data);
    }
    
    /**
     * Atualiza uma ocorrência
     */
    public function update($id)
    {
        if (!$this->can('edit_ocorrencias')) {
            $this->setErrorMessage('Você não tem permissão para editar ocorrências.');
            $this->redirect('/ocorrencias');
            return;
        }
        
        try {
            $ocorrencia = $this->ocorrenciaModel->find($id);
            
            if (!$ocorrencia) {
                throw new Exception('Ocorrência não encontrada.');
            }
            
            $ocorrenciaAtualizada = $this->ocorrenciaModel->update($id, $_POST);
            $this->setSuccessMessage("Ocorrência '{$ocorrenciaAtualizada['titulo']}' atualizada com sucesso!");
            $this->redirect('/ocorrencias');
            
        } catch (Exception $e) {
            // Armazenar erros e dados antigos na sessão
            $_SESSION['validation_errors'] = [$e->getMessage()];
            $_SESSION['old_input'] = $_POST;
            
            $this->redirect("/ocorrencias/{$id}/edit");
        }
    }
    
    /**
     * Resolve uma ocorrência
     */
    public function resolve($id)
    {
        if (!$this->can('resolve_ocorrencias')) {
            $this->setErrorMessage('Você não tem permissão para resolver ocorrências.');
            $this->redirect('/ocorrencias');
            return;
        }
        
        try {
            $resolucao = $_POST['resolucao'] ?? '';
            
            if (empty($resolucao)) {
                throw new Exception('Descrição da resolução é obrigatória.');
            }
            
            $ocorrencia = $this->ocorrenciaModel->resolver($id, $resolucao);
            $this->setSuccessMessage("Ocorrência '{$ocorrencia['titulo']}' resolvida com sucesso!");
            
        } catch (Exception $e) {
            $this->setErrorMessage($e->getMessage());
        }
        
        // Responder com JSON se for requisição AJAX
        if ($this->isAjaxRequest()) {
            header('Content-Type: application/json');
            echo json_encode([
                'success' => !isset($e),
                'message' => isset($e) ? $e->getMessage() : "Ocorrência resolvida com sucesso"
            ]);
            return;
        }
        
        $this->redirect("/ocorrencias/{$id}");
    }
    
    /**
     * Fecha uma ocorrência
     */
    public function close($id)
    {
        if (!$this->can('close_ocorrencias')) {
            $this->setErrorMessage('Você não tem permissão para fechar ocorrências.');
            $this->redirect('/ocorrencias');
            return;
        }
        
        try {
            $observacoes = $_POST['observacoes'] ?? '';
            $ocorrencia = $this->ocorrenciaModel->fechar($id, $observacoes);
            $this->setSuccessMessage("Ocorrência '{$ocorrencia['titulo']}' fechada com sucesso!");
            
        } catch (Exception $e) {
            $this->setErrorMessage($e->getMessage());
        }
        
        $this->redirect("/ocorrencias/{$id}");
    }
    
    /**
     * Reabre uma ocorrência
     */
    public function reopen($id)
    {
        if (!$this->can('edit_ocorrencias')) {
            $this->setErrorMessage('Você não tem permissão para reabrir ocorrências.');
            $this->redirect('/ocorrencias');
            return;
        }
        
        try {
            $motivo = $_POST['motivo'] ?? '';
            
            if (empty($motivo)) {
                throw new Exception('Motivo da reabertura é obrigatório.');
            }
            
            $ocorrencia = $this->ocorrenciaModel->reabrir($id, $motivo);
            $this->setSuccessMessage("Ocorrência '{$ocorrencia['titulo']}' reaberta com sucesso!");
            
        } catch (Exception $e) {
            $this->setErrorMessage($e->getMessage());
        }
        
        $this->redirect("/ocorrencias/{$id}");
    }
    
    /**
     * Remove anexo de uma ocorrência
     */
    public function removeAttachment($id)
    {
        if (!$this->can('edit_ocorrencias')) {
            http_response_code(403);
            echo json_encode(['error' => 'Sem permissão']);
            return;
        }
        
        try {
            $nomeArquivo = $_POST['arquivo'] ?? '';
            
            if (empty($nomeArquivo)) {
                throw new Exception('Nome do arquivo é obrigatório.');
            }
            
            $this->ocorrenciaModel->removerAnexo($id, $nomeArquivo);
            
            header('Content-Type: application/json');
            echo json_encode(['success' => true, 'message' => 'Anexo removido com sucesso']);
            
        } catch (Exception $e) {
            http_response_code(400);
            header('Content-Type: application/json');
            echo json_encode(['error' => $e->getMessage()]);
        }
    }
    
    /**
     * Busca ocorrências por empresa (AJAX)
     */
    public function byEmpresa($empresaId)
    {
        if (!$this->can('view_ocorrencias')) {
            http_response_code(403);
            echo json_encode(['error' => 'Sem permissão']);
            return;
        }
        
        $ocorrencias = $this->ocorrenciaModel->search(['empresa_id' => $empresaId]);
        
        // Formatar dados
        foreach ($ocorrencias as &$ocorrencia) {
            $ocorrencia['data_ocorrencia_formatada'] = date('d/m/Y H:i', strtotime($ocorrencia['data_ocorrencia']));
            $ocorrencia['tempo_relativo'] = $this->timeAgo($ocorrencia['data_ocorrencia']);
        }
        
        header('Content-Type: application/json');
        echo json_encode(['ocorrencias' => $ocorrencias]);
    }
    
    /**
     * Dashboard de ocorrências (AJAX)
     */
    public function dashboard()
    {
        if (!$this->isAjaxRequest()) {
            http_response_code(400);
            return;
        }
        
        $stats = $this->ocorrenciaModel->stats();
        $emAtraso = $this->ocorrenciaModel->emAtraso();
        $porPeriodo = $this->ocorrenciaModel->porPeriodo();
        
        header('Content-Type: application/json');
        echo json_encode([
            'stats' => $stats,
            'em_atraso' => $emAtraso,
            'por_periodo' => $porPeriodo
        ]);
    }
    
    /**
     * Exporta lista de ocorrências
     */
    public function export()
    {
        if (!$this->can('export_ocorrencias')) {
            $this->setErrorMessage('Você não tem permissão para exportar ocorrências.');
            $this->redirect('/ocorrencias');
            return;
        }
        
        $formato = $_GET['formato'] ?? 'csv';
        
        // Aplicar filtros se houver
        $filtros = array_filter($_GET, function($value) {
            return $value !== '' && $value !== null;
        });
        unset($filtros['formato']);
        
        $ocorrencias = empty($filtros) ? $this->ocorrenciaModel->all() : $this->ocorrenciaModel->search($filtros);
        
        switch ($formato) {
            case 'csv':
                $this->exportCsv($ocorrencias);
                break;
            case 'excel':
                $this->exportExcel($ocorrencias);
                break;
            default:
                $this->setErrorMessage('Formato de exportação inválido.');
                $this->redirect('/ocorrencias');
        }
    }
    
    /**
     * Exporta para CSV
     */
    private function exportCsv($ocorrencias)
    {
        $filename = 'ocorrencias_' . date('Y-m-d_H-i-s') . '.csv';
        
        header('Content-Type: text/csv; charset=utf-8');
        header('Content-Disposition: attachment; filename=' . $filename);
        
        $output = fopen('php://output', 'w');
        
        // BOM para UTF-8
        fprintf($output, chr(0xEF).chr(0xBB).chr(0xBF));
        
        // Cabeçalho
        fputcsv($output, [
            'ID', 'Título', 'Empresa', 'Tipo', 'Status', 'Prioridade',
            'Usuário Responsável', 'Data da Ocorrência', 'Data de Resolução', 'Descrição'
        ], ';');
        
        // Dados
        foreach ($ocorrencias as $ocorrencia) {
            fputcsv($output, [
                $ocorrencia['id'],
                $ocorrencia['titulo'],
                $ocorrencia['empresa_nome'],
                $ocorrencia['tipo_nome'],
                $ocorrencia['status'],
                $ocorrencia['prioridade'],
                $ocorrencia['usuario_nome'],
                date('d/m/Y H:i', strtotime($ocorrencia['data_ocorrencia'])),
                $ocorrencia['data_resolucao'] ? date('d/m/Y H:i', strtotime($ocorrencia['data_resolucao'])) : '',
                $ocorrencia['descricao']
            ], ';');
        }
        
        fclose($output);
    }
    
    /**
     * Verifica permissões do usuário
     */
    private function can($action)
    {
        if (!Auth::check()) {
            return false;
        }
        
        $userRole = Auth::user()['nivel_acesso'];
        
        $permissions = [
            'admin' => ['*'],
            'operador' => [
                'view_ocorrencias', 'create_ocorrencias', 'edit_ocorrencias',
                'resolve_ocorrencias', 'close_ocorrencias', 'export_ocorrencias'
            ],
            'visualizador' => ['view_ocorrencias']
        ];
        
        $userPermissions = $permissions[$userRole] ?? [];
        
        return in_array('*', $userPermissions) || in_array($action, $userPermissions);
    }
    
    /**
     * Calcula tempo relativo
     */
    private function timeAgo($datetime)
    {
        $time = time() - strtotime($datetime);
        
        if ($time < 60) return 'agora mesmo';
        if ($time < 3600) return floor($time/60) . ' min atrás';
        if ($time < 86400) return floor($time/3600) . ' h atrás';
        if ($time < 2592000) return floor($time/86400) . ' dias atrás';
        if ($time < 31536000) return floor($time/2592000) . ' meses atrás';
        
        return floor($time/31536000) . ' anos atrás';
    }
    
    /**
     * Verifica se é requisição AJAX
     */
    private function isAjaxRequest()
    {
        return isset($_SERVER['HTTP_X_REQUESTED_WITH']) && 
               strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) === 'xmlhttprequest';
    }
    
    /**
     * Renderiza uma view
     */
    private function view($view, $data = [])
    {
        // Extrair variáveis para o escopo da view
        extract($data);
        
        // Incluir header
        include APP_ROOT . '/app/views/layouts/header.php';
        
        // Incluir view específica
        $viewFile = APP_ROOT . '/app/views/' . $view . '.php';
        if (file_exists($viewFile)) {
            include $viewFile;
        } else {
            throw new Exception("View não encontrada: {$view}");
        }
        
        // Incluir footer
        include APP_ROOT . '/app/views/layouts/footer.php';
    }
    
    /**
     * Redireciona para uma URL
     */
    private function redirect($url)
    {
        header("Location: {$url}");
        exit;
    }
    
    /**
     * Define mensagem de sucesso
     */
    private function setSuccessMessage($message)
    {
        $_SESSION['success_message'] = $message;
    }
    
    /**
     * Define mensagem de erro
     */
    private function setErrorMessage($message)
    {
        $_SESSION['error_message'] = $message;
    }
}

