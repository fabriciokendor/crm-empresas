#!/bin/bash

# CRM Empresas - Script de Instalação
# Sistema de Gerenciamento de Relacionamento com Empresas

set -e

# Cores para output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Função para log
log() {
    echo -e "${GREEN}[$(date +'%Y-%m-%d %H:%M:%S')] $1${NC}"
}

error() {
    echo -e "${RED}[ERROR] $1${NC}" >&2
}

warning() {
    echo -e "${YELLOW}[WARNING] $1${NC}"
}

info() {
    echo -e "${BLUE}[INFO] $1${NC}"
}

# Verificar se está rodando como root
check_root() {
    if [[ $EUID -eq 0 ]]; then
        error "Este script não deve ser executado como root!"
        exit 1
    fi
}

# Verificar sistema operacional
check_os() {
    if [[ ! -f /etc/os-release ]]; then
        error "Sistema operacional não suportado"
        exit 1
    fi
    
    . /etc/os-release
    
    if [[ "$ID" != "ubuntu" ]] && [[ "$ID" != "debian" ]]; then
        warning "Sistema não testado. Continuando mesmo assim..."
    fi
    
    log "Sistema detectado: $PRETTY_NAME"
}

# Verificar dependências
check_dependencies() {
    log "Verificando dependências..."
    
    local deps=("apache2" "mysql-server" "php" "php-mysql" "php-mbstring" "php-xml" "php-curl" "php-zip" "php-gd")
    local missing=()
    
    for dep in "${deps[@]}"; do
        if ! dpkg -l | grep -q "^ii  $dep "; then
            missing+=("$dep")
        fi
    done
    
    if [[ ${#missing[@]} -gt 0 ]]; then
        error "Dependências não encontradas: ${missing[*]}"
        info "Execute: sudo apt update && sudo apt install ${missing[*]}"
        exit 1
    fi
    
    log "Todas as dependências estão instaladas"
}

# Configurar permissões
setup_permissions() {
    log "Configurando permissões..."
    
    # Criar diretórios necessários
    mkdir -p storage/{backups,sessions,tmp,logs}
    mkdir -p uploads
    
    # Definir permissões
    chmod 755 .
    chmod 755 public
    chmod -R 755 app
    chmod -R 755 config
    chmod -R 755 database
    chmod -R 777 storage
    chmod -R 777 uploads
    
    # Proprietário Apache
    if getent group www-data > /dev/null 2>&1; then
        sudo chown -R $USER:www-data storage uploads
        sudo chmod -R g+w storage uploads
    fi
    
    log "Permissões configuradas"
}

# Configurar banco de dados
setup_database() {
    log "Configurando banco de dados..."
    
    read -p "Nome do banco de dados [crm_empresas]: " DB_NAME
    DB_NAME=${DB_NAME:-crm_empresas}
    
    read -p "Usuário do banco [crm_user]: " DB_USER
    DB_USER=${DB_USER:-crm_user}
    
    read -s -p "Senha do usuário: " DB_PASS
    echo
    
    read -p "Host do banco [localhost]: " DB_HOST
    DB_HOST=${DB_HOST:-localhost}
    
    # Criar banco e usuário
    mysql -u root -p << EOF
CREATE DATABASE IF NOT EXISTS $DB_NAME CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
CREATE USER IF NOT EXISTS '$DB_USER'@'$DB_HOST' IDENTIFIED BY '$DB_PASS';
GRANT ALL PRIVILEGES ON $DB_NAME.* TO '$DB_USER'@'$DB_HOST';
FLUSH PRIVILEGES;
EOF
    
    # Atualizar configuração
    sed -i "s/'database' => 'crm_empresas'/'database' => '$DB_NAME'/" config/database.php
    sed -i "s/'username' => 'root'/'username' => '$DB_USER'/" config/database.php
    sed -i "s/'password' => ''/'password' => '$DB_PASS'/" config/database.php
    sed -i "s/'host' => 'localhost'/'host' => '$DB_HOST'/" config/database.php
    
    # Executar migrations
    mysql -u $DB_USER -p$DB_PASS -h $DB_HOST $DB_NAME < database/migrations/create_tables.sql
    mysql -u $DB_USER -p$DB_PASS -h $DB_HOST $DB_NAME < database/migrations/optimize_indexes.sql
    mysql -u $DB_USER -p$DB_PASS -h $DB_HOST $DB_NAME < database/seeds/initial_data.sql
    
    log "Banco de dados configurado"
}

# Configurar Apache
setup_apache() {
    log "Configurando Apache..."
    
    read -p "Domínio do site [crm-empresas.local]: " DOMAIN
    DOMAIN=${DOMAIN:-crm-empresas.local}
    
    read -p "Caminho de instalação [/var/www/html/crm-empresas]: " INSTALL_PATH
    INSTALL_PATH=${INSTALL_PATH:-/var/www/html/crm-empresas}
    
    # Atualizar configuração do Apache
    sed -i "s/crm-empresas.local/$DOMAIN/g" apache-config.conf
    sed -i "s|/var/www/html/crm-empresas|$INSTALL_PATH|g" apache-config.conf
    
    # Copiar configuração
    sudo cp apache-config.conf /etc/apache2/sites-available/crm-empresas.conf
    
    # Habilitar site e módulos
    sudo a2ensite crm-empresas
    sudo a2enmod rewrite headers deflate expires ssl
    
    # Adicionar ao hosts se for local
    if [[ "$DOMAIN" == *.local ]]; then
        if ! grep -q "$DOMAIN" /etc/hosts; then
            echo "127.0.0.1 $DOMAIN" | sudo tee -a /etc/hosts
        fi
    fi
    
    # Reiniciar Apache
    sudo systemctl reload apache2
    
    log "Apache configurado para $DOMAIN"
}

# Configurar cron para backup
setup_cron() {
    log "Configurando backup automático..."
    
    read -p "Configurar backup automático? [y/N]: " SETUP_BACKUP
    
    if [[ "$SETUP_BACKUP" =~ ^[Yy]$ ]]; then
        read -p "Frequência (diario/semanal/mensal) [diario]: " FREQ
        FREQ=${FREQ:-diario}
        
        read -p "Hora (HH:MM) [02:00]: " TIME
        TIME=${TIME:-02:00}
        
        IFS=':' read -r HOUR MINUTE <<< "$TIME"
        
        case $FREQ in
            "diario")
                CRON_EXPR="$MINUTE $HOUR * * *"
                ;;
            "semanal")
                CRON_EXPR="$MINUTE $HOUR * * 0"
                ;;
            "mensal")
                CRON_EXPR="$MINUTE $HOUR 1 * *"
                ;;
            *)
                CRON_EXPR="$MINUTE $HOUR * * *"
                ;;
        esac
        
        # Adicionar ao crontab
        (crontab -l 2>/dev/null; echo "$CRON_EXPR /usr/bin/php $(pwd)/public/index.php backup/auto >> /var/log/crm-backup.log 2>&1") | crontab -
        
        log "Backup automático configurado: $FREQ às $TIME"
    fi
}

# Configurar SSL (Let's Encrypt)
setup_ssl() {
    read -p "Configurar SSL com Let's Encrypt? [y/N]: " SETUP_SSL
    
    if [[ "$SETUP_SSL" =~ ^[Yy]$ ]]; then
        if ! command -v certbot &> /dev/null; then
            info "Instalando Certbot..."
            sudo apt update
            sudo apt install -y certbot python3-certbot-apache
        fi
        
        read -p "Email para Let's Encrypt: " EMAIL
        
        sudo certbot --apache -d $DOMAIN --email $EMAIL --agree-tos --non-interactive
        
        log "SSL configurado com Let's Encrypt"
    fi
}

# Teste de instalação
test_installation() {
    log "Testando instalação..."
    
    # Testar conexão com banco
    php -r "
    include 'config/database.php';
    try {
        \$pdo = new PDO(\"mysql:host={\$config['host']};dbname={\$config['database']}\", \$config['username'], \$config['password']);
        echo 'Conexão com banco: OK\n';
    } catch (Exception \$e) {
        echo 'Erro na conexão: ' . \$e->getMessage() . '\n';
        exit(1);
    }
    "
    
    # Testar permissões
    if [[ -w storage && -w uploads ]]; then
        echo "Permissões de escrita: OK"
    else
        error "Problemas com permissões de escrita"
        exit 1
    fi
    
    # Testar Apache
    if curl -s -o /dev/null -w "%{http_code}" "http://$DOMAIN" | grep -q "200\|302"; then
        echo "Apache respondendo: OK"
    else
        warning "Apache pode não estar respondendo corretamente"
    fi
    
    log "Testes concluídos"
}

# Exibir informações finais
show_final_info() {
    echo
    echo "=============================================="
    echo "  CRM EMPRESAS - INSTALAÇÃO CONCLUÍDA"
    echo "=============================================="
    echo
    echo "URL do sistema: http://$DOMAIN"
    echo "Usuário admin padrão: admin@admin.com"
    echo "Senha padrão: admin123"
    echo
    echo "IMPORTANTE:"
    echo "1. Altere a senha do administrador imediatamente"
    echo "2. Configure SSL para produção"
    echo "3. Revise as configurações de segurança"
    echo "4. Configure backup automático"
    echo
    echo "Logs do sistema:"
    echo "- Apache: /var/log/apache2/crm-empresas-*.log"
    echo "- Backup: /var/log/crm-backup.log"
    echo "- Sistema: $(pwd)/storage/logs/"
    echo
    echo "Documentação: README.md"
    echo "=============================================="
}

# Função principal
main() {
    echo "=============================================="
    echo "  CRM EMPRESAS - INSTALAÇÃO AUTOMÁTICA"
    echo "=============================================="
    echo
    
    check_root
    check_os
    check_dependencies
    
    log "Iniciando instalação..."
    
    setup_permissions
    setup_database
    setup_apache
    setup_cron
    setup_ssl
    test_installation
    
    show_final_info
    
    log "Instalação concluída com sucesso!"
}

# Executar apenas se chamado diretamente
if [[ "${BASH_SOURCE[0]}" == "${0}" ]]; then
    main "$@"
fi

