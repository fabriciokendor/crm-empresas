<?php
/**
 * Classe de Autenticação
 * Sistema de Gerenciamento de Relacionamento com Empresas
 */

class Auth
{
    private static $user = null;
    private static $config = [];
    
    /**
     * Inicializa a classe de autenticação
     */
    public static function init()
    {
        self::$config = require __DIR__ . '/../../config/config.php';
        
        // Configurar sessão
        if (session_status() === PHP_SESSION_NONE) {
            $sessionConfig = self::$config['session'];
            
            session_name($sessionConfig['name']);
            session_set_cookie_params([
                'lifetime' => $sessionConfig['lifetime'],
                'path' => $sessionConfig['path'],
                'domain' => $sessionConfig['domain'],
                'secure' => $sessionConfig['secure'],
                'httponly' => $sessionConfig['httponly'],
                'samesite' => $sessionConfig['samesite']
            ]);
            
            session_start();
        }
        
        // Regenerar ID da sessão periodicamente
        self::regenerateSessionId();
        
        // Carregar usuário da sessão
        self::loadUserFromSession();
    }
    
    /**
     * Tenta fazer login com email e senha
     */
    public static function attempt($email, $password, $remember = false)
    {
        // Verificar tentativas de login
        if (self::tooManyAttempts($email)) {
            throw new Exception('Muitas tentativas de login. Tente novamente em ' . 
                self::getRemainingLockoutTime($email) . ' minutos.');
        }
        
        $db = Database::getInstance();
        
        $user = $db->selectOne(
            "SELECT * FROM usuarios WHERE email = ? AND ativo = 1",
            [$email]
        );
        
        if ($user && password_verify($password, $user['senha'])) {
            // Login bem-sucedido
            self::login($user, $remember);
            self::clearLoginAttempts($email);
            self::updateLastLogin($user['id']);
            
            return true;
        } else {
            // Login falhou
            self::recordLoginAttempt($email);
            return false;
        }
    }
    
    /**
     * Faz login do usuário
     */
    public static function login($user, $remember = false)
    {
        self::$user = $user;
        
        // Regenerar ID da sessão por segurança
        session_regenerate_id(true);
        
        // Armazenar dados na sessão
        $_SESSION['user_id'] = $user['id'];
        $_SESSION['user_email'] = $user['email'];
        $_SESSION['user_nivel'] = $user['nivel_acesso'];
        $_SESSION['login_time'] = time();
        $_SESSION['last_activity'] = time();
        
        // Registrar sessão no banco
        self::registerSession($user['id']);
        
        // Cookie "lembrar-me" (opcional)
        if ($remember) {
            self::setRememberToken($user['id']);
        }
        
        // Log da ação
        self::logAction('login', $user['id']);
    }
    
    /**
     * Faz logout do usuário
     */
    public static function logout()
    {
        if (self::check()) {
            // Log da ação
            self::logAction('logout', self::id());
            
            // Remover sessão do banco
            self::removeSession();
            
            // Limpar cookie "lembrar-me"
            self::clearRememberToken();
        }
        
        // Limpar dados da sessão
        self::$user = null;
        session_unset();
        session_destroy();
        
        // Iniciar nova sessão
        session_start();
        session_regenerate_id(true);
    }
    
    /**
     * Verifica se o usuário está autenticado
     */
    public static function check()
    {
        return self::$user !== null;
    }
    
    /**
     * Verifica se o usuário é convidado (não autenticado)
     */
    public static function guest()
    {
        return !self::check();
    }
    
    /**
     * Retorna o usuário autenticado
     */
    public static function user()
    {
        return self::$user;
    }
    
    /**
     * Retorna o ID do usuário autenticado
     */
    public static function id()
    {
        return self::check() ? self::$user['id'] : null;
    }
    
    /**
     * Verifica se o usuário tem um nível de acesso específico
     */
    public static function hasRole($role)
    {
        if (!self::check()) {
            return false;
        }
        
        $userRole = self::$user['nivel_acesso'];
        
        // Hierarquia de níveis
        $hierarchy = ['visualizador', 'operador', 'admin'];
        $userLevel = array_search($userRole, $hierarchy);
        $requiredLevel = array_search($role, $hierarchy);
        
        return $userLevel !== false && $requiredLevel !== false && $userLevel >= $requiredLevel;
    }
    
    /**
     * Verifica se o usuário é administrador
     */
    public static function isAdmin()
    {
        return self::hasRole('admin');
    }
    
    /**
     * Carrega o usuário da sessão
     */
    private static function loadUserFromSession()
    {
        if (isset($_SESSION['user_id'])) {
            // Verificar se a sessão não expirou
            if (self::sessionExpired()) {
                self::logout();
                return;
            }
            
            // Atualizar última atividade
            $_SESSION['last_activity'] = time();
            
            // Carregar dados do usuário
            $db = Database::getInstance();
            self::$user = $db->selectOne(
                "SELECT * FROM usuarios WHERE id = ? AND ativo = 1",
                [$_SESSION['user_id']]
            );
            
            if (!self::$user) {
                // Usuário não encontrado ou inativo
                self::logout();
            }
        }
    }
    
    /**
     * Verifica se a sessão expirou
     */
    private static function sessionExpired()
    {
        $lastActivity = $_SESSION['last_activity'] ?? 0;
        $sessionLifetime = self::$config['session']['lifetime'];
        
        return (time() - $lastActivity) > $sessionLifetime;
    }
    
    /**
     * Regenera o ID da sessão periodicamente
     */
    private static function regenerateSessionId()
    {
        $interval = self::$config['security']['session_regenerate_interval'];
        $lastRegeneration = $_SESSION['last_regeneration'] ?? 0;
        
        if ((time() - $lastRegeneration) > $interval) {
            session_regenerate_id(true);
            $_SESSION['last_regeneration'] = time();
        }
    }
    
    /**
     * Registra a sessão no banco de dados
     */
    private static function registerSession($userId)
    {
        $db = Database::getInstance();
        
        // Remover sessões antigas do usuário
        $db->delete("DELETE FROM sessoes WHERE usuario_id = ?", [$userId]);
        
        // Inserir nova sessão
        $db->insert(
            "INSERT INTO sessoes (id, usuario_id, ip_address, user_agent, dados_sessao) VALUES (?, ?, ?, ?, ?)",
            [
                session_id(),
                $userId,
                $_SERVER['REMOTE_ADDR'] ?? '',
                $_SERVER['HTTP_USER_AGENT'] ?? '',
                json_encode($_SESSION)
            ]
        );
    }
    
    /**
     * Remove a sessão do banco de dados
     */
    private static function removeSession()
    {
        $db = Database::getInstance();
        $db->delete("DELETE FROM sessoes WHERE id = ?", [session_id()]);
    }
    
    /**
     * Atualiza o último login do usuário
     */
    private static function updateLastLogin($userId)
    {
        $db = Database::getInstance();
        $db->update(
            "UPDATE usuarios SET ultimo_login = NOW() WHERE id = ?",
            [$userId]
        );
    }
    
    /**
     * Verifica se há muitas tentativas de login
     */
    private static function tooManyAttempts($email)
    {
        $cacheKey = 'login_attempts_' . md5($email);
        $attempts = self::getFromCache($cacheKey, []);
        
        $maxAttempts = self::$config['security']['max_login_attempts'];
        $lockoutDuration = self::$config['security']['lockout_duration'];
        
        // Limpar tentativas antigas
        $attempts = array_filter($attempts, function($time) use ($lockoutDuration) {
            return (time() - $time) < $lockoutDuration;
        });
        
        return count($attempts) >= $maxAttempts;
    }
    
    /**
     * Registra uma tentativa de login
     */
    private static function recordLoginAttempt($email)
    {
        $cacheKey = 'login_attempts_' . md5($email);
        $attempts = self::getFromCache($cacheKey, []);
        $attempts[] = time();
        
        self::putInCache($cacheKey, $attempts, self::$config['security']['lockout_duration']);
    }
    
    /**
     * Limpa as tentativas de login
     */
    private static function clearLoginAttempts($email)
    {
        $cacheKey = 'login_attempts_' . md5($email);
        self::removeFromCache($cacheKey);
    }
    
    /**
     * Retorna o tempo restante de bloqueio
     */
    private static function getRemainingLockoutTime($email)
    {
        $cacheKey = 'login_attempts_' . md5($email);
        $attempts = self::getFromCache($cacheKey, []);
        
        if (empty($attempts)) {
            return 0;
        }
        
        $lockoutDuration = self::$config['security']['lockout_duration'];
        $lastAttempt = max($attempts);
        $remaining = $lockoutDuration - (time() - $lastAttempt);
        
        return max(0, ceil($remaining / 60)); // em minutos
    }
    
    /**
     * Define token "lembrar-me"
     */
    private static function setRememberToken($userId)
    {
        $token = bin2hex(random_bytes(32));
        $hashedToken = hash('sha256', $token);
        
        $db = Database::getInstance();
        $db->update(
            "UPDATE usuarios SET remember_token = ? WHERE id = ?",
            [$hashedToken, $userId]
        );
        
        // Cookie válido por 30 dias
        setcookie('remember_token', $token, time() + (30 * 24 * 60 * 60), '/', '', false, true);
    }
    
    /**
     * Limpa o token "lembrar-me"
     */
    private static function clearRememberToken()
    {
        if (self::check()) {
            $db = Database::getInstance();
            $db->update(
                "UPDATE usuarios SET remember_token = NULL WHERE id = ?",
                [self::id()]
            );
        }
        
        setcookie('remember_token', '', time() - 3600, '/');
    }
    
    /**
     * Registra uma ação no log
     */
    private static function logAction($action, $userId = null)
    {
        $db = Database::getInstance();
        $db->insert(
            "INSERT INTO logs_sistema (usuario_id, acao, ip_address, user_agent) VALUES (?, ?, ?, ?)",
            [
                $userId,
                $action,
                $_SERVER['REMOTE_ADDR'] ?? '',
                $_SERVER['HTTP_USER_AGENT'] ?? ''
            ]
        );
    }
    
    /**
     * Métodos auxiliares de cache (implementação simples com arquivos)
     */
    private static function getFromCache($key, $default = null)
    {
        $cacheFile = sys_get_temp_dir() . '/crm_cache_' . $key;
        
        if (file_exists($cacheFile)) {
            $data = unserialize(file_get_contents($cacheFile));
            if ($data['expires'] > time()) {
                return $data['value'];
            } else {
                unlink($cacheFile);
            }
        }
        
        return $default;
    }
    
    private static function putInCache($key, $value, $ttl = 3600)
    {
        $cacheFile = sys_get_temp_dir() . '/crm_cache_' . $key;
        $data = [
            'value' => $value,
            'expires' => time() + $ttl
        ];
        
        file_put_contents($cacheFile, serialize($data), LOCK_EX);
    }
    
    private static function removeFromCache($key)
    {
        $cacheFile = sys_get_temp_dir() . '/crm_cache_' . $key;
        if (file_exists($cacheFile)) {
            unlink($cacheFile);
        }
    }
}

