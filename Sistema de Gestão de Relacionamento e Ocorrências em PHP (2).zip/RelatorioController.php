<?php
/**
 * Controller de Relatórios
 * Sistema de Gerenciamento de Relacionamento com Empresas
 */

class RelatorioController
{
    private $db;
    private $empresaModel;
    private $ocorrenciaModel;
    private $usuarioModel;
    
    public function __construct()
    {
        $this->db = Database::getInstance();
        $this->empresaModel = new Empresa();
        $this->ocorrenciaModel = new Ocorrencia();
        $this->usuarioModel = new Usuario();
        
        // Verificar autenticação
        if (!Auth::check()) {
            header('Location: /login');
            exit;
        }
    }
    
    /**
     * Página principal de relatórios
     */
    public function index()
    {
        // Verificar permissão
        if (!$this->can('view_relatorios')) {
            $this->setErrorMessage('Você não tem permissão para visualizar relatórios.');
            $this->redirect('/dashboard');
            return;
        }
        
        // Estatísticas gerais
        $stats = $this->getEstatisticasGerais();
        
        // Dados para gráficos
        $ocorrenciasPorMes = $this->getOcorrenciasPorMes();
        $ocorrenciasPorTipo = $this->getOcorrenciasPorTipo();
        $empresasTop = $this->getTopEmpresas(10);
        $usuariosAtivos = $this->getUsuariosMaisAtivos(10);
        
        $data = [
            'title' => 'Relatórios - CRM Empresas',
            'stats' => $stats,
            'ocorrencias_por_mes' => $ocorrenciasPorMes,
            'ocorrencias_por_tipo' => $ocorrenciasPorTipo,
            'empresas_top' => $empresasTop,
            'usuarios_ativos' => $usuariosAtivos,
            'can_export' => $this->can('export_relatorios')
        ];
        
        $this->view('relatorios/index', $data);
    }
    
    /**
     * Relatório de ranking de empresas
     */
    public function ranking()
    {
        if (!$this->can('view_relatorios')) {
            $this->setErrorMessage('Você não tem permissão para visualizar relatórios.');
            $this->redirect('/dashboard');
            return;
        }
        
        $periodo = $_GET['periodo'] ?? '12';
        $limite = min((int)($_GET['limite'] ?? 50), 100);
        
        $ranking = $this->getRankingEmpresas($periodo, $limite);
        $estatisticas = $this->getEstatisticasRanking($periodo);
        
        $data = [
            'title' => 'Ranking de Empresas - CRM Empresas',
            'ranking' => $ranking,
            'estatisticas' => $estatisticas,
            'periodo' => $periodo,
            'limite' => $limite,
            'can_export' => $this->can('export_relatorios')
        ];
        
        $this->view('relatorios/ranking', $data);
    }
    
    /**
     * Relatório de ocorrências
     */
    public function ocorrencias()
    {
        if (!$this->can('view_relatorios')) {
            $this->setErrorMessage('Você não tem permissão para visualizar relatórios.');
            $this->redirect('/dashboard');
            return;
        }
        
        $filtros = [
            'data_inicio' => $_GET['data_inicio'] ?? date('Y-m-01'),
            'data_fim' => $_GET['data_fim'] ?? date('Y-m-t'),
            'empresa_id' => $_GET['empresa_id'] ?? '',
            'tipo_ocorrencia_id' => $_GET['tipo_ocorrencia_id'] ?? '',
            'status' => $_GET['status'] ?? '',
            'usuario_id' => $_GET['usuario_id'] ?? ''
        ];
        
        $ocorrencias = $this->getRelatorioOcorrencias($filtros);
        $resumo = $this->getResumoOcorrencias($filtros);
        $graficos = $this->getGraficosOcorrencias($filtros);
        
        // Dados para filtros
        $empresas = $this->empresaModel->all(true);
        $tiposOcorrencia = $this->db->select("SELECT * FROM tipos_ocorrencia WHERE ativo = 1 ORDER BY nome");
        $usuarios = $this->usuarioModel->all(true);
        
        $data = [
            'title' => 'Relatório de Ocorrências - CRM Empresas',
            'ocorrencias' => $ocorrencias,
            'resumo' => $resumo,
            'graficos' => $graficos,
            'filtros' => $filtros,
            'empresas' => $empresas,
            'tipos_ocorrencia' => $tiposOcorrencia,
            'usuarios' => $usuarios,
            'can_export' => $this->can('export_relatorios')
        ];
        
        $this->view('relatorios/ocorrencias', $data);
    }
    
    /**
     * Relatório de usuários
     */
    public function usuarios()
    {
        if (!$this->can('view_relatorios') || !Auth::isAdmin()) {
            $this->setErrorMessage('Você não tem permissão para visualizar este relatório.');
            $this->redirect('/relatorios');
            return;
        }
        
        $periodo = $_GET['periodo'] ?? '12';
        
        $usuarios = $this->getRelatorioUsuarios($periodo);
        $estatisticas = $this->getEstatisticasUsuarios($periodo);
        $atividades = $this->getAtividadesPorUsuario($periodo);
        
        $data = [
            'title' => 'Relatório de Usuários - CRM Empresas',
            'usuarios' => $usuarios,
            'estatisticas' => $estatisticas,
            'atividades' => $atividades,
            'periodo' => $periodo,
            'can_export' => $this->can('export_relatorios')
        ];
        
        $this->view('relatorios/usuarios', $data);
    }
    
    /**
     * Dados para dashboard (AJAX)
     */
    public function dashboardData()
    {
        if (!$this->isAjaxRequest()) {
            http_response_code(400);
            return;
        }
        
        $data = [
            'stats' => $this->getEstatisticasGerais(),
            'ocorrencias_mes' => $this->getOcorrenciasPorMes(6),
            'top_empresas' => $this->getTopEmpresas(5),
            'ocorrencias_tipo' => $this->getOcorrenciasPorTipo(),
            'usuarios_ativos' => $this->getUsuariosMaisAtivos(5)
        ];
        
        header('Content-Type: application/json');
        echo json_encode($data);
    }
    
    /**
     * Exporta relatórios
     */
    public function export()
    {
        if (!$this->can('export_relatorios')) {
            $this->setErrorMessage('Você não tem permissão para exportar relatórios.');
            $this->redirect('/relatorios');
            return;
        }
        
        $tipo = $_GET['tipo'] ?? 'ranking';
        $formato = $_GET['formato'] ?? 'csv';
        
        switch ($tipo) {
            case 'ranking':
                $this->exportRanking($formato);
                break;
            case 'ocorrencias':
                $this->exportOcorrencias($formato);
                break;
            case 'usuarios':
                $this->exportUsuarios($formato);
                break;
            default:
                $this->setErrorMessage('Tipo de relatório inválido.');
                $this->redirect('/relatorios');
        }
    }
    
    /**
     * Métodos privados para coleta de dados
     */
    private function getEstatisticasGerais()
    {
        return [
            'total_empresas' => $this->empresaModel->count(true),
            'total_usuarios' => $this->usuarioModel->count(true),
            'total_ocorrencias' => $this->ocorrenciaModel->countByStatus(''),
            'ocorrencias_abertas' => $this->ocorrenciaModel->countByStatus('aberta') + $this->ocorrenciaModel->countByStatus('em_andamento'),
            'ocorrencias_resolvidas' => $this->ocorrenciaModel->countByStatus('resolvida') + $this->ocorrenciaModel->countByStatus('fechada'),
            'ocorrencias_mes' => $this->getOcorrenciasMesAtual(),
            'empresas_ativas' => $this->getEmpresasComOcorrenciasMes(),
            'tempo_medio_resolucao' => $this->getTempoMedioResolucao()
        ];
    }
    
    private function getOcorrenciasPorMes($meses = 12)
    {
        return $this->db->select(
            "SELECT 
                DATE_FORMAT(data_ocorrencia, '%Y-%m') as mes,
                DATE_FORMAT(data_ocorrencia, '%m/%Y') as mes_formatado,
                COUNT(*) as total
             FROM ocorrencias
             WHERE data_ocorrencia >= DATE_SUB(NOW(), INTERVAL ? MONTH)
             GROUP BY DATE_FORMAT(data_ocorrencia, '%Y-%m')
             ORDER BY mes",
            [$meses]
        );
    }
    
    private function getOcorrenciasPorTipo()
    {
        return $this->db->select(
            "SELECT 
                t.nome,
                t.cor,
                COUNT(o.id) as total,
                ROUND((COUNT(o.id) * 100.0 / (SELECT COUNT(*) FROM ocorrencias)), 1) as percentual
             FROM tipos_ocorrencia t
             LEFT JOIN ocorrencias o ON t.id = o.tipo_ocorrencia_id
             WHERE t.ativo = 1
             GROUP BY t.id, t.nome, t.cor
             ORDER BY total DESC"
        );
    }
    
    private function getTopEmpresas($limite = 10)
    {
        return $this->db->select(
            "SELECT 
                e.id,
                e.razao_social,
                e.nome_fantasia,
                e.contato_principal,
                COUNT(o.id) as total_ocorrencias,
                COUNT(CASE WHEN o.status IN ('aberta', 'em_andamento') THEN 1 END) as ocorrencias_abertas,
                COUNT(CASE WHEN o.status IN ('resolvida', 'fechada') THEN 1 END) as ocorrencias_fechadas,
                MAX(o.data_ocorrencia) as ultima_ocorrencia,
                ROUND(AVG(CASE 
                    WHEN o.status IN ('resolvida', 'fechada') AND o.data_resolucao IS NOT NULL 
                    THEN DATEDIFF(o.data_resolucao, o.data_ocorrencia) 
                END), 1) as tempo_medio_resolucao
             FROM empresas e
             LEFT JOIN ocorrencias o ON e.id = o.empresa_id
             WHERE e.ativo = 1
             GROUP BY e.id, e.razao_social, e.nome_fantasia, e.contato_principal
             HAVING total_ocorrencias > 0
             ORDER BY total_ocorrencias DESC
             LIMIT ?",
            [$limite]
        );
    }
    
    private function getUsuariosMaisAtivos($limite = 10)
    {
        return $this->db->select(
            "SELECT 
                u.id,
                u.nome,
                u.email,
                u.nivel_acesso,
                COUNT(o.id) as total_ocorrencias,
                COUNT(CASE WHEN o.status IN ('resolvida', 'fechada') THEN 1 END) as ocorrencias_resolvidas,
                COUNT(CASE WHEN o.data_ocorrencia >= DATE_SUB(NOW(), INTERVAL 30 DAY) THEN 1 END) as ocorrencias_mes,
                MAX(o.data_ocorrencia) as ultima_atividade
             FROM usuarios u
             LEFT JOIN ocorrencias o ON u.id = o.usuario_id
             WHERE u.ativo = 1
             GROUP BY u.id, u.nome, u.email, u.nivel_acesso
             ORDER BY total_ocorrencias DESC
             LIMIT ?",
            [$limite]
        );
    }
    
    private function getRankingEmpresas($periodo, $limite)
    {
        $whereClause = '';
        $params = [$limite];
        
        if ($periodo !== 'todos') {
            $whereClause = "AND o.data_ocorrencia >= DATE_SUB(NOW(), INTERVAL ? MONTH)";
            array_unshift($params, $periodo);
        }
        
        return $this->db->select(
            "SELECT 
                e.id,
                e.razao_social,
                e.nome_fantasia,
                e.contato_principal,
                e.telefone,
                e.email,
                COUNT(o.id) as total_ocorrencias,
                COUNT(CASE WHEN o.status = 'aberta' THEN 1 END) as abertas,
                COUNT(CASE WHEN o.status = 'em_andamento' THEN 1 END) as em_andamento,
                COUNT(CASE WHEN o.status = 'resolvida' THEN 1 END) as resolvidas,
                COUNT(CASE WHEN o.status = 'fechada' THEN 1 END) as fechadas,
                MIN(o.data_ocorrencia) as primeira_ocorrencia,
                MAX(o.data_ocorrencia) as ultima_ocorrencia,
                ROUND(AVG(CASE 
                    WHEN o.status IN ('resolvida', 'fechada') AND o.data_resolucao IS NOT NULL 
                    THEN DATEDIFF(o.data_resolucao, o.data_ocorrencia) 
                END), 1) as tempo_medio_resolucao
             FROM empresas e
             LEFT JOIN ocorrencias o ON e.id = o.empresa_id {$whereClause}
             WHERE e.ativo = 1
             GROUP BY e.id, e.razao_social, e.nome_fantasia, e.contato_principal, e.telefone, e.email
             HAVING total_ocorrencias > 0
             ORDER BY total_ocorrencias DESC
             LIMIT ?",
            $params
        );
    }
    
    private function getRelatorioOcorrencias($filtros)
    {
        $sql = "
            SELECT 
                o.*,
                e.razao_social as empresa_nome,
                u.nome as usuario_nome,
                t.nome as tipo_nome,
                t.cor as tipo_cor,
                CASE 
                    WHEN o.data_resolucao IS NOT NULL 
                    THEN DATEDIFF(o.data_resolucao, o.data_ocorrencia)
                    ELSE DATEDIFF(NOW(), o.data_ocorrencia)
                END as dias_duracao
            FROM ocorrencias o
            INNER JOIN empresas e ON o.empresa_id = e.id
            INNER JOIN usuarios u ON o.usuario_id = u.id
            INNER JOIN tipos_ocorrencia t ON o.tipo_ocorrencia_id = t.id
            WHERE o.data_ocorrencia BETWEEN ? AND ?
        ";
        
        $params = [$filtros['data_inicio'], $filtros['data_fim'] . ' 23:59:59'];
        
        if (!empty($filtros['empresa_id'])) {
            $sql .= " AND o.empresa_id = ?";
            $params[] = $filtros['empresa_id'];
        }
        
        if (!empty($filtros['tipo_ocorrencia_id'])) {
            $sql .= " AND o.tipo_ocorrencia_id = ?";
            $params[] = $filtros['tipo_ocorrencia_id'];
        }
        
        if (!empty($filtros['status'])) {
            $sql .= " AND o.status = ?";
            $params[] = $filtros['status'];
        }
        
        if (!empty($filtros['usuario_id'])) {
            $sql .= " AND o.usuario_id = ?";
            $params[] = $filtros['usuario_id'];
        }
        
        $sql .= " ORDER BY o.data_ocorrencia DESC";
        
        return $this->db->select($sql, $params);
    }
    
    private function getResumoOcorrencias($filtros)
    {
        $sql = "
            SELECT 
                COUNT(*) as total,
                COUNT(CASE WHEN status = 'aberta' THEN 1 END) as abertas,
                COUNT(CASE WHEN status = 'em_andamento' THEN 1 END) as em_andamento,
                COUNT(CASE WHEN status = 'resolvida' THEN 1 END) as resolvidas,
                COUNT(CASE WHEN status = 'fechada' THEN 1 END) as fechadas,
                COUNT(CASE WHEN prioridade = 'critica' THEN 1 END) as criticas,
                COUNT(CASE WHEN prioridade = 'alta' THEN 1 END) as altas,
                ROUND(AVG(CASE 
                    WHEN status IN ('resolvida', 'fechada') AND data_resolucao IS NOT NULL 
                    THEN DATEDIFF(data_resolucao, data_ocorrencia) 
                END), 1) as tempo_medio_resolucao,
                COUNT(DISTINCT empresa_id) as empresas_envolvidas,
                COUNT(DISTINCT usuario_id) as usuarios_envolvidos
            FROM ocorrencias
            WHERE data_ocorrencia BETWEEN ? AND ?
        ";
        
        $params = [$filtros['data_inicio'], $filtros['data_fim'] . ' 23:59:59'];
        
        if (!empty($filtros['empresa_id'])) {
            $sql .= " AND empresa_id = ?";
            $params[] = $filtros['empresa_id'];
        }
        
        if (!empty($filtros['tipo_ocorrencia_id'])) {
            $sql .= " AND tipo_ocorrencia_id = ?";
            $params[] = $filtros['tipo_ocorrencia_id'];
        }
        
        if (!empty($filtros['status'])) {
            $sql .= " AND status = ?";
            $params[] = $filtros['status'];
        }
        
        if (!empty($filtros['usuario_id'])) {
            $sql .= " AND usuario_id = ?";
            $params[] = $filtros['usuario_id'];
        }
        
        return $this->db->selectOne($sql, $params);
    }
    
    private function getGraficosOcorrencias($filtros)
    {
        // Por status
        $porStatus = $this->db->select(
            "SELECT status, COUNT(*) as total 
             FROM ocorrencias 
             WHERE data_ocorrencia BETWEEN ? AND ?
             GROUP BY status",
            [$filtros['data_inicio'], $filtros['data_fim'] . ' 23:59:59']
        );
        
        // Por tipo
        $porTipo = $this->db->select(
            "SELECT t.nome, t.cor, COUNT(o.id) as total
             FROM tipos_ocorrencia t
             LEFT JOIN ocorrencias o ON t.id = o.tipo_ocorrencia_id 
                AND o.data_ocorrencia BETWEEN ? AND ?
             GROUP BY t.id, t.nome, t.cor
             HAVING total > 0
             ORDER BY total DESC",
            [$filtros['data_inicio'], $filtros['data_fim'] . ' 23:59:59']
        );
        
        // Por dia
        $porDia = $this->db->select(
            "SELECT 
                DATE(data_ocorrencia) as data,
                COUNT(*) as total
             FROM ocorrencias
             WHERE data_ocorrencia BETWEEN ? AND ?
             GROUP BY DATE(data_ocorrencia)
             ORDER BY data",
            [$filtros['data_inicio'], $filtros['data_fim'] . ' 23:59:59']
        );
        
        return [
            'por_status' => $porStatus,
            'por_tipo' => $porTipo,
            'por_dia' => $porDia
        ];
    }
    
    private function getOcorrenciasMesAtual()
    {
        $result = $this->db->selectOne(
            "SELECT COUNT(*) as total FROM ocorrencias 
             WHERE MONTH(data_ocorrencia) = MONTH(NOW()) 
             AND YEAR(data_ocorrencia) = YEAR(NOW())"
        );
        return $result['total'];
    }
    
    private function getEmpresasComOcorrenciasMes()
    {
        $result = $this->db->selectOne(
            "SELECT COUNT(DISTINCT empresa_id) as total FROM ocorrencias 
             WHERE MONTH(data_ocorrencia) = MONTH(NOW()) 
             AND YEAR(data_ocorrencia) = YEAR(NOW())"
        );
        return $result['total'];
    }
    
    private function getTempoMedioResolucao()
    {
        $result = $this->db->selectOne(
            "SELECT ROUND(AVG(DATEDIFF(data_resolucao, data_ocorrencia)), 1) as media
             FROM ocorrencias 
             WHERE status IN ('resolvida', 'fechada') 
             AND data_resolucao IS NOT NULL
             AND data_ocorrencia >= DATE_SUB(NOW(), INTERVAL 3 MONTH)"
        );
        return $result['media'] ?? 0;
    }
    
    /**
     * Métodos de exportação
     */
    private function exportRanking($formato)
    {
        $periodo = $_GET['periodo'] ?? '12';
        $limite = min((int)($_GET['limite'] ?? 50), 100);
        $ranking = $this->getRankingEmpresas($periodo, $limite);
        
        if ($formato === 'csv') {
            $this->exportRankingCsv($ranking);
        } else {
            $this->setErrorMessage('Formato de exportação não suportado.');
            $this->redirect('/relatorios/ranking');
        }
    }
    
    private function exportRankingCsv($ranking)
    {
        $filename = 'ranking_empresas_' . date('Y-m-d_H-i-s') . '.csv';
        
        header('Content-Type: text/csv; charset=utf-8');
        header('Content-Disposition: attachment; filename=' . $filename);
        
        $output = fopen('php://output', 'w');
        
        // BOM para UTF-8
        fprintf($output, chr(0xEF).chr(0xBB).chr(0xBF));
        
        // Cabeçalho
        fputcsv($output, [
            'Posição', 'Razão Social', 'Nome Fantasia', 'Contato Principal',
            'Total Ocorrências', 'Abertas', 'Em Andamento', 'Resolvidas', 'Fechadas',
            'Primeira Ocorrência', 'Última Ocorrência', 'Tempo Médio Resolução (dias)'
        ], ';');
        
        // Dados
        $posicao = 1;
        foreach ($ranking as $empresa) {
            fputcsv($output, [
                $posicao++,
                $empresa['razao_social'],
                $empresa['nome_fantasia'],
                $empresa['contato_principal'],
                $empresa['total_ocorrencias'],
                $empresa['abertas'],
                $empresa['em_andamento'],
                $empresa['resolvidas'],
                $empresa['fechadas'],
                $empresa['primeira_ocorrencia'] ? date('d/m/Y', strtotime($empresa['primeira_ocorrencia'])) : '',
                $empresa['ultima_ocorrencia'] ? date('d/m/Y', strtotime($empresa['ultima_ocorrencia'])) : '',
                $empresa['tempo_medio_resolucao'] ?? ''
            ], ';');
        }
        
        fclose($output);
    }
    
    /**
     * Métodos auxiliares
     */
    private function can($action)
    {
        if (!Auth::check()) {
            return false;
        }
        
        $userRole = Auth::user()['nivel_acesso'];
        
        $permissions = [
            'admin' => ['*'],
            'operador' => ['view_relatorios', 'export_relatorios'],
            'visualizador' => ['view_relatorios']
        ];
        
        $userPermissions = $permissions[$userRole] ?? [];
        
        return in_array('*', $userPermissions) || in_array($action, $userPermissions);
    }
    
    private function isAjaxRequest()
    {
        return isset($_SERVER['HTTP_X_REQUESTED_WITH']) && 
               strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) === 'xmlhttprequest';
    }
    
    private function view($view, $data = [])
    {
        extract($data);
        include APP_ROOT . '/app/views/layouts/header.php';
        $viewFile = APP_ROOT . '/app/views/' . $view . '.php';
        if (file_exists($viewFile)) {
            include $viewFile;
        } else {
            throw new Exception("View não encontrada: {$view}");
        }
        include APP_ROOT . '/app/views/layouts/footer.php';
    }
    
    private function redirect($url)
    {
        header("Location: {$url}");
        exit;
    }
    
    private function setSuccessMessage($message)
    {
        $_SESSION['success_message'] = $message;
    }
    
    private function setErrorMessage($message)
    {
        $_SESSION['error_message'] = $message;
    }
}

