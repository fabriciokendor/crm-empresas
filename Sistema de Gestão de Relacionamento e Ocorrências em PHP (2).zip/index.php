<?php
/**
 * Ponto de Entrada da Aplicação
 * Sistema de Gerenciamento de Relacionamento com Empresas
 */

// Definir constantes
define('APP_ROOT', dirname(__DIR__));
define('APP_START_TIME', microtime(true));

// Configurar timezone
date_default_timezone_set('America/Sao_Paulo');

// Configurar exibição de erros
if ($_ENV['APP_DEBUG'] ?? false) {
    error_reporting(E_ALL);
    ini_set('display_errors', 1);
} else {
    error_reporting(0);
    ini_set('display_errors', 0);
}

// Autoloader simples
spl_autoload_register(function ($class) {
    $paths = [
        APP_ROOT . '/app/controllers/',
        APP_ROOT . '/app/models/',
        APP_ROOT . '/app/helpers/',
        APP_ROOT . '/app/middleware/'
    ];
    
    foreach ($paths as $path) {
        $file = $path . $class . '.php';
        if (file_exists($file)) {
            require_once $file;
            return;
        }
    }
});

// Carregar configurações
$config = require APP_ROOT . '/config/config.php';
$routes = require APP_ROOT . '/config/routes.php';

// Inicializar autenticação
Auth::init();

// Classe principal da aplicação
class App
{
    private $config;
    private $routes;
    private $request;
    
    public function __construct($config, $routes)
    {
        $this->config = $config;
        $this->routes = $routes;
        $this->request = $this->parseRequest();
    }
    
    /**
     * Executa a aplicação
     */
    public function run()
    {
        try {
            // Aplicar middleware global
            $this->applyMiddleware();
            
            // Encontrar e executar rota
            $route = $this->findRoute();
            
            if ($route) {
                $this->executeRoute($route);
            } else {
                $this->handle404();
            }
            
        } catch (Exception $e) {
            $this->handleError($e);
        }
    }
    
    /**
     * Analisa a requisição
     */
    private function parseRequest()
    {
        $method = $_SERVER['REQUEST_METHOD'];
        $uri = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);
        
        // Remover trailing slash (exceto para root)
        if ($uri !== '/' && substr($uri, -1) === '/') {
            $uri = rtrim($uri, '/');
        }
        
        return [
            'method' => $method,
            'uri' => $uri,
            'query' => $_GET,
            'body' => $_POST,
            'files' => $_FILES,
            'headers' => getallheaders() ?: []
        ];
    }
    
    /**
     * Aplica middleware global
     */
    private function applyMiddleware()
    {
        $middlewareConfig = $this->routes['middleware'] ?? [];
        
        foreach ($middlewareConfig as $name => $config) {
            if ($this->shouldApplyMiddleware($name, $config)) {
                $middlewareClass = $config['class'];
                
                if (class_exists($middlewareClass)) {
                    $middleware = new $middlewareClass();
                    $middleware->handle($this->request);
                }
            }
        }
    }
    
    /**
     * Verifica se deve aplicar o middleware
     */
    private function shouldApplyMiddleware($name, $config)
    {
        $uri = $this->request['uri'];
        $method = $this->request['method'];
        
        // Verificar exceções
        if (isset($config['except'])) {
            foreach ($config['except'] as $pattern) {
                if ($this->matchPattern($pattern, $uri)) {
                    return false;
                }
            }
        }
        
        // Verificar rotas específicas
        if (isset($config['routes'])) {
            $routeGroup = $config['routes'];
            return $this->isRouteInGroup($uri, $routeGroup);
        }
        
        // Verificar métodos específicos
        if (isset($config['methods'])) {
            return in_array($method, $config['methods']);
        }
        
        return true;
    }
    
    /**
     * Encontra a rota correspondente
     */
    private function findRoute()
    {
        $method = $this->request['method'];
        $uri = $this->request['uri'];
        
        // Verificar todas as rotas
        foreach ($this->routes as $groupName => $group) {
            if (in_array($groupName, ['middleware', 'cache'])) {
                continue;
            }
            
            if (is_array($group)) {
                foreach ($group as $pattern => $handler) {
                    if ($this->matchRoute($pattern, $method, $uri)) {
                        return [
                            'group' => $groupName,
                            'pattern' => $pattern,
                            'handler' => $handler,
                            'params' => $this->extractParams($pattern, $uri)
                        ];
                    }
                }
            }
        }
        
        return null;
    }
    
    /**
     * Verifica se a rota corresponde
     */
    private function matchRoute($pattern, $method, $uri)
    {
        // Separar método e padrão
        $parts = explode(' ', $pattern, 2);
        $routeMethod = $parts[0];
        $routePattern = $parts[1] ?? $parts[0];
        
        // Verificar método
        if ($routeMethod !== $method && $routeMethod !== '*') {
            return false;
        }
        
        // Converter padrão para regex
        $regex = $this->patternToRegex($routePattern);
        
        return preg_match($regex, $uri);
    }
    
    /**
     * Converte padrão de rota para regex
     */
    private function patternToRegex($pattern)
    {
        // Escapar caracteres especiais
        $pattern = preg_quote($pattern, '/');
        
        // Substituir parâmetros {id} por regex
        $pattern = preg_replace('/\\\{([^}]+)\\\}/', '([^/]+)', $pattern);
        
        // Substituir wildcards
        $pattern = str_replace('\*', '.*', $pattern);
        
        return '/^' . $pattern . '$/';
    }
    
    /**
     * Extrai parâmetros da URL
     */
    private function extractParams($pattern, $uri)
    {
        $params = [];
        
        // Encontrar nomes dos parâmetros
        preg_match_all('/\{([^}]+)\}/', $pattern, $paramNames);
        
        // Extrair valores
        $regex = $this->patternToRegex($pattern);
        preg_match($regex, $uri, $matches);
        
        // Combinar nomes e valores
        for ($i = 0; $i < count($paramNames[1]); $i++) {
            $paramName = $paramNames[1][$i];
            $paramValue = $matches[$i + 1] ?? null;
            $params[$paramName] = $paramValue;
        }
        
        return $params;
    }
    
    /**
     * Executa a rota
     */
    private function executeRoute($route)
    {
        $handler = $route['handler'];
        $params = $route['params'];
        
        // Verificar autorização para grupos protegidos
        if (in_array($route['group'], ['protected', 'admin'])) {
            if (!Auth::check()) {
                $this->redirectToLogin();
                return;
            }
            
            if ($route['group'] === 'admin' && !Auth::isAdmin()) {
                $this->handle403();
                return;
            }
        }
        
        // Executar handler
        if (is_string($handler) && strpos($handler, '@') !== false) {
            // Controller@method
            list($controllerName, $method) = explode('@', $handler);
            
            if (class_exists($controllerName)) {
                $controller = new $controllerName();
                
                if (method_exists($controller, $method)) {
                    // Passar parâmetros para o método
                    $reflection = new ReflectionMethod($controller, $method);
                    $methodParams = [];
                    
                    foreach ($reflection->getParameters() as $param) {
                        $paramName = $param->getName();
                        $methodParams[] = $params[$paramName] ?? null;
                    }
                    
                    call_user_func_array([$controller, $method], $methodParams);
                } else {
                    throw new Exception("Método {$method} não encontrado no controller {$controllerName}");
                }
            } else {
                throw new Exception("Controller {$controllerName} não encontrado");
            }
        } elseif (is_callable($handler)) {
            // Função anônima
            call_user_func($handler, $params);
        } else {
            throw new Exception("Handler de rota inválido");
        }
    }
    
    /**
     * Redireciona para login
     */
    private function redirectToLogin()
    {
        header('Location: /login');
        exit;
    }
    
    /**
     * Trata erro 403 (Forbidden)
     */
    private function handle403()
    {
        http_response_code(403);
        echo "403 - Acesso Negado";
        exit;
    }
    
    /**
     * Trata erro 404 (Not Found)
     */
    private function handle404()
    {
        http_response_code(404);
        echo "404 - Página não encontrada";
        exit;
    }
    
    /**
     * Trata erros gerais
     */
    private function handleError($exception)
    {
        http_response_code(500);
        
        if ($this->config['app']['debug']) {
            echo "<h1>Erro:</h1>";
            echo "<p>" . $exception->getMessage() . "</p>";
            echo "<pre>" . $exception->getTraceAsString() . "</pre>";
        } else {
            echo "500 - Erro interno do servidor";
            
            // Log do erro
            $this->logError($exception);
        }
        
        exit;
    }
    
    /**
     * Registra erro no log
     */
    private function logError($exception)
    {
        $logFile = APP_ROOT . '/logs/error.log';
        $logDir = dirname($logFile);
        
        if (!is_dir($logDir)) {
            mkdir($logDir, 0755, true);
        }
        
        $message = sprintf(
            "[%s] %s in %s:%d\nStack trace:\n%s\n\n",
            date('Y-m-d H:i:s'),
            $exception->getMessage(),
            $exception->getFile(),
            $exception->getLine(),
            $exception->getTraceAsString()
        );
        
        file_put_contents($logFile, $message, FILE_APPEND | LOCK_EX);
    }
    
    /**
     * Verifica se padrão corresponde
     */
    private function matchPattern($pattern, $uri)
    {
        $regex = str_replace('*', '.*', preg_quote($pattern, '/'));
        return preg_match('/^' . $regex . '$/', $uri);
    }
    
    /**
     * Verifica se rota está no grupo
     */
    private function isRouteInGroup($uri, $groupName)
    {
        $group = $this->routes[$groupName] ?? [];
        
        foreach ($group as $pattern => $handler) {
            $routePattern = explode(' ', $pattern, 2)[1] ?? $pattern;
            if ($this->matchPattern($routePattern, $uri)) {
                return true;
            }
        }
        
        return false;
    }
}

// Executar aplicação
$app = new App($config, $routes);
$app->run();

