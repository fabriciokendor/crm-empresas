<?php
/**
 * Classe de Conexão com Banco de Dados
 * Sistema de Gerenciamento de Relacionamento com Empresas
 */

class Database
{
    private static $instance = null;
    private $connection = null;
    private $config = [];
    private $queryLog = [];
    
    private function __construct()
    {
        $this->config = require __DIR__ . '/../../config/database.php';
        $this->connect();
    }
    
    /**
     * Singleton - retorna a instância única da classe
     */
    public static function getInstance()
    {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    /**
     * Estabelece conexão com o banco de dados
     */
    private function connect()
    {
        try {
            $config = $this->config['connections'][$this->config['default']];
            
            $dsn = sprintf(
                "%s:host=%s;port=%s;dbname=%s;charset=%s",
                $config['driver'],
                $config['host'],
                $config['port'],
                $config['database'],
                $config['charset']
            );
            
            $this->connection = new PDO(
                $dsn,
                $config['username'],
                $config['password'],
                $config['options']
            );
            
            // Configurar timezone
            $this->connection->exec("SET time_zone = '+00:00'");
            
        } catch (PDOException $e) {
            $this->logError("Erro de conexão com banco de dados: " . $e->getMessage());
            throw new Exception("Erro ao conectar com o banco de dados");
        }
    }
    
    /**
     * Retorna a conexão PDO
     */
    public function getConnection()
    {
        // Verificar se a conexão ainda está ativa
        if ($this->connection === null) {
            $this->connect();
        }
        
        return $this->connection;
    }
    
    /**
     * Executa uma consulta preparada
     */
    public function query($sql, $params = [])
    {
        $startTime = microtime(true);
        
        try {
            $stmt = $this->connection->prepare($sql);
            $result = $stmt->execute($params);
            
            $executionTime = microtime(true) - $startTime;
            $this->logQuery($sql, $params, $executionTime);
            
            return $stmt;
            
        } catch (PDOException $e) {
            $this->logError("Erro na consulta SQL: " . $e->getMessage() . " | SQL: " . $sql);
            throw new Exception("Erro ao executar consulta no banco de dados");
        }
    }
    
    /**
     * Executa SELECT e retorna todos os resultados
     */
    public function select($sql, $params = [])
    {
        $stmt = $this->query($sql, $params);
        return $stmt->fetchAll();
    }
    
    /**
     * Executa SELECT e retorna apenas o primeiro resultado
     */
    public function selectOne($sql, $params = [])
    {
        $stmt = $this->query($sql, $params);
        return $stmt->fetch();
    }
    
    /**
     * Executa INSERT e retorna o ID inserido
     */
    public function insert($sql, $params = [])
    {
        $this->query($sql, $params);
        return $this->connection->lastInsertId();
    }
    
    /**
     * Executa UPDATE e retorna o número de linhas afetadas
     */
    public function update($sql, $params = [])
    {
        $stmt = $this->query($sql, $params);
        return $stmt->rowCount();
    }
    
    /**
     * Executa DELETE e retorna o número de linhas afetadas
     */
    public function delete($sql, $params = [])
    {
        $stmt = $this->query($sql, $params);
        return $stmt->rowCount();
    }
    
    /**
     * Inicia uma transação
     */
    public function beginTransaction()
    {
        return $this->connection->beginTransaction();
    }
    
    /**
     * Confirma uma transação
     */
    public function commit()
    {
        return $this->connection->commit();
    }
    
    /**
     * Desfaz uma transação
     */
    public function rollback()
    {
        return $this->connection->rollback();
    }
    
    /**
     * Verifica se está em uma transação
     */
    public function inTransaction()
    {
        return $this->connection->inTransaction();
    }
    
    /**
     * Executa uma função dentro de uma transação
     */
    public function transaction($callback)
    {
        $this->beginTransaction();
        
        try {
            $result = $callback($this);
            $this->commit();
            return $result;
        } catch (Exception $e) {
            $this->rollback();
            throw $e;
        }
    }
    
    /**
     * Escapa uma string para uso seguro em SQL
     */
    public function quote($value)
    {
        return $this->connection->quote($value);
    }
    
    /**
     * Retorna informações sobre a última consulta
     */
    public function getLastQuery()
    {
        return end($this->queryLog);
    }
    
    /**
     * Retorna todas as consultas executadas
     */
    public function getQueryLog()
    {
        return $this->queryLog;
    }
    
    /**
     * Limpa o log de consultas
     */
    public function clearQueryLog()
    {
        $this->queryLog = [];
    }
    
    /**
     * Registra uma consulta no log
     */
    private function logQuery($sql, $params, $executionTime)
    {
        if ($this->config['query_log']['enabled']) {
            $logEntry = [
                'sql' => $sql,
                'params' => $params,
                'execution_time' => $executionTime,
                'timestamp' => date('Y-m-d H:i:s')
            ];
            
            $this->queryLog[] = $logEntry;
            
            // Log de consultas lentas
            if ($executionTime > $this->config['query_log']['slow_query_time']) {
                $this->logSlowQuery($logEntry);
            }
        }
    }
    
    /**
     * Registra consultas lentas em arquivo
     */
    private function logSlowQuery($logEntry)
    {
        $logFile = $this->config['query_log']['log_file'];
        $logDir = dirname($logFile);
        
        if (!is_dir($logDir)) {
            mkdir($logDir, 0755, true);
        }
        
        $message = sprintf(
            "[%s] SLOW QUERY (%.4fs): %s | Params: %s\n",
            $logEntry['timestamp'],
            $logEntry['execution_time'],
            $logEntry['sql'],
            json_encode($logEntry['params'])
        );
        
        file_put_contents($logFile, $message, FILE_APPEND | LOCK_EX);
    }
    
    /**
     * Registra erros em arquivo de log
     */
    private function logError($message)
    {
        $logFile = __DIR__ . '/../../logs/error.log';
        $logDir = dirname($logFile);
        
        if (!is_dir($logDir)) {
            mkdir($logDir, 0755, true);
        }
        
        $timestamp = date('Y-m-d H:i:s');
        $logMessage = "[{$timestamp}] ERROR: {$message}\n";
        
        file_put_contents($logFile, $logMessage, FILE_APPEND | LOCK_EX);
    }
    
    /**
     * Testa a conexão com o banco
     */
    public function testConnection()
    {
        try {
            $this->selectOne("SELECT 1 as test");
            return true;
        } catch (Exception $e) {
            return false;
        }
    }
    
    /**
     * Retorna estatísticas da conexão
     */
    public function getConnectionStats()
    {
        return [
            'total_queries' => count($this->queryLog),
            'total_time' => array_sum(array_column($this->queryLog, 'execution_time')),
            'avg_time' => count($this->queryLog) > 0 ? 
                array_sum(array_column($this->queryLog, 'execution_time')) / count($this->queryLog) : 0,
            'slow_queries' => count(array_filter($this->queryLog, function($query) {
                return $query['execution_time'] > $this->config['query_log']['slow_query_time'];
            }))
        ];
    }
    
    /**
     * Impede clonagem da instância
     */
    private function __clone() {}
    
    /**
     * Impede deserialização da instância
     */
    public function __wakeup()
    {
        throw new Exception("Cannot unserialize singleton");
    }
}

