<?php
/**
 * Controller do Dashboard
 * Sistema de Gerenciamento de Relacionamento com Empresas
 */

class DashboardController
{
    private $db;
    
    public function __construct()
    {
        $this->db = Database::getInstance();
        
        // Verificar autenticação
        if (!Auth::check()) {
            header('Location: /login');
            exit;
        }
    }
    
    /**
     * Página principal do dashboard
     */
    public function index()
    {
        $stats = $this->getStats();
        $recentActivities = $this->getRecentActivities();
        $topEmpresas = $this->getTopEmpresas();
        $ocorrenciasPorMes = $this->getOcorrenciasPorMes();
        
        $data = [
            'title' => 'Dashboard - CRM Empresas',
            'user' => Auth::user(),
            'stats' => $stats,
            'recent_activities' => $recentActivities,
            'top_empresas' => $topEmpresas,
            'ocorrencias_por_mes' => $ocorrenciasPorMes,
            'success' => $_SESSION['success_message'] ?? null,
            'error' => $_SESSION['error_message'] ?? null
        ];
        
        // Limpar mensagens da sessão
        unset($_SESSION['success_message'], $_SESSION['error_message']);
        
        $this->view('dashboard/index', $data);
    }
    
    /**
     * Retorna estatísticas gerais (AJAX)
     */
    public function stats()
    {
        if (!$this->isAjaxRequest()) {
            http_response_code(400);
            return;
        }
        
        $stats = $this->getStats();
        
        header('Content-Type: application/json');
        echo json_encode($stats);
    }
    
    /**
     * Coleta estatísticas gerais do sistema
     */
    private function getStats()
    {
        // Usar view materializada se disponível, senão calcular
        $dashboardStats = $this->db->selectOne("SELECT * FROM dashboard_stats WHERE id = 1");
        
        if ($dashboardStats) {
            $stats = [
                'total_usuarios' => $dashboardStats['total_usuarios'],
                'total_empresas' => $dashboardStats['total_empresas'],
                'total_ocorrencias' => $dashboardStats['total_ocorrencias'],
                'ocorrencias_abertas' => $dashboardStats['ocorrencias_abertas'],
                'ocorrencias_mes_atual' => $dashboardStats['ocorrencias_mes_atual']
            ];
        } else {
            // Calcular manualmente se a view não existir
            $stats = [
                'total_usuarios' => $this->getTotalUsuarios(),
                'total_empresas' => $this->getTotalEmpresas(),
                'total_ocorrencias' => $this->getTotalOcorrencias(),
                'ocorrencias_abertas' => $this->getOcorrenciasAbertas(),
                'ocorrencias_mes_atual' => $this->getOcorrenciasMesAtual()
            ];
        }
        
        // Estatísticas adicionais
        $stats['ocorrencias_fechadas'] = $stats['total_ocorrencias'] - $stats['ocorrencias_abertas'];
        $stats['taxa_resolucao'] = $stats['total_ocorrencias'] > 0 ? 
            round(($stats['ocorrencias_fechadas'] / $stats['total_ocorrencias']) * 100, 1) : 0;
        
        // Comparação com mês anterior
        $stats['crescimento_mes'] = $this->getCrescimentoMes();
        
        return $stats;
    }
    
    /**
     * Retorna atividades recentes
     */
    private function getRecentActivities($limit = 10)
    {
        $sql = "
            SELECT 
                l.acao,
                l.created_at,
                u.nome as usuario_nome,
                l.tabela_afetada,
                l.registro_id
            FROM logs_sistema l
            LEFT JOIN usuarios u ON l.usuario_id = u.id
            ORDER BY l.created_at DESC
            LIMIT ?
        ";
        
        $activities = $this->db->select($sql, [$limit]);
        
        // Formatar atividades
        foreach ($activities as &$activity) {
            $activity['descricao'] = $this->formatActivity($activity);
            $activity['tempo_relativo'] = $this->timeAgo($activity['created_at']);
        }
        
        return $activities;
    }
    
    /**
     * Retorna top empresas por número de ocorrências
     */
    private function getTopEmpresas($limit = 5)
    {
        $sql = "
            SELECT 
                e.id,
                e.razao_social,
                e.nome_fantasia,
                COUNT(o.id) as total_ocorrencias,
                COUNT(CASE WHEN o.status IN ('aberta', 'em_andamento') THEN 1 END) as ocorrencias_abertas
            FROM empresas e
            LEFT JOIN ocorrencias o ON e.id = o.empresa_id
            WHERE e.ativo = 1
            GROUP BY e.id, e.razao_social, e.nome_fantasia
            HAVING total_ocorrencias > 0
            ORDER BY total_ocorrencias DESC
            LIMIT ?
        ";
        
        return $this->db->select($sql, [$limit]);
    }
    
    /**
     * Retorna dados de ocorrências por mês (últimos 12 meses)
     */
    private function getOcorrenciasPorMes()
    {
        $sql = "
            SELECT 
                DATE_FORMAT(data_ocorrencia, '%Y-%m') as mes,
                COUNT(*) as total
            FROM ocorrencias
            WHERE data_ocorrencia >= DATE_SUB(NOW(), INTERVAL 12 MONTH)
            GROUP BY DATE_FORMAT(data_ocorrencia, '%Y-%m')
            ORDER BY mes
        ";
        
        $dados = $this->db->select($sql);
        
        // Preencher meses sem dados
        $resultado = [];
        $dataInicio = new DateTime('-11 months');
        
        for ($i = 0; $i < 12; $i++) {
            $mes = $dataInicio->format('Y-m');
            $total = 0;
            
            foreach ($dados as $dado) {
                if ($dado['mes'] === $mes) {
                    $total = $dado['total'];
                    break;
                }
            }
            
            $resultado[] = [
                'mes' => $mes,
                'mes_nome' => $this->formatMes($mes),
                'total' => $total
            ];
            
            $dataInicio->modify('+1 month');
        }
        
        return $resultado;
    }
    
    /**
     * Métodos auxiliares para estatísticas
     */
    private function getTotalUsuarios()
    {
        $result = $this->db->selectOne("SELECT COUNT(*) as total FROM usuarios WHERE ativo = 1");
        return $result['total'];
    }
    
    private function getTotalEmpresas()
    {
        $result = $this->db->selectOne("SELECT COUNT(*) as total FROM empresas WHERE ativo = 1");
        return $result['total'];
    }
    
    private function getTotalOcorrencias()
    {
        $result = $this->db->selectOne("SELECT COUNT(*) as total FROM ocorrencias");
        return $result['total'];
    }
    
    private function getOcorrenciasAbertas()
    {
        $result = $this->db->selectOne(
            "SELECT COUNT(*) as total FROM ocorrencias WHERE status IN ('aberta', 'em_andamento')"
        );
        return $result['total'];
    }
    
    private function getOcorrenciasMesAtual()
    {
        $result = $this->db->selectOne(
            "SELECT COUNT(*) as total FROM ocorrencias 
             WHERE MONTH(data_ocorrencia) = MONTH(NOW()) 
             AND YEAR(data_ocorrencia) = YEAR(NOW())"
        );
        return $result['total'];
    }
    
    private function getCrescimentoMes()
    {
        $mesAtual = $this->getOcorrenciasMesAtual();
        
        $mesAnterior = $this->db->selectOne(
            "SELECT COUNT(*) as total FROM ocorrencias 
             WHERE MONTH(data_ocorrencia) = MONTH(DATE_SUB(NOW(), INTERVAL 1 MONTH))
             AND YEAR(data_ocorrencia) = YEAR(DATE_SUB(NOW(), INTERVAL 1 MONTH))"
        );
        
        $totalMesAnterior = $mesAnterior['total'];
        
        if ($totalMesAnterior == 0) {
            return $mesAtual > 0 ? 100 : 0;
        }
        
        return round((($mesAtual - $totalMesAnterior) / $totalMesAnterior) * 100, 1);
    }
    
    /**
     * Formata descrição da atividade
     */
    private function formatActivity($activity)
    {
        $usuario = $activity['usuario_nome'] ?? 'Sistema';
        $acao = $activity['acao'];
        $tabela = $activity['tabela_afetada'];
        
        $acoes = [
            'login' => 'fez login no sistema',
            'logout' => 'fez logout do sistema',
            'INSERT' => 'criou um registro',
            'UPDATE' => 'atualizou um registro',
            'DELETE' => 'excluiu um registro'
        ];
        
        $tabelas = [
            'usuarios' => 'usuário',
            'empresas' => 'empresa',
            'ocorrencias' => 'ocorrência',
            'tipos_ocorrencia' => 'tipo de ocorrência'
        ];
        
        $acaoTexto = $acoes[$acao] ?? $acao;
        $tabelaTexto = $tabelas[$tabela] ?? $tabela;
        
        if (in_array($acao, ['INSERT', 'UPDATE', 'DELETE'])) {
            return "{$usuario} {$acaoTexto} em {$tabelaTexto}";
        }
        
        return "{$usuario} {$acaoTexto}";
    }
    
    /**
     * Calcula tempo relativo
     */
    private function timeAgo($datetime)
    {
        $time = time() - strtotime($datetime);
        
        if ($time < 60) return 'agora mesmo';
        if ($time < 3600) return floor($time/60) . ' min atrás';
        if ($time < 86400) return floor($time/3600) . ' h atrás';
        if ($time < 2592000) return floor($time/86400) . ' dias atrás';
        if ($time < 31536000) return floor($time/2592000) . ' meses atrás';
        
        return floor($time/31536000) . ' anos atrás';
    }
    
    /**
     * Formata nome do mês
     */
    private function formatMes($mes)
    {
        $meses = [
            '01' => 'Jan', '02' => 'Fev', '03' => 'Mar', '04' => 'Abr',
            '05' => 'Mai', '06' => 'Jun', '07' => 'Jul', '08' => 'Ago',
            '09' => 'Set', '10' => 'Out', '11' => 'Nov', '12' => 'Dez'
        ];
        
        $parts = explode('-', $mes);
        return $meses[$parts[1]] . '/' . substr($parts[0], 2);
    }
    
    /**
     * Verifica se é requisição AJAX
     */
    private function isAjaxRequest()
    {
        return isset($_SERVER['HTTP_X_REQUESTED_WITH']) && 
               strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) === 'xmlhttprequest';
    }
    
    /**
     * Renderiza uma view
     */
    private function view($view, $data = [])
    {
        // Extrair variáveis para o escopo da view
        extract($data);
        
        // Incluir header
        include APP_ROOT . '/app/views/layouts/header.php';
        
        // Incluir view específica
        $viewFile = APP_ROOT . '/app/views/' . $view . '.php';
        if (file_exists($viewFile)) {
            include $viewFile;
        } else {
            throw new Exception("View não encontrada: {$view}");
        }
        
        // Incluir footer
        include APP_ROOT . '/app/views/layouts/footer.php';
    }
}

