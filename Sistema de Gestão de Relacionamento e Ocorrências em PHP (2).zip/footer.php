            </div> <!-- End main-content-area -->
        </div> <!-- End content-wrapper -->
    </div> <!-- End main-content -->

    <!-- jQuery -->
    <script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
    
    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
    
    <!-- DataTables -->
    <script src="https://cdn.datatables.net/1.13.7/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.13.7/js/dataTables.bootstrap5.min.js"></script>
    
    <!-- Select2 -->
    <script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>
    
    <!-- Moment.js for date formatting -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.29.4/moment.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.29.4/locale/pt-br.min.js"></script>
    
    <!-- InputMask -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.inputmask/5.0.8/jquery.inputmask.min.js"></script>
    
    <!-- SweetAlert2 -->
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

    <script>
        // Global variables
        window.APP_URL = '<?= $_SERVER['REQUEST_SCHEME'] ?>://<?= $_SERVER['HTTP_HOST'] ?>';
        window.CSRF_TOKEN = '<?= $_SESSION['csrf_token'] ?? '' ?>';
        
        // Configure moment.js locale
        moment.locale('pt-br');
        
        $(document).ready(function() {
            // Sidebar toggle
            $('#sidebarToggle').on('click', function() {
                $('#sidebar').toggleClass('show');
                $('#sidebarOverlay').toggleClass('show');
            });
            
            // Close sidebar when clicking overlay
            $('#sidebarOverlay').on('click', function() {
                $('#sidebar').removeClass('show');
                $('#sidebarOverlay').removeClass('show');
            });
            
            // Close sidebar on window resize if large screen
            $(window).on('resize', function() {
                if ($(window).width() >= 992) {
                    $('#sidebar').removeClass('show');
                    $('#sidebarOverlay').removeClass('show');
                }
            });
            
            // Initialize DataTables with Portuguese
            $.extend(true, $.fn.dataTable.defaults, {
                language: {
                    url: 'https://cdn.datatables.net/plug-ins/1.13.7/i18n/pt-BR.json'
                },
                responsive: true,
                pageLength: 25,
                lengthMenu: [[10, 25, 50, 100, -1], [10, 25, 50, 100, "Todos"]],
                dom: '<"row"<"col-sm-12 col-md-6"l><"col-sm-12 col-md-6"f>>' +
                     '<"row"<"col-sm-12"tr>>' +
                     '<"row"<"col-sm-12 col-md-5"i><"col-sm-12 col-md-7"p>>',
                order: [[0, 'desc']]
            });
            
            // Initialize Select2 with Portuguese
            $.fn.select2.defaults.set('language', 'pt');
            $('.select2').select2({
                theme: 'bootstrap-5',
                width: '100%'
            });
            
            // Initialize input masks
            $('[data-mask="cnpj"]').inputmask('99.999.999/9999-99');
            $('[data-mask="cpf"]').inputmask('999.999.999-99');
            $('[data-mask="phone"]').inputmask(['(99) 9999-9999', '(99) 99999-9999']);
            $('[data-mask="cep"]').inputmask('99999-999');
            $('[data-mask="date"]').inputmask('99/99/9999');
            $('[data-mask="datetime"]').inputmask('99/99/9999 99:99');
            $('[data-mask="time"]').inputmask('99:99');
            
            // Auto-dismiss alerts after 5 seconds
            $('.alert').each(function() {
                const alert = $(this);
                if (!alert.hasClass('alert-permanent')) {
                    setTimeout(function() {
                        alert.fadeOut();
                    }, 5000);
                }
            });
            
            // AJAX setup with CSRF token
            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': window.CSRF_TOKEN,
                    'X-Requested-With': 'XMLHttpRequest'
                },
                beforeSend: function() {
                    showLoading();
                },
                complete: function() {
                    hideLoading();
                },
                error: function(xhr, status, error) {
                    hideLoading();
                    
                    let message = 'Erro na requisição';
                    if (xhr.responseJSON && xhr.responseJSON.message) {
                        message = xhr.responseJSON.message;
                    } else if (xhr.responseText) {
                        try {
                            const response = JSON.parse(xhr.responseText);
                            message = response.message || message;
                        } catch (e) {
                            // Keep default message
                        }
                    }
                    
                    Swal.fire({
                        icon: 'error',
                        title: 'Erro',
                        text: message,
                        confirmButtonText: 'OK'
                    });
                }
            });
            
            // Form validation
            $('form[data-validate="true"]').on('submit', function(e) {
                const form = $(this);
                let isValid = true;
                
                // Clear previous errors
                form.find('.is-invalid').removeClass('is-invalid');
                form.find('.invalid-feedback').remove();
                
                // Validate required fields
                form.find('[required]').each(function() {
                    const field = $(this);
                    if (!field.val().trim()) {
                        field.addClass('is-invalid');
                        field.after('<div class="invalid-feedback">Este campo é obrigatório.</div>');
                        isValid = false;
                    }
                });
                
                // Validate email fields
                form.find('input[type="email"]').each(function() {
                    const field = $(this);
                    const email = field.val().trim();
                    if (email && !isValidEmail(email)) {
                        field.addClass('is-invalid');
                        field.after('<div class="invalid-feedback">Email inválido.</div>');
                        isValid = false;
                    }
                });
                
                // Validate CNPJ fields
                form.find('[data-mask="cnpj"]').each(function() {
                    const field = $(this);
                    const cnpj = field.val().replace(/\D/g, '');
                    if (cnpj && !isValidCNPJ(cnpj)) {
                        field.addClass('is-invalid');
                        field.after('<div class="invalid-feedback">CNPJ inválido.</div>');
                        isValid = false;
                    }
                });
                
                if (!isValid) {
                    e.preventDefault();
                    // Focus on first invalid field
                    form.find('.is-invalid').first().focus();
                }
            });
            
            // Confirm delete actions
            $('[data-confirm-delete]').on('click', function(e) {
                e.preventDefault();
                const link = $(this);
                const message = link.data('confirm-delete') || 'Tem certeza que deseja excluir este item?';
                
                Swal.fire({
                    title: 'Confirmar exclusão',
                    text: message,
                    icon: 'warning',
                    showCancelButton: true,
                    confirmButtonColor: '#dc3545',
                    cancelButtonColor: '#6c757d',
                    confirmButtonText: 'Sim, excluir',
                    cancelButtonText: 'Cancelar'
                }).then((result) => {
                    if (result.isConfirmed) {
                        if (link.is('form')) {
                            link.submit();
                        } else {
                            window.location.href = link.attr('href');
                        }
                    }
                });
            });
            
            // Auto-refresh notifications
            loadNotifications();
            setInterval(loadNotifications, 60000); // Every minute
            
            // Initialize tooltips
            const tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
            tooltipTriggerList.map(function (tooltipTriggerEl) {
                return new bootstrap.Tooltip(tooltipTriggerEl);
            });
            
            // Initialize popovers
            const popoverTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="popover"]'));
            popoverTriggerList.map(function (popoverTriggerEl) {
                return new bootstrap.Popover(popoverTriggerEl);
            });
        });
        
        // Utility functions
        function showLoading() {
            $('#loadingSpinner').show();
        }
        
        function hideLoading() {
            $('#loadingSpinner').hide();
        }
        
        function isValidEmail(email) {
            const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
            return re.test(email);
        }
        
        function isValidCNPJ(cnpj) {
            cnpj = cnpj.replace(/\D/g, '');
            
            if (cnpj.length !== 14) return false;
            
            // Check for known invalid patterns
            if (/^(\d)\1+$/.test(cnpj)) return false;
            
            // Validate check digits
            let sum = 0;
            let weight = 2;
            
            for (let i = 11; i >= 0; i--) {
                sum += parseInt(cnpj.charAt(i)) * weight;
                weight = weight === 9 ? 2 : weight + 1;
            }
            
            let digit1 = sum % 11 < 2 ? 0 : 11 - (sum % 11);
            if (parseInt(cnpj.charAt(12)) !== digit1) return false;
            
            sum = 0;
            weight = 2;
            
            for (let i = 12; i >= 0; i--) {
                sum += parseInt(cnpj.charAt(i)) * weight;
                weight = weight === 9 ? 2 : weight + 1;
            }
            
            let digit2 = sum % 11 < 2 ? 0 : 11 - (sum % 11);
            return parseInt(cnpj.charAt(13)) === digit2;
        }
        
        function formatCurrency(value) {
            return new Intl.NumberFormat('pt-BR', {
                style: 'currency',
                currency: 'BRL'
            }).format(value);
        }
        
        function formatDate(date, format = 'DD/MM/YYYY') {
            return moment(date).format(format);
        }
        
        function formatDateTime(date, format = 'DD/MM/YYYY HH:mm') {
            return moment(date).format(format);
        }
        
        function timeAgo(date) {
            return moment(date).fromNow();
        }
        
        function loadNotifications() {
            $.get('/api/notifications')
                .done(function(data) {
                    const count = data.count || 0;
                    const notifications = data.notifications || [];
                    
                    $('#notificationCount').text(count).toggle(count > 0);
                    
                    const dropdown = $('#notificationCount').closest('.dropdown').find('.dropdown-menu');
                    const noNotifications = $('#noNotifications');
                    
                    if (count === 0) {
                        noNotifications.show();
                    } else {
                        noNotifications.hide();
                        // Add notifications to dropdown
                        // Implementation depends on notification structure
                    }
                })
                .fail(function() {
                    // Silently fail - notifications are not critical
                });
        }
        
        // Export functions to global scope
        window.showLoading = showLoading;
        window.hideLoading = hideLoading;
        window.formatCurrency = formatCurrency;
        window.formatDate = formatDate;
        window.formatDateTime = formatDateTime;
        window.timeAgo = timeAgo;
    </script>
    
    <!-- Page-specific scripts -->
    <?php if (isset($scripts)): ?>
        <?= $scripts ?>
    <?php endif; ?>
</body>
</html>

