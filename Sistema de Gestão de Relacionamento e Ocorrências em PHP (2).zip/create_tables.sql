-- ============================================================================
-- Sistema de Gerenciamento de Relacionamento com Empresas
-- Script de Criação das Tabelas - MySQL 5.7+
-- ============================================================================

-- Criação do banco de dados
CREATE DATABASE IF NOT EXISTS crm_empresas 
CHARACTER SET utf8mb4 
COLLATE utf8mb4_unicode_ci;

USE crm_empresas;

-- ============================================================================
-- TABELA: usuarios
-- Descrição: Armazena informações dos usuários do sistema
-- ============================================================================
CREATE TABLE usuarios (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(100) NOT NULL,
    email VARCHAR(100) NOT NULL UNIQUE,
    senha VARCHAR(255) NOT NULL,
    nivel_acesso ENUM('admin', 'operador', 'visualizador') NOT NULL DEFAULT 'operador',
    ativo BOOLEAN NOT NULL DEFAULT TRUE,
    ultimo_login DATETIME NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    
    INDEX idx_email (email),
    INDEX idx_nivel_acesso (nivel_acesso),
    INDEX idx_ativo (ativo)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================================
-- TABELA: tipos_ocorrencia
-- Descrição: Categorias de ocorrências (criada antes de empresas para FK)
-- ============================================================================
CREATE TABLE tipos_ocorrencia (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(50) NOT NULL UNIQUE,
    descricao TEXT,
    cor VARCHAR(7) NOT NULL DEFAULT '#007bff',
    icone VARCHAR(50) DEFAULT 'fas fa-info-circle',
    ativo BOOLEAN NOT NULL DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    
    INDEX idx_ativo (ativo)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================================
-- TABELA: empresas
-- Descrição: Informações das empresas clientes
-- ============================================================================
CREATE TABLE empresas (
    id INT AUTO_INCREMENT PRIMARY KEY,
    razao_social VARCHAR(200) NOT NULL,
    nome_fantasia VARCHAR(200),
    cnpj VARCHAR(18) UNIQUE,
    inscricao_estadual VARCHAR(20),
    endereco TEXT,
    cidade VARCHAR(100),
    estado VARCHAR(2),
    cep VARCHAR(10),
    telefone VARCHAR(20),
    email VARCHAR(100),
    site VARCHAR(200),
    contato_principal VARCHAR(100),
    cargo_contato VARCHAR(100),
    observacoes TEXT,
    ativo BOOLEAN NOT NULL DEFAULT TRUE,
    usuario_cadastro INT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    
    FOREIGN KEY (usuario_cadastro) REFERENCES usuarios(id) ON DELETE RESTRICT,
    INDEX idx_cnpj (cnpj),
    INDEX idx_razao_social (razao_social),
    INDEX idx_ativo (ativo),
    INDEX idx_usuario_cadastro (usuario_cadastro),
    FULLTEXT idx_busca_empresa (razao_social, nome_fantasia, contato_principal)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================================
-- TABELA: ocorrencias
-- Descrição: Registro de ocorrências/interações com empresas
-- ============================================================================
CREATE TABLE ocorrencias (
    id INT AUTO_INCREMENT PRIMARY KEY,
    empresa_id INT NOT NULL,
    usuario_id INT NOT NULL,
    tipo_ocorrencia_id INT NOT NULL,
    titulo VARCHAR(200) NOT NULL,
    descricao TEXT NOT NULL,
    data_ocorrencia DATETIME NOT NULL,
    prioridade ENUM('baixa', 'media', 'alta', 'critica') NOT NULL DEFAULT 'media',
    status ENUM('aberta', 'em_andamento', 'resolvida', 'fechada') NOT NULL DEFAULT 'aberta',
    resolucao TEXT,
    data_resolucao DATETIME NULL,
    anexos JSON,
    tags VARCHAR(500),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    
    FOREIGN KEY (empresa_id) REFERENCES empresas(id) ON DELETE CASCADE,
    FOREIGN KEY (usuario_id) REFERENCES usuarios(id) ON DELETE RESTRICT,
    FOREIGN KEY (tipo_ocorrencia_id) REFERENCES tipos_ocorrencia(id) ON DELETE RESTRICT,
    INDEX idx_empresa_id (empresa_id),
    INDEX idx_usuario_id (usuario_id),
    INDEX idx_tipo_ocorrencia_id (tipo_ocorrencia_id),
    INDEX idx_data_ocorrencia (data_ocorrencia),
    INDEX idx_status (status),
    INDEX idx_prioridade (prioridade),
    FULLTEXT idx_busca_ocorrencia (titulo, descricao, tags)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================================
-- TABELA: historico_ocorrencias
-- Descrição: Log de alterações nas ocorrências
-- ============================================================================
CREATE TABLE historico_ocorrencias (
    id INT AUTO_INCREMENT PRIMARY KEY,
    ocorrencia_id INT NOT NULL,
    usuario_id INT NOT NULL,
    acao VARCHAR(50) NOT NULL,
    dados_anteriores JSON,
    dados_novos JSON,
    observacoes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    
    FOREIGN KEY (ocorrencia_id) REFERENCES ocorrencias(id) ON DELETE CASCADE,
    FOREIGN KEY (usuario_id) REFERENCES usuarios(id) ON DELETE RESTRICT,
    INDEX idx_ocorrencia_id (ocorrencia_id),
    INDEX idx_usuario_id (usuario_id),
    INDEX idx_acao (acao),
    INDEX idx_created_at (created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================================
-- TABELA: backups
-- Descrição: Controle de backups do sistema
-- ============================================================================
CREATE TABLE backups (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nome_arquivo VARCHAR(255) NOT NULL,
    caminho_arquivo VARCHAR(500) NOT NULL,
    tamanho_bytes BIGINT,
    tipo_backup ENUM('manual', 'automatico') NOT NULL DEFAULT 'automatico',
    status ENUM('em_progresso', 'concluido', 'erro') NOT NULL DEFAULT 'em_progresso',
    usuario_id INT NULL,
    data_inicio DATETIME NOT NULL,
    data_fim DATETIME NULL,
    observacoes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    
    FOREIGN KEY (usuario_id) REFERENCES usuarios(id) ON DELETE SET NULL,
    INDEX idx_tipo_backup (tipo_backup),
    INDEX idx_status (status),
    INDEX idx_data_inicio (data_inicio),
    INDEX idx_usuario_id (usuario_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================================
-- TABELA: sessoes
-- Descrição: Controle de sessões de usuários
-- ============================================================================
CREATE TABLE sessoes (
    id VARCHAR(128) PRIMARY KEY,
    usuario_id INT NOT NULL,
    ip_address VARCHAR(45),
    user_agent TEXT,
    dados_sessao TEXT,
    ultima_atividade TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    
    FOREIGN KEY (usuario_id) REFERENCES usuarios(id) ON DELETE CASCADE,
    INDEX idx_usuario_id (usuario_id),
    INDEX idx_ultima_atividade (ultima_atividade)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================================
-- TABELA: logs_sistema
-- Descrição: Log de auditoria do sistema
-- ============================================================================
CREATE TABLE logs_sistema (
    id INT AUTO_INCREMENT PRIMARY KEY,
    usuario_id INT NULL,
    acao VARCHAR(100) NOT NULL,
    tabela_afetada VARCHAR(50),
    registro_id INT,
    dados_anteriores JSON,
    dados_novos JSON,
    ip_address VARCHAR(45),
    user_agent TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    
    FOREIGN KEY (usuario_id) REFERENCES usuarios(id) ON DELETE SET NULL,
    INDEX idx_usuario_id (usuario_id),
    INDEX idx_acao (acao),
    INDEX idx_tabela_afetada (tabela_afetada),
    INDEX idx_created_at (created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================================
-- TRIGGERS PARA AUDITORIA
-- ============================================================================

-- Trigger para log de inserção em empresas
DELIMITER $$
CREATE TRIGGER tr_empresas_insert 
AFTER INSERT ON empresas
FOR EACH ROW
BEGIN
    INSERT INTO logs_sistema (usuario_id, acao, tabela_afetada, registro_id, dados_novos)
    VALUES (NEW.usuario_cadastro, 'INSERT', 'empresas', NEW.id, JSON_OBJECT(
        'razao_social', NEW.razao_social,
        'cnpj', NEW.cnpj,
        'ativo', NEW.ativo
    ));
END$$

-- Trigger para log de atualização em empresas
CREATE TRIGGER tr_empresas_update 
AFTER UPDATE ON empresas
FOR EACH ROW
BEGIN
    INSERT INTO logs_sistema (acao, tabela_afetada, registro_id, dados_anteriores, dados_novos)
    VALUES ('UPDATE', 'empresas', NEW.id, 
        JSON_OBJECT('razao_social', OLD.razao_social, 'cnpj', OLD.cnpj, 'ativo', OLD.ativo),
        JSON_OBJECT('razao_social', NEW.razao_social, 'cnpj', NEW.cnpj, 'ativo', NEW.ativo)
    );
END$$

-- Trigger para log de inserção em ocorrências
CREATE TRIGGER tr_ocorrencias_insert 
AFTER INSERT ON ocorrencias
FOR EACH ROW
BEGIN
    INSERT INTO logs_sistema (usuario_id, acao, tabela_afetada, registro_id, dados_novos)
    VALUES (NEW.usuario_id, 'INSERT', 'ocorrencias', NEW.id, JSON_OBJECT(
        'empresa_id', NEW.empresa_id,
        'titulo', NEW.titulo,
        'status', NEW.status
    ));
END$$

DELIMITER ;

-- ============================================================================
-- VIEWS PARA RELATÓRIOS
-- ============================================================================

-- View para ranking de empresas por ocorrências
CREATE VIEW vw_ranking_empresas AS
SELECT 
    e.id,
    e.razao_social,
    e.nome_fantasia,
    e.contato_principal,
    COUNT(o.id) as total_ocorrencias,
    COUNT(CASE WHEN o.status = 'aberta' THEN 1 END) as ocorrencias_abertas,
    COUNT(CASE WHEN o.status = 'fechada' THEN 1 END) as ocorrencias_fechadas,
    MAX(o.data_ocorrencia) as ultima_ocorrencia
FROM empresas e
LEFT JOIN ocorrencias o ON e.id = o.empresa_id
WHERE e.ativo = TRUE
GROUP BY e.id, e.razao_social, e.nome_fantasia, e.contato_principal
ORDER BY total_ocorrencias DESC;

-- View para relatório de ocorrências detalhado
CREATE VIEW vw_relatorio_ocorrencias AS
SELECT 
    o.id,
    o.titulo,
    o.descricao,
    o.data_ocorrencia,
    o.prioridade,
    o.status,
    e.razao_social as empresa,
    e.contato_principal,
    u.nome as usuario_responsavel,
    t.nome as tipo_ocorrencia,
    t.cor as cor_tipo
FROM ocorrencias o
INNER JOIN empresas e ON o.empresa_id = e.id
INNER JOIN usuarios u ON o.usuario_id = u.id
INNER JOIN tipos_ocorrencia t ON o.tipo_ocorrencia_id = t.id
ORDER BY o.data_ocorrencia DESC;

-- ============================================================================
-- COMENTÁRIOS FINAIS
-- ============================================================================
-- Este script cria toda a estrutura necessária para o sistema CRM
-- Inclui tabelas, índices, triggers de auditoria e views para relatórios
-- Otimizado para MySQL 5.7+ com suporte a JSON e FULLTEXT
-- ============================================================================

