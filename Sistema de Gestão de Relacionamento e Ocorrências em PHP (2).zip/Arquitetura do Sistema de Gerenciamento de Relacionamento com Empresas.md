# Arquitetura do Sistema de Gerenciamento de Relacionamento com Empresas

## 1. ARQUITETURA GERAL

### 1.1 Padrão Arquitetural
- **Padrão MVC (Model-View-Controller)**
- **Arquitetura em 3 camadas**: Apresentação, Lógica de Negócio, Dados

### 1.2 Stack Tecnológica
- **Backend**: PHP 7.4+ com PDO
- **Frontend**: HTML5, CSS3, JavaScript, Bootstrap 5
- **Banco de Dados**: MySQL 5.7+
- **Servidor Web**: Apache 2.4+
- **Sistema Operacional**: Linux (Ubuntu/CentOS)

## 2. ESTRUTURA DE DIRETÓRIOS

```
crm-empresas/
├── config/
│   ├── database.php          # Configurações do banco
│   ├── config.php           # Configurações gerais
│   └── routes.php           # Definição de rotas
├── app/
│   ├── controllers/         # Controladores MVC
│   │   ├── AuthController.php
│   │   ├── EmpresaController.php
│   │   ├── OcorrenciaController.php
│   │   ├── RelatorioController.php
│   │   ├── UsuarioController.php
│   │   └── BackupController.php
│   ├── models/             # Modelos de dados
│   │   ├── Usuario.php
│   │   ├── Empresa.php
│   │   ├── Ocorrencia.php
│   │   ├── TipoOcorrencia.php
│   │   └── Backup.php
│   ├── views/              # Templates de visualização
│   │   ├── layouts/
│   │   │   ├── header.php
│   │   │   ├── footer.php
│   │   │   └── sidebar.php
│   │   ├── auth/
│   │   │   ├── login.php
│   │   │   └── logout.php
│   │   ├── dashboard/
│   │   │   └── index.php
│   │   ├── empresas/
│   │   │   ├── index.php
│   │   │   ├── create.php
│   │   │   ├── edit.php
│   │   │   └── show.php
│   │   ├── ocorrencias/
│   │   │   ├── index.php
│   │   │   ├── create.php
│   │   │   └── edit.php
│   │   ├── relatorios/
│   │   │   ├── index.php
│   │   │   ├── ranking.php
│   │   │   └── ocorrencias.php
│   │   ├── usuarios/
│   │   │   ├── index.php
│   │   │   ├── create.php
│   │   │   └── edit.php
│   │   └── backup/
│   │       ├── index.php
│   │       └── restore.php
│   └── helpers/            # Classes auxiliares
│       ├── Database.php    # Conexão com banco
│       ├── Auth.php        # Autenticação
│       ├── Validator.php   # Validações
│       ├── FileUpload.php  # Upload de arquivos
│       └── Backup.php      # Sistema de backup
├── public/                 # Pasta pública (DocumentRoot)
│   ├── index.php          # Ponto de entrada
│   ├── assets/
│   │   ├── css/
│   │   │   ├── bootstrap.min.css
│   │   │   ├── style.css
│   │   │   └── dashboard.css
│   │   ├── js/
│   │   │   ├── bootstrap.min.js
│   │   │   ├── jquery.min.js
│   │   │   ├── chart.js
│   │   │   └── app.js
│   │   └── images/
│   │       └── logo.png
│   └── uploads/           # Arquivos enviados
├── database/
│   ├── migrations/        # Scripts de criação
│   │   └── create_tables.sql
│   ├── seeds/            # Dados iniciais
│   │   └── initial_data.sql
│   └── backups/          # Backups do sistema
├── logs/                 # Logs do sistema
│   ├── error.log
│   ├── access.log
│   └── backup.log
├── vendor/               # Dependências (se usar Composer)
├── .htaccess            # Configurações Apache
├── composer.json        # Dependências PHP
└── README.md           # Documentação
```

## 3. COMPONENTES PRINCIPAIS

### 3.1 Camada de Apresentação (Views)
- **Templates PHP** com separação de layout
- **Bootstrap 5** para responsividade
- **JavaScript/jQuery** para interatividade
- **Chart.js** para gráficos nos relatórios

### 3.2 Camada de Controle (Controllers)
- **AuthController**: Autenticação e autorização
- **EmpresaController**: CRUD de empresas
- **OcorrenciaController**: Gestão de ocorrências
- **RelatorioController**: Geração de relatórios
- **UsuarioController**: Gestão de usuários
- **BackupController**: Sistema de backup/restore

### 3.3 Camada de Modelo (Models)
- **Classes PHP** representando entidades
- **PDO** para acesso ao banco de dados
- **Validações** de dados integradas
- **Relacionamentos** entre entidades

### 3.4 Camada de Dados
- **MySQL** como SGBD principal
- **Estrutura normalizada** (3FN)
- **Índices** para otimização
- **Triggers** para auditoria

## 4. FLUXO DE DADOS

```
Usuário → Apache → index.php → Router → Controller → Model → Database
                                    ↓
                              View ← Controller ← Model ← Database
```

## 5. SEGURANÇA

### 5.1 Autenticação
- **Sessões PHP** seguras
- **Hash de senhas** com password_hash()
- **Timeout** de sessão
- **Proteção CSRF**

### 5.2 Autorização
- **Níveis de acesso**: Admin, Operador, Visualizador
- **Controle por funcionalidade**
- **Middleware** de autorização

### 5.3 Validação
- **Sanitização** de entrada
- **Validação** server-side
- **Prepared statements** (PDO)
- **Escape** de saída

## 6. PERFORMANCE

### 6.1 Otimizações
- **Cache** de consultas frequentes
- **Índices** no banco de dados
- **Compressão** de assets
- **Lazy loading** de dados

### 6.2 Monitoramento
- **Logs** de erro e acesso
- **Métricas** de performance
- **Alertas** de sistema

## 7. BACKUP E RECUPERAÇÃO

### 7.1 Estratégia de Backup
- **Backup automático** diário
- **Backup incremental** semanal
- **Backup completo** mensal
- **Retenção** de 30 dias

### 7.2 Recuperação
- **Restore** via interface web
- **Validação** de integridade
- **Rollback** de transações
- **Teste** de recuperação

Esta arquitetura garante escalabilidade, manutenibilidade e segurança para o sistema de gerenciamento de relacionamento com empresas.

