<?php
/**
 * Configurações Gerais da Aplicação
 * Sistema de Gerenciamento de Relacionamento com Empresas
 */

return [
    // Configurações da aplicação
    'app' => [
        'name' => 'CRM Empresas',
        'version' => '1.0.0',
        'debug' => $_ENV['APP_DEBUG'] ?? false,
        'timezone' => 'America/Sao_Paulo',
        'locale' => 'pt_BR',
        'url' => $_ENV['APP_URL'] ?? 'http://localhost',
        'key' => $_ENV['APP_KEY'] ?? 'base64:' . base64_encode(random_bytes(32))
    ],
    
    // Configurações de sessão
    'session' => [
        'name' => 'CRM_SESSION',
        'lifetime' => 7200, // 2 horas
        'path' => '/',
        'domain' => null,
        'secure' => $_ENV['SESSION_SECURE'] ?? false,
        'httponly' => true,
        'samesite' => 'Lax'
    ],
    
    // Configurações de segurança
    'security' => [
        'csrf_token_name' => '_token',
        'password_min_length' => 8,
        'password_require_special' => true,
        'max_login_attempts' => 5,
        'lockout_duration' => 900, // 15 minutos
        'session_regenerate_interval' => 300 // 5 minutos
    ],
    
    // Configurações de upload
    'upload' => [
        'max_file_size' => 10 * 1024 * 1024, // 10MB
        'allowed_extensions' => ['jpg', 'jpeg', 'png', 'gif', 'pdf', 'doc', 'docx', 'xls', 'xlsx'],
        'upload_path' => __DIR__ . '/../public/uploads/',
        'temp_path' => sys_get_temp_dir()
    ],
    
    // Configurações de email
    'mail' => [
        'driver' => $_ENV['MAIL_DRIVER'] ?? 'smtp',
        'host' => $_ENV['MAIL_HOST'] ?? 'localhost',
        'port' => $_ENV['MAIL_PORT'] ?? 587,
        'username' => $_ENV['MAIL_USERNAME'] ?? '',
        'password' => $_ENV['MAIL_PASSWORD'] ?? '',
        'encryption' => $_ENV['MAIL_ENCRYPTION'] ?? 'tls',
        'from' => [
            'address' => $_ENV['MAIL_FROM_ADDRESS'] ?? 'noreply@empresa.com',
            'name' => $_ENV['MAIL_FROM_NAME'] ?? 'CRM Empresas'
        ]
    ],
    
    // Configurações de backup
    'backup' => [
        'path' => __DIR__ . '/../database/backups/',
        'retention_days' => 30,
        'compress' => true,
        'auto_backup_time' => '01:00', // 01:00 AM
        'max_backup_size' => 100 * 1024 * 1024 // 100MB
    ],
    
    // Configurações de log
    'logging' => [
        'default' => 'file',
        'channels' => [
            'file' => [
                'driver' => 'file',
                'path' => __DIR__ . '/../logs/app.log',
                'level' => $_ENV['LOG_LEVEL'] ?? 'info',
                'max_files' => 30
            ],
            'error' => [
                'driver' => 'file',
                'path' => __DIR__ . '/../logs/error.log',
                'level' => 'error'
            ]
        ]
    ],
    
    // Configurações de paginação
    'pagination' => [
        'per_page' => 20,
        'max_per_page' => 100,
        'page_name' => 'page'
    ],
    
    // Configurações de cache
    'cache' => [
        'default' => 'file',
        'stores' => [
            'file' => [
                'driver' => 'file',
                'path' => __DIR__ . '/../storage/cache'
            ]
        ],
        'prefix' => 'crm_cache_'
    ],
    
    // Configurações de relatórios
    'reports' => [
        'export_formats' => ['pdf', 'excel', 'csv'],
        'temp_path' => sys_get_temp_dir(),
        'max_records' => 10000
    ],
    
    // Configurações de API (para futuras integrações)
    'api' => [
        'rate_limit' => 60, // requests per minute
        'version' => 'v1',
        'prefix' => 'api'
    ]
];

