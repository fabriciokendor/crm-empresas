<?php
/**
 * Controller de Autenticação
 * Sistema de Gerenciamento de Relacionamento com Empresas
 */

class AuthController
{
    private $usuarioModel;
    
    public function __construct()
    {
        $this->usuarioModel = new Usuario();
    }
    
    /**
     * Exibe a página de login
     */
    public function showLogin()
    {
        // Se já estiver logado, redirecionar para dashboard
        if (Auth::check()) {
            $this->redirect('/dashboard');
            return;
        }
        
        $data = [
            'title' => 'Login - CRM Empresas',
            'error' => $_SESSION['login_error'] ?? null,
            'old_email' => $_SESSION['old_email'] ?? ''
        ];
        
        // Limpar mensagens da sessão
        unset($_SESSION['login_error'], $_SESSION['old_email']);
        
        $this->view('auth/login', $data);
    }
    
    /**
     * Processa o login
     */
    public function login()
    {
        try {
            // Validar dados
            $validator = Validator::make($_POST, [
                'email' => 'required|email',
                'senha' => 'required'
            ]);
            
            if (!$validator->validate()) {
                throw new Exception('Por favor, preencha todos os campos corretamente.');
            }
            
            $email = $_POST['email'];
            $senha = $_POST['senha'];
            $lembrar = isset($_POST['lembrar']);
            
            // Tentar fazer login
            if (Auth::attempt($email, $senha, $lembrar)) {
                // Login bem-sucedido
                $this->setSuccessMessage('Login realizado com sucesso!');
                
                // Redirecionar para página solicitada ou dashboard
                $redirectTo = $_SESSION['intended_url'] ?? '/dashboard';
                unset($_SESSION['intended_url']);
                
                $this->redirect($redirectTo);
            } else {
                throw new Exception('Email ou senha incorretos.');
            }
            
        } catch (Exception $e) {
            // Armazenar erro e dados antigos na sessão
            $_SESSION['login_error'] = $e->getMessage();
            $_SESSION['old_email'] = $_POST['email'] ?? '';
            
            $this->redirect('/login');
        }
    }
    
    /**
     * Faz logout do usuário
     */
    public function logout()
    {
        Auth::logout();
        $this->setSuccessMessage('Logout realizado com sucesso!');
        $this->redirect('/login');
    }
    
    /**
     * Exibe página de perfil do usuário
     */
    public function profile()
    {
        $user = Auth::user();
        
        $data = [
            'title' => 'Meu Perfil - CRM Empresas',
            'user' => $user,
            'success' => $_SESSION['success_message'] ?? null,
            'error' => $_SESSION['error_message'] ?? null
        ];
        
        // Limpar mensagens da sessão
        unset($_SESSION['success_message'], $_SESSION['error_message']);
        
        $this->view('auth/profile', $data);
    }
    
    /**
     * Atualiza dados do perfil
     */
    public function updateProfile()
    {
        try {
            $userId = Auth::id();
            
            // Validar dados
            $validator = Validator::make($_POST, [
                'nome' => 'required|min:2|max:100',
                'email' => 'required|email|unique:usuarios,email,' . $userId
            ]);
            
            if (!$validator->validate()) {
                throw new Exception('Dados inválidos: ' . implode(', ', array_map(function($errors) {
                    return implode(', ', $errors);
                }, $validator->errors())));
            }
            
            // Atualizar dados (sem alterar senha e nível de acesso)
            $data = [
                'nome' => $_POST['nome'],
                'email' => $_POST['email'],
                'nivel_acesso' => Auth::user()['nivel_acesso'], // Manter nível atual
                'ativo' => true
            ];
            
            $this->usuarioModel->update($userId, $data);
            
            // Recarregar dados do usuário na sessão
            $updatedUser = $this->usuarioModel->find($userId);
            $_SESSION['user_email'] = $updatedUser['email'];
            
            $this->setSuccessMessage('Perfil atualizado com sucesso!');
            
        } catch (Exception $e) {
            $this->setErrorMessage($e->getMessage());
        }
        
        $this->redirect('/profile');
    }
    
    /**
     * Atualiza senha do usuário
     */
    public function updatePassword()
    {
        try {
            $userId = Auth::id();
            
            // Validar dados
            $validator = Validator::make($_POST, [
                'senha_atual' => 'required',
                'nova_senha' => 'required|min:8',
                'confirmar_senha' => 'required'
            ]);
            
            if (!$validator->validate()) {
                throw new Exception('Por favor, preencha todos os campos corretamente.');
            }
            
            // Verificar se as senhas coincidem
            if ($_POST['nova_senha'] !== $_POST['confirmar_senha']) {
                throw new Exception('A confirmação da senha não confere.');
            }
            
            // Atualizar senha
            $this->usuarioModel->updatePassword(
                $userId,
                $_POST['senha_atual'],
                $_POST['nova_senha']
            );
            
            $this->setSuccessMessage('Senha alterada com sucesso!');
            
        } catch (Exception $e) {
            $this->setErrorMessage($e->getMessage());
        }
        
        $this->redirect('/profile');
    }
    
    /**
     * Middleware para verificar autenticação
     */
    public function requireAuth()
    {
        if (!Auth::check()) {
            // Armazenar URL solicitada para redirecionamento após login
            $_SESSION['intended_url'] = $_SERVER['REQUEST_URI'];
            $this->redirect('/login');
            exit;
        }
    }
    
    /**
     * Middleware para verificar se é administrador
     */
    public function requireAdmin()
    {
        $this->requireAuth();
        
        if (!Auth::isAdmin()) {
            $this->setErrorMessage('Acesso negado. Apenas administradores podem acessar esta página.');
            $this->redirect('/dashboard');
            exit;
        }
    }
    
    /**
     * Verifica se usuário tem permissão para uma ação
     */
    public function can($action, $resource = null)
    {
        if (!Auth::check()) {
            return false;
        }
        
        $userRole = Auth::user()['nivel_acesso'];
        
        // Definir permissões por nível
        $permissions = [
            'admin' => ['*'], // Admin pode tudo
            'operador' => [
                'view_empresas', 'create_empresas', 'edit_empresas',
                'view_ocorrencias', 'create_ocorrencias', 'edit_ocorrencias',
                'view_relatorios', 'export_relatorios'
            ],
            'visualizador' => [
                'view_empresas', 'view_ocorrencias', 'view_relatorios'
            ]
        ];
        
        $userPermissions = $permissions[$userRole] ?? [];
        
        // Admin tem acesso total
        if (in_array('*', $userPermissions)) {
            return true;
        }
        
        // Verificar permissão específica
        return in_array($action, $userPermissions);
    }
    
    /**
     * Renderiza uma view
     */
    private function view($view, $data = [])
    {
        // Extrair variáveis para o escopo da view
        extract($data);
        
        // Incluir header
        include APP_ROOT . '/app/views/layouts/header.php';
        
        // Incluir view específica
        $viewFile = APP_ROOT . '/app/views/' . $view . '.php';
        if (file_exists($viewFile)) {
            include $viewFile;
        } else {
            throw new Exception("View não encontrada: {$view}");
        }
        
        // Incluir footer
        include APP_ROOT . '/app/views/layouts/footer.php';
    }
    
    /**
     * Redireciona para uma URL
     */
    private function redirect($url)
    {
        header("Location: {$url}");
        exit;
    }
    
    /**
     * Define mensagem de sucesso
     */
    private function setSuccessMessage($message)
    {
        $_SESSION['success_message'] = $message;
    }
    
    /**
     * Define mensagem de erro
     */
    private function setErrorMessage($message)
    {
        $_SESSION['error_message'] = $message;
    }
    
    /**
     * Retorna dados do usuário em JSON (para AJAX)
     */
    public function userInfo()
    {
        if (!Auth::check()) {
            http_response_code(401);
            echo json_encode(['error' => 'Não autenticado']);
            return;
        }
        
        $user = Auth::user();
        
        // Remover dados sensíveis
        unset($user['senha']);
        
        header('Content-Type: application/json');
        echo json_encode([
            'user' => $user,
            'permissions' => $this->getUserPermissions()
        ]);
    }
    
    /**
     * Retorna permissões do usuário atual
     */
    private function getUserPermissions()
    {
        if (!Auth::check()) {
            return [];
        }
        
        $userRole = Auth::user()['nivel_acesso'];
        
        $permissions = [
            'admin' => [
                'manage_users', 'manage_companies', 'manage_occurrences',
                'view_reports', 'export_reports', 'manage_backups', 'view_logs'
            ],
            'operador' => [
                'manage_companies', 'manage_occurrences', 'view_reports', 'export_reports'
            ],
            'visualizador' => [
                'view_companies', 'view_occurrences', 'view_reports'
            ]
        ];
        
        return $permissions[$userRole] ?? [];
    }
    
    /**
     * Endpoint para verificar sessão (AJAX)
     */
    public function checkSession()
    {
        header('Content-Type: application/json');
        
        if (Auth::check()) {
            echo json_encode([
                'authenticated' => true,
                'user' => [
                    'id' => Auth::id(),
                    'nome' => Auth::user()['nome'],
                    'email' => Auth::user()['email'],
                    'nivel_acesso' => Auth::user()['nivel_acesso']
                ]
            ]);
        } else {
            echo json_encode(['authenticated' => false]);
        }
    }
}

